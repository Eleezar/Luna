package com.luna.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

// Поиск контактов по имени в любом падеже: «маме», «Ивану», «Петру Сидорову»
object Contacts {

    class Contact(val name: String, val number: String, val type: Int)

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun all(ctx: Context): List<Contact> {
        val out = ArrayList<Contact>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE
        )
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: ""
                val number = c.getString(1) ?: ""
                if (name.isNotBlank() && number.isNotBlank()) out.add(Contact(name, number, c.getInt(2)))
            }
        }
        return out
    }

    // Подходящие контакты: у каждого один номер (мобильный в приоритете)
    fun find(ctx: Context, spoken: String): List<Contact> {
        val stems = spoken.lowercase().split(" ").filter { it.isNotBlank() }.map { Messenger.stem(it) }
        if (stems.isEmpty()) return emptyList()
        val matched = all(ctx).filter { c -> stems.all { st -> Messenger.sharesStem(c.name, st) } }
        val perName = matched.groupBy { it.name }.map { (_, list) ->
            list.firstOrNull { it.type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE } ?: list.first()
        }
        if (perName.size > 1) {
            // «Мама» точнее, чем «Мама Лена»: берём контакт, в имени которого слов ровно столько, сколько сказано
            val exact = perName.filter { it.name.trim().split(" ").size == stems.size }
            if (exact.size == 1) return exact
        }
        return perName
    }
}
