package com.luna.assistant

import android.content.Context
import org.vosk.Model
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

// Голосовая модель не лежит внутри APK (так APK маленький и надёжно ставится).
// При первом запуске она скачивается один раз с GitHub и дальше работает без интернета.
object ModelLoader {

    private const val MODEL_URL = "https://github.com/Eleezar/luna/releases/latest/download/model-ru.zip"

    // Блокирующая функция: вызывать только из фонового потока
    fun ensure(ctx: Context, onStatus: (String) -> Unit): Model {
        val dir = File(ctx.filesDir, "model-ru")
        val ready = File(dir, ".ready")
        if (!ready.exists()) {
            dir.deleteRecursively()
            download(ctx, dir, onStatus)
            ready.writeText("ok")
        }
        return Model(dir.absolutePath)
    }

    private fun download(ctx: Context, dir: File, onStatus: (String) -> Unit) {
        val tmp = File(ctx.cacheDir, "model.zip")
        var lastError: Exception? = null
        for (attempt in 1..3) {
            try {
                downloadTo(tmp, onStatus)
                onStatus("Распаковываю модель…")
                dir.deleteRecursively()
                unzip(tmp, dir)
                tmp.delete()
                return
            } catch (e: Exception) {
                lastError = e
                Thread.sleep(2000)
            }
        }
        tmp.delete()
        throw lastError ?: IOException("Не удалось скачать модель")
    }

    private fun downloadTo(file: File, onStatus: (String) -> Unit) {
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            var done = 0L
            var lastPct = -1
            conn.inputStream.use { input ->
                file.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct && pct % 10 == 0) {
                                lastPct = pct
                                onStatus("Скачиваю голосовую модель: $pct%")
                            }
                        }
                    }
                }
            }
            if (total > 0 && done != total) throw IOException("Модель скачалась не полностью")
        } finally {
            conn.disconnect()
        }
    }

    // Распаковка без верхней папки (vosk-model-small-ru-0.22/...)
    private fun unzip(zip: File, dest: File) {
        dest.mkdirs()
        val root = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val name = entry.name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val out = File(dest, name)
                    if (!out.canonicalPath.startsWith(root)) throw IOException("Неверный путь в архиве")
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
