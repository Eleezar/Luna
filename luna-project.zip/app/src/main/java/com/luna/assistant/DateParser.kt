package com.luna.assistant

import java.util.Calendar

// Разбор русских дат и времени из речи: «завтра в десять утра», «в пятницу в пятнадцать тридцать»,
// «двадцатого ноября в восемнадцать ноль ноль», «через два часа», «в половине десятого»
object DateParser {

    class Result(val date: Calendar?, val hour: Int?, val minute: Int?, val title: String)

    private class TimeMatch(val hour: Int, val minute: Int, val end: Int)
    private class Rel(val target: Calendar, val withTime: Boolean, val end: Int)

    internal val months = mapOf(
        "января" to 0, "февраля" to 1, "марта" to 2, "апреля" to 3, "мая" to 4, "июня" to 5,
        "июля" to 6, "августа" to 7, "сентября" to 8, "октября" to 9, "ноября" to 10, "декабря" to 11
    )

    internal val weekdays = mapOf(
        "понедельник" to Calendar.MONDAY, "понедельника" to Calendar.MONDAY,
        "вторник" to Calendar.TUESDAY, "вторника" to Calendar.TUESDAY,
        "среда" to Calendar.WEDNESDAY, "среду" to Calendar.WEDNESDAY, "среды" to Calendar.WEDNESDAY,
        "четверг" to Calendar.THURSDAY, "четверга" to Calendar.THURSDAY,
        "пятница" to Calendar.FRIDAY, "пятницу" to Calendar.FRIDAY, "пятницы" to Calendar.FRIDAY,
        "суббота" to Calendar.SATURDAY, "субботу" to Calendar.SATURDAY, "субботы" to Calendar.SATURDAY,
        "воскресенье" to Calendar.SUNDAY, "воскресенья" to Calendar.SUNDAY
    )

    internal val ordinals: Map<String, Int> = buildOrdinals()

    // true: время без «утра/вечера» понимается как есть («семь» = 7:00), нужно для будильников
    @Volatile
    private var amBias = false

    private val preps = setOf("в", "во", "к", "около", "на")
    private val hourWords = setOf("часов", "часа", "час", "минут", "минуты", "минуту")
    private val afterWords = setOf("часов", "часа", "час", "минут", "минуты", "минуту", "числа")
    private val fillers = setOf("что", "чтобы", "мне", "о", "про")
    private val tailPreps = setOf("на", "в", "к", "до", "во", "с", "от")

    private fun buildOrdinals(): Map<String, Int> {
        val stems = mapOf(
            "перв" to 1, "втор" to 2, "трет" to 3, "четвёрт" to 4, "четверт" to 4, "пят" to 5,
            "шест" to 6, "седьм" to 7, "восьм" to 8, "девят" to 9, "десят" to 10,
            "одиннадцат" to 11, "двенадцат" to 12, "тринадцат" to 13, "четырнадцат" to 14,
            "пятнадцат" to 15, "шестнадцат" to 16, "семнадцат" to 17, "восемнадцат" to 18,
            "девятнадцат" to 19, "двадцат" to 20, "тридцат" to 30
        )
        val endings = listOf("ый", "ой", "ого", "ое", "ом", "ую", "ья", "ье", "ьего", "ьем", "ий")
        val map = HashMap<String, Int>()
        for ((s, v) in stems) for (e in endings) map[s + e] = v
        return map
    }

    private fun today(): Calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    private fun offsetDays(n: Int): Calendar = today().apply { add(Calendar.DAY_OF_MONTH, n) }

    private fun dayStart(c: Calendar): Calendar = (c.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    private fun nextWeekday(dow: Int): Calendar {
        val c = today()
        do {
            c.add(Calendar.DAY_OF_MONTH, 1)
        } while (c.get(Calendar.DAY_OF_WEEK) != dow)
        return c
    }

    private fun dayMonth(day: Int, month: Int?): Calendar {
        val t = today()
        val c = today()
        if (month != null) {
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.set(Calendar.MONTH, month)
            c.set(Calendar.DAY_OF_MONTH, day)
            if (c.before(t)) c.add(Calendar.YEAR, 1)
        } else {
            c.set(Calendar.DAY_OF_MONTH, minOf(day, c.getActualMaximum(Calendar.DAY_OF_MONTH)))
            if (c.before(t)) {
                c.set(Calendar.DAY_OF_MONTH, 1)
                c.add(Calendar.MONTH, 1)
                c.set(Calendar.DAY_OF_MONTH, minOf(day, c.getActualMaximum(Calendar.DAY_OF_MONTH)))
            }
        }
        return c
    }

    // Читает число (в том числе «двадцать пять») не больше max. Возвращает значение и индекс следующего слова
    internal fun readNumber(w: List<String>, i: Int, max: Int): Pair<Int, Int>? {
        val word = w.getOrNull(i) ?: return null
        val v = Calc.units[word] ?: return null
        if (v >= 20 && v < 100 && v % 10 == 0) {
            val u = Calc.units[w.getOrNull(i + 1) ?: ""]
            if (u != null && u in 1..9 && v + u <= max) return Pair(v + u, i + 2)
        }
        if (v > max) return null
        return Pair(v, i + 1)
    }

    // Учитывает «утра / дня / вечера / ночи» и пропускает слова «часов», «минут»
    private fun finish(hour: Int, minute: Int, w: List<String>, from: Int): TimeMatch {
        var j = from
        var h = hour
        while (j < w.size && w[j] in hourWords) j++
        when (w.getOrNull(j)) {
            "утра" -> { if (h == 12) h = 0; j++ }
            "дня" -> { if (h in 1..6) h += 12; j++ }
            "вечера" -> { if (h < 12) h += 12; j++ }
            "ночи" -> { if (h == 12) h = 0 else if (h in 6..11) h += 12; j++ }
            else -> { if (!amBias && h in 1..6) h += 12 }
        }
        return TimeMatch(((h % 24) + 24) % 24, minute, j)
    }

    private fun parseTimeAt(w: List<String>, i: Int): TimeMatch? {
        val t = w.getOrNull(i) ?: return null
        when (t) {
            "полдень" -> return TimeMatch(12, 0, i + 1)
            "полночь" -> return TimeMatch(0, 0, i + 1)
            "час" -> return finish(1, 0, w, i + 1)
            "половине", "половину" -> {
                val h = ordinals[w.getOrNull(i + 1) ?: ""] ?: return null
                return finish(h - 1, 30, w, i + 2)
            }
            "четверть" -> {
                val h = ordinals[w.getOrNull(i + 1) ?: ""] ?: return null
                return finish(h - 1, 15, w, i + 2)
            }
            "без" -> {
                val m = readNumber(w, i + 1, 59) ?: return null
                val h = readNumber(w, m.second, 23) ?: return null
                return finish((h.first + 23) % 24, 60 - m.first, w, h.second)
            }
        }
        val h = readNumber(w, i, 23) ?: return null
        var j = h.second
        while (j < w.size && (w[j] == "часов" || w[j] == "часа" || w[j] == "час")) j++
        var minute = 0
        val z = w.getOrNull(j)
        if (z == "ноль" || z == "нуль") {
            val m = readNumber(w, j + 1, 9)
            if (m != null) { minute = m.first; j = m.second }
        } else {
            val m = readNumber(w, j, 59)
            if (m != null) { minute = m.first; j = m.second }
        }
        return finish(h.first, minute, w, j)
    }

    private fun parseRelative(w: List<String>, i: Int): Rel? {
        var j = i
        var count = 1
        val first = w.getOrNull(j) ?: return null
        val now = Calendar.getInstance()
        if (first == "полчаса") {
            now.add(Calendar.MINUTE, 30)
            return Rel(now, true, j + 1)
        }
        val nb = readNumber(w, j, 99)
        if (nb != null) { count = nb.first; j = nb.second }
        val u = w.getOrNull(j) ?: return null
        return when {
            u.startsWith("минут") -> { now.add(Calendar.MINUTE, count); Rel(now, true, j + 1) }
            u == "час" || u == "часа" || u == "часов" -> { now.add(Calendar.HOUR_OF_DAY, count); Rel(now, true, j + 1) }
            u == "день" || u == "дня" || u == "дней" -> Rel(offsetDays(count), false, j + 1)
            u.startsWith("недел") -> Rel(offsetDays(7 * count), false, j + 1)
            else -> null
        }
    }

    private fun parseDayMonth(w: List<String>, i: Int): Pair<Calendar, Int>? {
        // число и месяц: «двадцать ноября», «один декабря» (цифры от Google уже превращены в слова)
        val cardDay = readNumber(w, i, 31)
        if (cardDay != null && cardDay.first >= 1) {
            val mo = months[w.getOrNull(cardDay.second) ?: ""]
            if (mo != null) return Pair(dayMonth(cardDay.first, mo), cardDay.second + 1)
        }
        var day: Int? = null
        var j = i
        val card = Calc.units[w[i]]
        val next = ordinals[w.getOrNull(i + 1) ?: ""]
        if ((card == 20 || card == 30) && next != null && next in 1..9) {
            day = card + next
            j = i + 2
        } else if (ordinals.containsKey(w[i])) {
            day = ordinals[w[i]]
            j = i + 1
        }
        if (day == null || day < 1 || day > 31) return null
        val month = months[w.getOrNull(j) ?: ""]
        if (month != null) return Pair(dayMonth(day, month), j + 1)
        val prev = w.getOrNull(i - 1)
        val nextWord = w.getOrNull(j)
        if (nextWord == "числа" || prev == "на" || prev == "к" || prev == "до" || prev == "с") {
            return Pair(dayMonth(day, null), j)
        }
        return null
    }

    fun cleanTitle(s: String): String {
        val w = s.lowercase().split(" ").filter { it.isNotBlank() }.toMutableList()
        while (w.isNotEmpty() && w.first() in fillers) w.removeAt(0)
        while (w.isNotEmpty() && w.last() in tailPreps) w.removeAt(w.size - 1)
        return w.joinToString(" ").replaceFirstChar { it.uppercase() }
    }

    // bareTime = true: пользователь отвечает на вопрос «Во сколько?», предлог «в» можно не говорить
    fun parse(text: String, bareTime: Boolean = false, preferAm: Boolean = false): Result {
        amBias = preferAm
        val w = text.lowercase().split(" ").filter { it.isNotBlank() }
        val used = BooleanArray(w.size)
        var date: Calendar? = null
        var hour: Int? = null
        var minute: Int? = null
        var i = 0
        while (i < w.size) {
            val t = w[i]
            var end = -1
            when {
                t == "сегодня" -> { date = offsetDays(0); end = i + 1 }
                t == "завтра" -> { date = offsetDays(1); end = i + 1 }
                t == "послезавтра" -> { date = offsetDays(2); end = i + 1 }
                weekdays.containsKey(t) -> { date = nextWeekday(weekdays.getValue(t)); end = i + 1 }
                t == "через" -> {
                    val r = parseRelative(w, i + 1)
                    if (r != null) {
                        if (r.withTime) {
                            date = dayStart(r.target)
                            hour = r.target.get(Calendar.HOUR_OF_DAY)
                            minute = r.target.get(Calendar.MINUTE)
                        } else {
                            date = r.target
                        }
                        end = r.end
                    }
                }
                else -> {
                    val dm = parseDayMonth(w, i)
                    if (dm != null) {
                        date = dm.first
                        end = dm.second
                    } else if (hour == null && (t in preps || t == "без" || bareTime)) {
                        val start = if (t in preps) i + 1 else i
                        val tm = parseTimeAt(w, start)
                        if (tm != null) {
                            hour = tm.hour
                            minute = tm.minute
                            end = tm.end
                        }
                    }
                }
            }
            if (end > i) {
                for (k in i until end) used[k] = true
                i = end
            } else {
                i++
            }
        }
        // убираем предлоги перед найденными кусками и слова «числа», «часов»
        val base = used.copyOf()
        for (k in w.indices) {
            if (!base[k]) continue
            if (k > 0 && !base[k - 1] && w[k - 1] in preps) used[k - 1] = true
            if (k + 1 < w.size && !base[k + 1] && w[k + 1] in afterWords) used[k + 1] = true
        }
        val rest = w.filterIndexed { idx, _ -> !used[idx] }.joinToString(" ")
        return Result(date, hour, minute, cleanTitle(rest))
    }
}
