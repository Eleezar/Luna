package com.luna.assistant

import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import java.io.IOException

// Свой «слух» для Vosk: читает звук из выбранного источника и устройства и отдаёт его распознавателю.
// Заменяет стандартный SpeechService, который умеет только один источник.
class VoskListener(
    private val recognizer: Recognizer,
    private val source: Int,
    private val device: AudioDeviceInfo?,
    private val listener: RecognitionListener,
    private val logRoute: Boolean
) {
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    @Volatile
    private var cancelled = false

    private var thread: Thread? = null

    @Volatile
    private var lastLoudAt = SystemClock.elapsedRealtime()

    // Сколько миллисекунд подряд из микрофона идёт цифровая тишина (признак мёртвого источника)
    fun silentMs(): Long = SystemClock.elapsedRealtime() - lastLoudAt

    // true, если микрофон открыт и запись идёт
    fun start(): Boolean {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val bufBytes = maxOf(min, rate / 5 * 2) // не меньше 0,2 секунды звука
        val rec: AudioRecord = try {
            AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes * 2)
        } catch (e: Exception) {
            Diag.log("микрофон", "AudioRecord не создан: ${e.javaClass.simpleName}: ${e.message}")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        if (device != null) rec.setPreferredDevice(device)
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Diag.log("микрофон", "Запись не началась: ${e.message}")
            rec.release()
            return false
        }
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            rec.release()
            return false
        }
        if (logRoute) {
            val routed = rec.routedDevice?.let { Diag.deviceName(it) } ?: "неизвестно"
            Diag.log("микрофон", "Запись идёт: источник $source, устройство: $routed")
        }
        running = true
        val t = Thread { loop(rec, bufBytes / 2) }
        t.name = "luna-mic"
        thread = t
        t.start()
        return true
    }

    private fun post(block: () -> Unit) {
        main.post { if (!cancelled) block() }
    }

    private fun loop(rec: AudioRecord, shorts: Int) {
        val buf = ShortArray(shorts)
        try {
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) {
                    post { listener.onError(IOException("Ошибка чтения звука: $n")) }
                    break
                }
                if (n == 0) continue
                var p = 0
                for (i in 0 until n) {
                    val a = if (buf[i] < 0) -buf[i].toInt() else buf[i].toInt()
                    if (a > p) p = a
                }
                if (p >= 4) lastLoudAt = SystemClock.elapsedRealtime()
                if (recognizer.acceptWaveForm(buf, n)) {
                    val r = recognizer.result
                    post { listener.onResult(r) }
                } else {
                    val p = recognizer.partialResult
                    post { listener.onPartialResult(p) }
                }
            }
        } catch (e: Exception) {
            post { listener.onError(e) }
        } finally {
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
        }
    }

    // Останавливает запись и ждёт конца потока: после этого распознаватель можно закрывать
    fun stop() {
        cancelled = true
        running = false
        try { thread?.join(1500) } catch (e: InterruptedException) { }
        thread = null
    }
}
