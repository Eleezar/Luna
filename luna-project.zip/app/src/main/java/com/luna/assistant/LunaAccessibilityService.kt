package com.luna.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Служба доступности: Луна видит экран любого приложения и по голосовой команде нажимает, прокручивает, вводит текст.
// Содержимое экрана не сохраняется и не записывается в журнал.
class LunaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: LunaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
        Diag.set("Служба доступности", "включена")
        Diag.log("доступность", "Служба доступности подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Diag.set("Служба доступности", "выключена")
        Diag.log("доступность", "Служба доступности отключена")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // Обход дерева элементов экрана в ширину
    private fun walk(root: AccessibilityNodeInfo, limit: Int = 3000, visit: (AccessibilityNodeInfo) -> Unit) {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(root)
        var count = 0
        while (queue.isNotEmpty() && count < limit) {
            val n = queue.removeFirst()
            count++
            visit(n)
            for (i in 0 until n.childCount) {
                val c = n.getChild(i)
                if (c != null) queue.addLast(c)
            }
        }
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.isEnabled) {
                if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            cur = cur.parent
            depth++
        }
        // запасной вариант: касание по центру элемента
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    // Нажать на элемент, на котором написан текст (или есть такое описание)
    fun clickText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = query.lowercase().trim()
        if (q.isEmpty()) return false
        var exact: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        var partialLen = Int.MAX_VALUE
        walk(root) { n ->
            val label = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").lowercase().trim()
            if (label.isNotEmpty() && n.isVisibleToUser) {
                if (label == q) {
                    if (exact == null) exact = n
                } else if (label.contains(q) && label.length < partialLen) {
                    partial = n
                    partialLen = label.length
                }
            }
        }
        val target = exact ?: partial ?: return false
        return clickNode(target)
    }

    // Нажать на элемент, в котором есть слово с таким началом («ива» найдёт «Иван Петров»). Поля ввода пропускаем
    fun clickTextFuzzy(stem: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var best: AccessibilityNodeInfo? = null
        var bestLen = Int.MAX_VALUE
        walk(root) { n ->
            if (!n.isEditable && n.isVisibleToUser) {
                val label = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
                if (label.isNotEmpty() && Messenger.sharesStem(label, stem) && label.length < bestLen) {
                    best = n
                    bestLen = label.length
                }
            }
        }
        val target = best ?: return false
        return clickNode(target)
    }

    // Включить или выключить переключатель по подписи (например «Динамик»), не нажимая лишний раз
    fun setToggle(labels: List<String>, on: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null
        walk(root) { n ->
            if (target == null && n.isVisibleToUser) {
                val label = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").lowercase()
                if (labels.any { label.contains(it) }) target = n
            }
        }
        val t = target ?: return false
        var cur: AccessibilityNodeInfo? = t
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isCheckable) {
                if (cur.isChecked == on) return true
                break
            }
            cur = cur.parent
            depth++
        }
        return clickNode(t)
    }

    // Вписать текст в поле ввода (в активное или в первое найденное)
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var field: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (field == null) {
            walk(root) { n -> if (field == null && n.isEditable && n.isVisibleToUser) field = n }
        }
        val f = field ?: return false
        val existing = if (f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val joined = if (existing.isEmpty()) text else "$existing $text"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, joined)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null
        walk(root) { n -> if (target == null && n.isScrollable && n.isVisibleToUser) target = n }
        val t = target ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return t.performAction(action)
    }

    // Тексты, видимые на экране (для команды «что на экране»)
    fun readScreen(limit: Int = 25): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = LinkedHashSet<String>()
        walk(root) { n ->
            if (out.size < limit && n.isVisibleToUser) {
                val s = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                if (s.isNotEmpty() && s.length < 300) out.add(s)
            }
        }
        return out.toList()
    }
}
