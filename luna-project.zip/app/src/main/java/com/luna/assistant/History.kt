package com.luna.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

// Память Луны о том, что она делала: что просили, что ответила, что получилось и что нет.
// Нужна, чтобы отвечать на вопросы «почему не включила музыку?» и «что ты сейчас сделала?».
// Хранится только в памяти и пропадает при перезапуске приложения.
object History {

    class Step(val text: String, var reply: String, var ok: Boolean, val domain: String) {
        var reason: String = ""
    }

    class Action(val time: Long, val text: String, val domain: String) {
        var reply: String = ""
        var ok = true
        var reason: String = ""
        val steps = ArrayList<Step>()
    }

    private val items = ArrayList<Action>()

    @Volatile
    var lastSpoken: String = ""

    @Volatile
    var lastHeard: String = ""

    @Volatile
    var lastHeardRaw: String = ""

    @Volatile
    var pendingRaw: String = ""

    private val failurePrefixes = listOf(
        "не нашла", "не поняла", "не получилось", "нет ", "включите", "не удалось", "сейчас нет", "не могу",
        "нет разрешения", "не нашла", "это уведомление уже закрыто"
    )

    fun isFailure(reply: String?): Boolean {
        val r = (reply ?: "").lowercase().trim()
        return failurePrefixes.any { r.startsWith(it) }
    }

    // К какой области относится фраза: музыка, звонок, смс, сценарий…
    fun domainOf(text: String): String {
        val t = text.lowercase()
        if (Scenarios.find(t) != null) return "scenario"
        val rules = listOf(
            "music" to listOf("музык", "пауза", "трек", "песн", "играй", "плеер", "воспроизв"),
            "sms" to listOf("смс", "ммс"),
            "call" to listOf("позвони", "набери", "звонок", "трубк", "громкая связь", "громкую связь", "динамик"),
            "message" to listOf("ответь", "в телеграм", "в ватсап", "в вайбер", "в вк"),
            "alarm" to listOf("будильник", "таймер", "разбуди", "засеки"),
            "note" to listOf("заметк"),
            "event" to listOf("напомни", "событи", "запланируй", "календар"),
            "notifications" to listOf("уведомлен"),
            "scenario" to listOf("сценари"),
            "device" to listOf("нажми", "прокрути", "листай", "назад", "экран", "скриншот", "напиши", "отправь"),
            "app" to listOf("открой", "запусти", "включи"),
            "volume" to listOf("громк", "громче", "тише", "без звука")
        )
        for ((domain, words) in rules) if (words.any { t.contains(it) }) return domain
        return "other"
    }

    @Synchronized
    fun add(text: String, reply: String): Action {
        val a = Action(System.currentTimeMillis(), text, domainOf(text))
        a.reply = reply
        a.ok = !isFailure(reply)
        items.add(a)
        while (items.size > 30) items.removeAt(0)
        return a
    }

    // Ответ на вопрос Луны (например, «да» на «Отправить?»): уточняем итог последнего действия
    @Synchronized
    fun update(reply: String) {
        val a = items.lastOrNull() ?: return
        a.reply = reply
        a.ok = !isFailure(reply)
    }

    @Synchronized
    fun last(): Action? = items.lastOrNull()

    @Synchronized
    fun lastFailure(): Action? = items.lastOrNull { !it.ok || it.steps.any { s -> !s.ok } }

    @Synchronized
    fun findForTopic(topic: String): Action? =
        items.lastOrNull { it.domain == topic || it.steps.any { s -> s.domain == topic } }

    // Шаг сценария: добавляется к последнему запущенному сценарию
    @Synchronized
    fun addStep(text: String, reply: String, ok: Boolean, domain: String) {
        val a = items.lastOrNull { it.domain == "scenario" } ?: return
        a.steps.add(Step(text, reply, ok, domain))
        if (!ok) a.ok = false
    }

    // Итог проверки: началась ли музыка после команды «включи музыку»
    @Synchronized
    fun noteMusic(ok: Boolean, reason: String) {
        val a = items.lastOrNull() ?: return
        if (System.currentTimeMillis() - a.time > 180_000) return
        if (a.domain == "music") {
            a.ok = ok
            a.reason = if (ok) "" else reason
            return
        }
        val s = a.steps.lastOrNull { it.domain == "music" } ?: return
        s.ok = ok
        s.reason = if (ok) "" else reason
        a.ok = a.steps.all { it.ok }
    }

    @Synchronized
    fun noteHeard(text: String) {
        lastHeard = text
        lastHeardRaw = if (pendingRaw.isNotBlank()) pendingRaw else text
        pendingRaw = ""
    }

    // Что сказать по итогам сценария, если что-то не получилось
    fun summarizeScenario(name: String) {
        val a = synchronized(this) { items.lastOrNull { it.domain == "scenario" } } ?: return
        val failed = a.steps.filter { !it.ok }
        if (failed.isEmpty()) return
        VoiceService.announce(
            "Сценарий $name выполнен не полностью. Не получилось: ${failed.joinToString(", ") { it.text }}. Спросите: почему не получилось?"
        )
    }

    // ---------- объяснения ----------

    private fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    private fun ago(time: Long): String {
        val min = ((System.currentTimeMillis() - time) / 60000).toInt()
        return when {
            min <= 0 -> "только что"
            min < 60 -> "$min ${plural(min, "минуту", "минуты", "минут")} назад"
            else -> "${min / 60} ${plural(min / 60, "час", "часа", "часов")} назад"
        }
    }

    private fun featureOf(domain: String): String? = when (domain) {
        "music", "device", "notifications" -> "device"
        "call", "sms" -> "phone"
        "message" -> "messenger"
        "alarm" -> "alarms"
        "note" -> "notes"
        "event" -> "events"
        "scenario" -> "scenarios"
        else -> null
    }

    private fun has(ctx: Context, perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun hintFor(domain: String, reply: String): String {
        val r = reply.lowercase()
        return when {
            r.contains("доступности") -> "Включите службу доступности кнопкой на главном экране."
            r.contains("доступ к уведомлениям") -> "Включите доступ к уведомлениям кнопкой на главном экране."
            r.contains("разрешени") || r.contains("доступа к контактам") ->
                "Выдайте разрешения кнопками на главном экране."
            r.contains("не нашла приложение") || (domain == "app" && r.contains("не нашла")) ->
                "Назовите приложение так, как оно называется на телефоне."
            domain == "music" ->
                "Для музыки нужен плеер: откройте музыкальное приложение или добавьте в сценарий шаги «открой ютуб музыку», «подожди пять секунд», «включи музыку»."
            else -> ""
        }
    }

    // Почему не получилось: выключенные возможности, нет разрешений, нет службы
    private fun reasonFor(ctx: Context, domain: String, text: String, reply: String, explicit: String): String {
        if (explicit.isNotBlank()) return explicit
        val key = featureOf(domain)
        if (key != null && !Features.on(key)) {
            val label = Features.all.firstOrNull { it.first == key }?.second ?: key
            return "Выключена возможность «$label». Включите её на экране «Секретарь»."
        }
        if (domain == "call" && !has(ctx, Manifest.permission.CALL_PHONE)) return "Нет разрешения на звонки."
        if (domain == "sms" && !has(ctx, Manifest.permission.SEND_SMS)) return "Нет разрешения на SMS."
        if ((domain == "call" || domain == "sms") && !Contacts.hasPermission(ctx)) return "Нет доступа к контактам."
        if ((domain == "device" || domain == "message") && LunaAccessibilityService.instance == null &&
            isFailure(reply)
        ) return "Не включена служба доступности."
        if (domain == "notifications" && LunaNotificationListener.instance == null) return "Не включён доступ к уведомлениям."
        if (reply.lowercase().startsWith("не поняла")) {
            return "Я не распознала команду. Услышала: «$text». Возможно, распознавание ошиблось."
        }
        if (isFailure(reply)) return "Я ответила: $reply."
        return ""
    }

    // Объяснение по записи. topic: область вопроса (например, «music»), чтобы выделить нужный шаг
    fun explain(ctx: Context, a: Action, topic: String): String {
        val sb = StringBuilder("Вы просили: ${a.text}, ${ago(a.time)}. ")
        if (a.steps.isNotEmpty()) {
            val focus = if (topic != "scenario" && topic != "other") a.steps.filter { it.domain == topic } else a.steps
            val list = if (focus.isEmpty()) a.steps else focus
            val failed = list.filter { !it.ok }
            if (failed.isEmpty()) {
                sb.append("Все шаги выполнены: ${list.size}. Ошибок я не вижу.")
            } else {
                for (s in failed.take(3)) {
                    val reason = reasonFor(ctx, s.domain, s.text, s.reply, s.reason)
                    sb.append("Шаг «${s.text}» не получился. $reason ")
                    val hint = hintFor(s.domain, s.reply + " " + reason)
                    if (hint.isNotBlank()) sb.append(hint).append(' ')
                }
            }
        } else if (a.ok && a.reason.isBlank()) {
            sb.append("Я ответила: ${a.reply}. Ошибок не было.")
        } else {
            val reason = reasonFor(ctx, a.domain, a.text, a.reply, a.reason)
            sb.append(if (reason.isNotBlank()) reason else "Я ответила: ${a.reply}.").append(' ')
            val hint = hintFor(a.domain, a.reply + " " + reason)
            if (hint.isNotBlank()) sb.append(hint)
        }
        return sb.toString().trim()
    }

    // Если по теме ничего не делали, но возможность выключена
    fun featureOffReason(topic: String): String? {
        val key = featureOf(topic) ?: return null
        if (Features.on(key)) return null
        val label = Features.all.firstOrNull { it.first == key }?.second ?: key
        return "Возможность «$label» сейчас выключена, поэтому я не выполняю такие команды. Включите её на экране «Секретарь»."
    }
}
