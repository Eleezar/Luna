package com.luna.assistant

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification

// Последние уведомления других приложений. Хранятся только в памяти и пропадают при перезапуске приложения.
// Если у уведомления есть кнопка «Ответить», Луна запоминает её, чтобы ответить голосом.
object NotifStore {

    class Item(
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val pkg: String,
        val key: String,
        var replyAction: Notification.Action?
    ) {
        var read = false
    }

    private val items = ArrayList<Item>()

    private fun appLabel(ctx: Context, pkg: String): String {
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    @Synchronized
    fun add(ctx: Context, sbn: StatusBarNotification) {
        if (sbn.packageName == ctx.packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return // постоянные уведомления (музыка, навигация) не читаем
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = appLabel(ctx, sbn.packageName)
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }
        items.removeAll { it.app == app && it.title == title && it.text == text }
        items.add(Item(app, title, text, sbn.postTime, sbn.packageName, sbn.key, reply))
        while (items.size > 50) items.removeAt(0)
        Diag.inc("уведомлений получено")
    }

    // Уведомление закрыто: ответить через него уже нельзя
    @Synchronized
    fun onRemoved(key: String) {
        for (i in items) if (i.key == key) i.replyAction = null
    }

    @Synchronized
    fun unread(): List<Item> = items.filter { !it.read }.sortedByDescending { it.time }

    // Уведомления, на которые можно ответить, самые свежие первыми
    @Synchronized
    fun replyable(): List<Item> = items.filter { it.replyAction != null }.sortedByDescending { it.time }

    @Synchronized
    fun markRead(list: List<Item>) {
        for (i in list) i.read = true
    }

    @Synchronized
    fun count(): Int = items.size

    @Synchronized
    fun clear() = items.clear()
}
