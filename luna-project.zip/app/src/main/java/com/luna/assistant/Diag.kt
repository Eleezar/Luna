package com.luna.assistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

// Диагностика: журнал событий (в памяти и в файле), счётчики, состояние, отчёт, запись сбоев
object Diag {

    const val BUILD = "diag-1"
    private const val MAX_LINES = 600

    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val fmtFull = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US)
    private val lines = ArrayList<String>()
    private val counters = LinkedHashMap<String, Int>()
    private val state = LinkedHashMap<String, String>()
    private var logFile: File? = null
    private var crashFile: File? = null
    private val io = Executors.newSingleThreadExecutor()

    @Volatile
    var micResults: String = ""

    fun init(ctx: Context) {
        logFile = File(ctx.filesDir, "luna.log")
        crashFile = File(ctx.filesDir, "last_crash.txt")
        try {
            val f = logFile
            if (f != null && f.exists()) {
                synchronized(this) { lines.addAll(f.readLines().takeLast(MAX_LINES)) }
            }
        } catch (e: Exception) {
        }
        log("приложение", "Запуск процесса, сборка $BUILD")
    }

    fun log(tag: String, msg: String) {
        val line = synchronized(this) {
            val l = "${fmt.format(Date())} [$tag] $msg"
            lines.add(l)
            while (lines.size > MAX_LINES) lines.removeAt(0)
            l
        }
        Log.d("Luna", "[$tag] $msg")
        val f = logFile ?: return
        io.execute {
            try {
                if (f.length() > 300_000) {
                    val tail = f.readLines().takeLast(MAX_LINES / 2)
                    f.writeText(tail.joinToString("\n") + "\n")
                }
                f.appendText(line + "\n")
            } catch (e: Exception) {
            }
        }
    }

    fun inc(name: String) {
        synchronized(this) { counters[name] = (counters[name] ?: 0) + 1 }
    }

    fun counter(name: String): Int = synchronized(this) { counters[name] ?: 0 }

    fun stateOf(key: String): String? = synchronized(this) { state[key] }

    fun set(key: String, value: String) {
        synchronized(this) { state[key] = value }
    }

    // Запись сбоя: синхронно, потому что процесс вот-вот завершится
    fun crash(thread: Thread, e: Throwable) {
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val text = synchronized(this) { "${fmtFull.format(Date())}, поток ${thread.name}\n$sw" }
        try { crashFile?.writeText(text) } catch (x: Exception) { }
        try {
            val stamp = synchronized(this) { fmt.format(Date()) }
            logFile?.appendText("$stamp [СБОЙ] ${e.javaClass.simpleName}: ${e.message}\n")
        } catch (x: Exception) { }
    }

    fun clear() {
        synchronized(this) {
            lines.clear()
            counters.clear()
        }
        try { logFile?.delete() } catch (e: Exception) { }
        try { crashFile?.delete() } catch (e: Exception) { }
        micResults = ""
        log("приложение", "Журнал очищен")
    }

    fun typeName(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "встроенный микрофон"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "проводная гарнитура"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "проводные наушники (без микрофона)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (звонки)"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (музыка)"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB-устройство"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB-гарнитура"
        AudioDeviceInfo.TYPE_TELEPHONY -> "телефонный канал"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "разговорный динамик"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "динамик"
        AudioDeviceInfo.TYPE_LINE_ANALOG -> "линейный вход"
        AudioDeviceInfo.TYPE_BUS -> "шина"
        AudioDeviceInfo.TYPE_REMOTE_SUBMIX -> "внутренний канал"
        else -> "тип $type"
    }

    fun deviceName(d: AudioDeviceInfo): String {
        val name = d.productName?.toString().orEmpty()
        return typeName(d.type) + if (name.isNotBlank()) " ($name)" else ""
    }

    fun inputDevices(ctx: Context): String {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val list = am.getDevices(AudioManager.GET_DEVICES_INPUTS).map { deviceName(it) }
            if (list.isEmpty()) "нет" else list.joinToString("; ")
        } catch (e: Exception) {
            "ошибка: ${e.message}"
        }
    }

    private fun yesNo(b: Boolean) = if (b) "да" else "НЕТ"

    fun report(ctx: Context): String {
        val sb = StringBuilder()
        val now = synchronized(this) { fmtFull.format(Date()) }
        sb.append("=== ЛУНА: ОТЧЁТ ДИАГНОСТИКИ ===\n")
        sb.append("Время: $now\n")
        sb.append("Сборка кода: $BUILD\n")
        try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            sb.append("Установлено/обновлено: ${synchronized(this) { fmtFull.format(Date(pi.lastUpdateTime)) }}\n")
        } catch (e: Exception) {
        }
        sb.append("Телефон: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Свободно в памяти приложения: ${ctx.filesDir.usableSpace / 1024 / 1024} МБ\n")

        sb.append("\n--- Разрешения ---\n")
        try {
            val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val notif = ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
            val overlay = Settings.canDrawOverlays(ctx)
            val battery = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            sb.append("Микрофон: ${yesNo(mic)}\n")
            sb.append("Уведомления: ${yesNo(notif)}\n")
            sb.append("Поверх других окон: ${yesNo(overlay)}\n")
            sb.append("Экономия батареи отключена для Луны: ${yesNo(battery)}\n")
        } catch (e: Exception) {
            sb.append("не удалось проверить: ${e.message}\n")
        }

        sb.append("\n--- Состояние ---\n")
        val st = synchronized(this) { LinkedHashMap(state) }
        for (key in listOf("Служба", "Режим", "Модель", "Голос (TTS)", "Распознавание команд", "Google-распознаватель", "Порог слова «Луна»", "Источник звука", "Музыка и Bluetooth", "Слежение за звонками")) {
            sb.append("$key: ${st[key] ?: "—"}\n")
        }
        try {
            val dir = File(ctx.filesDir, "model-ru")
            if (dir.exists()) {
                val files = dir.walkTopDown().filter { it.isFile }.toList()
                val mb = files.sumOf { it.length() } / 1024 / 1024
                sb.append("Файлы модели: ${files.size} шт., $mb МБ, готова: ${yesNo(File(dir, ".ready").exists())}\n")
            } else {
                sb.append("Файлы модели: папки нет (модель ещё не скачана)\n")
            }
        } catch (e: Exception) {
            sb.append("Файлы модели: ошибка ${e.message}\n")
        }

        sb.append("\n--- Микрофон ---\n")
        sb.append("Входные устройства: ${inputDevices(ctx)}\n")
        if (micResults.isNotBlank()) {
            sb.append("Последний тест источников:\n${micResults}\n")
        } else {
            sb.append("Тест источников звука не запускался (кнопка «Тест микрофона»)\n")
        }

        sb.append("\n--- Секретарь ---\n")
        try {
            sb.append("Заметок: ${Store.allNotes().size}, будущих событий: ${Store.upcoming(System.currentTimeMillis()).size}, сценариев: ${Store.allScenarios().size}, будильников и таймеров: ${Store.allAlarms().size}\n")
            sb.append("Поправок и своих фраз: ${Aliases.count()}\n")
            val alarms = ctx.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            sb.append("Точные напоминания разрешены: ${yesNo(Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms())}\n")
            sb.append("Календарь телефона (разрешение): ${yesNo(CalendarSync.hasPermission(ctx))}\n")
        } catch (e: Exception) {
            sb.append("не удалось проверить: ${e.message}\n")
        }

        sb.append("\n--- Управление телефоном ---\n")
        sb.append("Служба доступности подключена: ${yesNo(LunaAccessibilityService.instance != null)}\n")
        sb.append("Чтение уведомлений подключено: ${yesNo(LunaNotificationListener.instance != null)}\n")
        sb.append("Уведомлений в памяти Луны: ${NotifStore.count()}\n")

        sb.append("\n--- Счётчики ---\n")
        val cs = synchronized(this) { LinkedHashMap(counters) }
        if (cs.isEmpty()) sb.append("пока пусто\n") else cs.forEach { (k, v) -> sb.append("$k: $v\n") }

        sb.append("\n--- Последний сбой приложения ---\n")
        try {
            val f = crashFile
            if (f != null && f.exists()) sb.append(f.readText().take(2500)).append("\n")
            else sb.append("сбоев не было\n")
        } catch (e: Exception) {
            sb.append("не удалось прочитать\n")
        }

        sb.append("\n--- Журнал (последние события) ---\n")
        val tail = synchronized(this) { lines.takeLast(150).toList() }
        if (tail.isEmpty()) sb.append("пусто\n") else tail.forEach { sb.append(it).append("\n") }
        return sb.toString()
    }
}
