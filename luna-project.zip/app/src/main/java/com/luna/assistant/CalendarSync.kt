package com.luna.assistant

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.util.TimeZone

// Запись событий в календарь телефона (если есть разрешение и календарь). Если нет — события живут только в Луне.
object CalendarSync {

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    // Возвращает id события в календаре телефона или -1, если записать не получилось
    fun insert(ctx: Context, title: String, start: Long): Long {
        if (!hasPermission(ctx)) {
            Diag.log("календарь", "Нет разрешения на календарь телефона: событие сохранено только в Луне")
            return -1L
        }
        var result = -1L
        try {
            val calId = pickCalendar(ctx)
            if (calId == null) {
                Diag.log("календарь", "В телефоне не найден календарь для записи: событие сохранено только в Луне")
            } else {
                val values = ContentValues().apply {
                    put(CalendarContract.Events.DTSTART, start)
                    put(CalendarContract.Events.DTEND, start + 60 * 60 * 1000L)
                    put(CalendarContract.Events.TITLE, title)
                    put(CalendarContract.Events.CALENDAR_ID, calId)
                    put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                }
                val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                result = uri?.lastPathSegment?.toLongOrNull() ?: -1L
                Diag.log("календарь", "Событие записано в календарь телефона, id $result")
            }
        } catch (e: Exception) {
            Diag.log("календарь", "Ошибка записи в календарь телефона: ${e.javaClass.simpleName}: ${e.message}")
        }
        return result
    }

    fun delete(ctx: Context, sysId: Long) {
        if (sysId < 0 || !hasPermission(ctx)) return
        try {
            ctx.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, sysId), null, null)
            Diag.log("календарь", "Событие $sysId удалено из календаря телефона")
        } catch (e: Exception) {
            Diag.log("календарь", "Не удалось удалить из календаря телефона: ${e.message}")
        }
    }

    private fun pickCalendar(ctx: Context): Long? {
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        var first: Long? = null
        var primary: Long? = null
        val cursor = ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (first == null) first = id
                if (primary == null && c.getInt(1) == 1) primary = id
            }
        }
        return primary ?: first
    }
}
