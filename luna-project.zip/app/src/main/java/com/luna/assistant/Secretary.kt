package com.luna.assistant

import android.content.Context
import java.util.Calendar
import java.util.Locale

// Секретарь: голосовые заметки и события с напоминаниями
object Secretary {

    private val noteAdd = listOf(
        "запиши заметку", "добавь заметку", "создай заметку", "сделай заметку", "новая заметка", "заметка", "запиши"
    )
    private val eventAdd = listOf(
        "запиши в календарь", "добавь в календарь", "создай событие", "добавь событие", "новое событие",
        "поставь напоминание", "напомни мне", "напомни", "запланируй", "назначь"
    )

    private class Draft(var title: String?, var date: Calendar?, var hour: Int?, var minute: Int?) {
        var tries = 0
    }

    private val monthsGen = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val weekdayNames = mapOf(
        Calendar.MONDAY to "понедельник", Calendar.TUESDAY to "вторник", Calendar.WEDNESDAY to "среда",
        Calendar.THURSDAY to "четверг", Calendar.FRIDAY to "пятница", Calendar.SATURDAY to "суббота",
        Calendar.SUNDAY to "воскресенье"
    )

    private fun strip(t: String, prefixes: List<String>): String? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t == p) return ""
            if (t.startsWith("$p ")) return t.removePrefix("$p ").trim()
        }
        return null
    }

    // Команды, которые диктуются длинной фразой (Луна дожидается конца диктовки)
    fun isDictation(t: String): Boolean = strip(t, eventAdd) != null || strip(t, noteAdd) != null

    fun handle(ctx: Context, t: String): Reply? {
        val ev = strip(t, eventAdd)
        if (ev != null) return addEvent(ctx, ev)
        val note = strip(t, noteAdd)
        if (note != null) return addNote(note)

        if (t.contains("заметк")) {
            if (t.contains("удали")) return if (t.contains("все")) confirmClearNotes() else deleteLastNote()
            val read = listOf("прочита", "прочти", "какие", "покажи", "последние", "мои", "сколько", "озвучь", "в заметках")
            if (read.any { t.contains(it) }) return readNotes()
        }
        if (t.contains("удали") && t.contains("событи")) return deleteLastEvent(ctx)
        if (isEventListQuery(t)) return listEvents(t)
        return null
    }

    private fun isEventListQuery(t: String): Boolean =
        t.startsWith("что у меня") || t.contains("мои события") || t.contains("ближайшие события") ||
            t.contains("что в календаре") || t.contains("какие события") || t.contains("что запланировано") ||
            t.contains("мой календарь") || t.contains("покажи события")

    // ---------- заметки ----------

    private fun addNote(raw: String): Reply {
        val text = DateParser.cleanTitle(raw)
        if (text.isBlank()) return Reply("Что записать?") { s -> addNote(s) }
        Store.addNote(text)
        Diag.inc("заметок записано")
        Diag.log("секретарь", "Заметка: «$text»")
        return Reply("Записала заметку: ${shorten(text)}")
    }

    private fun readNotes(): Reply {
        val all = Store.allNotes().sortedByDescending { it.id }
        if (all.isEmpty()) return Reply("Заметок пока нет")
        val names = listOf("Первая", "Вторая", "Третья")
        val sb = StringBuilder("У вас ${all.size} ${plural(all.size, "заметка", "заметки", "заметок")}. ")
        all.take(3).forEachIndexed { i, n -> sb.append("${names[i]}: ${n.text}. ") }
        return Reply(sb.toString().trim())
    }

    private fun deleteLastNote(): Reply {
        val n = Store.deleteLastNote() ?: return Reply("Заметок нет")
        Diag.log("секретарь", "Удалена заметка: «${n.text}»")
        return Reply("Удалила заметку: ${shorten(n.text)}")
    }

    private fun confirmClearNotes(): Reply = Reply("Удалить все заметки? Скажите да или нет.") { s ->
        if (isYes(s)) {
            val c = Store.clearNotes()
            Diag.log("секретарь", "Удалены все заметки: $c")
            Reply("Удалила $c ${plural(c, "заметку", "заметки", "заметок")}")
        } else {
            Reply("Хорошо, оставляю")
        }
    }

    private fun isYes(s: String): Boolean {
        val w = s.lowercase().split(" ")
        return w.any { it in setOf("да", "давай", "конечно", "удаляй", "подтверждаю", "ага") } && "нет" !in w
    }

    // ---------- события ----------

    private fun addEvent(ctx: Context, raw: String): Reply {
        val p = DateParser.parse(raw)
        val d = Draft(p.title.ifBlank { null }, p.date, p.hour, p.minute)
        return step(ctx, d)
    }

    private fun absorb(d: Draft, s: String, bare: Boolean) {
        val p = DateParser.parse(s, bare)
        if (d.title.isNullOrBlank() && p.title.isNotBlank()) d.title = p.title
        if (p.date != null) d.date = p.date
        if (p.hour != null) {
            d.hour = p.hour
            d.minute = p.minute
        }
    }

    private fun step(ctx: Context, d: Draft): Reply {
        d.tries++
        if (d.tries > 6) return Reply("Не получилось. Давайте начнём заново.")

        val title = d.title
        if (title.isNullOrBlank()) {
            return Reply("Что запланировать?") { s -> absorb(d, s, false); step(ctx, d) }
        }
        val hour = d.hour
        val dateVal = d.date
        if (dateVal == null && hour == null) {
            return Reply("На какую дату и время?") { s -> absorb(d, s, true); step(ctx, d) }
        }
        if (hour == null) {
            return Reply("Во сколько?") { s -> absorb(d, s, true); step(ctx, d) }
        }
        val minute = d.minute ?: 0
        val now = System.currentTimeMillis()

        val cal: Calendar = if (dateVal == null) {
            Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) add(Calendar.DAY_OF_MONTH, 1)
            }
        } else {
            (dateVal.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        }

        if (cal.timeInMillis <= now) {
            d.date = null
            d.hour = null
            d.minute = null
            return Reply("Это время уже прошло. На какую дату и время?") { s -> absorb(d, s, true); step(ctx, d) }
        }

        val start = cal.timeInMillis
        val sysId = CalendarSync.insert(ctx, title, start)
        val ev = Store.addEvent(title, start, sysId)
        Reminders.schedule(ctx, ev)
        Diag.inc("событий записано")
        Diag.log("секретарь", "Событие: «$title», ${describe(cal)}, в календаре телефона: ${if (sysId >= 0) "да" else "нет"}")
        return Reply("Записала: $title, ${describe(cal)}")
    }

    private fun deleteLastEvent(ctx: Context): Reply {
        val ev = Store.lastAddedEvent() ?: return Reply("Событий нет")
        Reminders.cancel(ctx, ev.id)
        CalendarSync.delete(ctx, ev.sysId)
        Store.deleteEvent(ev.id)
        Diag.log("секретарь", "Удалено событие: «${ev.title}»")
        return Reply("Удалила событие: ${ev.title}")
    }

    private fun listEvents(t: String): Reply {
        val now = System.currentTimeMillis()
        var list = Store.upcoming(now)
        val dayFilter = when {
            t.contains("послезавтра") -> 2
            t.contains("завтра") -> 1
            t.contains("сегодня") -> 0
            else -> -1
        }
        if (dayFilter >= 0) list = list.filter { dayDiff(it.start) == dayFilter }
        if (list.isEmpty()) {
            return Reply(
                when (dayFilter) {
                    0 -> "На сегодня ничего не запланировано"
                    1 -> "На завтра ничего не запланировано"
                    2 -> "На послезавтра ничего не запланировано"
                    else -> "Ближайших событий нет"
                }
            )
        }
        val sb = StringBuilder()
        for (ev in list.take(4)) {
            val cal = Calendar.getInstance().apply { timeInMillis = ev.start }
            sb.append("${describe(cal)}: ${ev.title}. ")
        }
        if (list.size > 4) sb.append("И ещё ${list.size - 4}.")
        return Reply(sb.toString().trim())
    }

    // ---------- вспомогательное ----------

    private fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun dayDiff(ms: Long): Int =
        Math.round((startOfDay(ms) - startOfDay(System.currentTimeMillis())) / 86_400_000.0).toInt()

    fun describe(cal: Calendar): String {
        val time = String.format(Locale.US, "%d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        val day = when (dayDiff(cal.timeInMillis)) {
            0 -> "сегодня"
            1 -> "завтра"
            2 -> "послезавтра"
            else -> "${weekdayNames[cal.get(Calendar.DAY_OF_WEEK)]}, ${cal.get(Calendar.DAY_OF_MONTH)} ${monthsGen[cal.get(Calendar.MONTH)]}"
        }
        return "$day в $time"
    }

    private fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    private fun shorten(s: String): String = if (s.length <= 90) s else s.take(90) + "…"
}
