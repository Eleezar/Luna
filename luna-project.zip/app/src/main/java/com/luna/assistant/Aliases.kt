package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Поправки и свои фразы.
// 1) Поправки: «нет, я сказал ютуб» — Луна запоминает, как вы произносите слово, и в следующий раз понимает.
// 2) Свои фразы: «когда я говорю спать, делай сценарий вечер».
object Aliases {

    private var file: File? = null
    private val words = LinkedHashMap<String, String>() // услышанное слово -> нужное слово
    private val phrases = LinkedHashMap<String, String>() // фраза -> команда

    private val customPrefixes = listOf(
        "когда я говорю", "когда я скажу", "если я говорю", "если я скажу", "запомни команду", "запомни фразу"
    )
    private val doSeparators = setOf("делай", "выполни", "сделай", "то")
    private val verbSeparators = setOf("запусти", "включи", "открой", "поставь", "позвони", "напиши", "прочитай", "отправь")
    private val correctionPrefixes = listOf(
        "нет я сказал", "нет я говорил", "я сказал", "я говорил", "не так я сказал", "нет не так я сказал"
    )

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "aliases.json")
        load()
    }

    @Synchronized
    private fun load() {
        words.clear()
        phrases.clear()
        val f = file ?: return
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            val w = root.optJSONObject("words")
            if (w != null) for (k in w.keys()) words[k] = w.getString(k)
            val p = root.optJSONObject("phrases")
            if (p != null) for (k in p.keys()) phrases[k] = p.getString(k)
            Diag.log("поправки", "Загружено: слов ${words.size}, фраз ${phrases.size}")
        } catch (e: Exception) {
            Diag.log("поправки", "Не удалось прочитать: ${e.message}")
        }
    }

    @Synchronized
    private fun save() {
        val f = file ?: return
        try {
            val root = JSONObject()
            val w = JSONObject()
            for ((k, v) in words) w.put(k, v)
            val p = JSONObject()
            for ((k, v) in phrases) p.put(k, v)
            root.put("words", w)
            root.put("phrases", p)
            f.writeText(root.toString())
        } catch (e: Exception) {
            Diag.log("поправки", "Не удалось сохранить: ${e.message}")
        }
    }

    // Применяет поправки: целая фраза или отдельные слова
    @Synchronized
    fun apply(text: String): String {
        val t = text.lowercase().trim()
        phrases[t]?.let { return it }
        if (words.isEmpty()) return t
        return t.split(" ").filter { it.isNotBlank() }.joinToString(" ") { words[it] ?: it }
    }

    @Synchronized
    fun count(): Int = words.size + phrases.size

    @Synchronized
    fun allWords(): Map<String, String> = LinkedHashMap(words)

    @Synchronized
    fun allPhrases(): Map<String, String> = LinkedHashMap(phrases)

    @Synchronized
    fun removeWord(k: String) {
        words.remove(k)
        save()
    }

    @Synchronized
    fun removePhrase(k: String) {
        phrases.remove(k)
        save()
    }

    @Synchronized
    fun clear() {
        words.clear()
        phrases.clear()
        save()
    }

    @Synchronized
    fun addWord(from: String, to: String) {
        if (from.isBlank() || to.isBlank() || from == to) return
        words[from] = to
        save()
    }

    @Synchronized
    fun addPhrase(from: String, to: String) {
        if (from.isBlank() || to.isBlank() || from == to) return
        phrases[from] = to
        save()
    }

    // Выучить поправку: услышано -> нужно
    fun learn(heard: String, intended: String) {
        val a = heard.lowercase().trim().split(" ").filter { it.isNotBlank() }
        val b = intended.lowercase().trim().split(" ").filter { it.isNotBlank() }
        if (a.isEmpty() || b.isEmpty() || a == b) return
        if (a.size == b.size) {
            val diffs = a.indices.filter { a[it] != b[it] }
            // слова должны быть похожи, иначе это не оговорка распознавания, а другая фраза
            val similar = diffs.all { Fuzzy.distance(a[it], b[it]) <= maxOf(3, b[it].length / 2) }
            if (diffs.size in 1..2 && similar) {
                for (i in diffs) addWord(a[i], b[i])
                Diag.log("поправки", "Запомнила поправку слова")
                Diag.inc("поправок выучено")
                return
            }
        }
        // длинные тексты (заметки, сообщения) целиком не запоминаем: это не оговорка распознавания
        if (a.size > 3 || b.size > 3) return
        addPhrase(a.joinToString(" "), b.joinToString(" "))
        Diag.log("поправки", "Запомнила фразу")
        Diag.inc("поправок выучено")
    }

    private fun strip(t: String, prefixes: List<String>): String? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t == p) return ""
            if (t.startsWith("$p ")) return t.removePrefix("$p ").trim()
        }
        return null
    }

    fun isKnown(t: String): Boolean =
        strip(t, customPrefixes) != null || strip(t, correctionPrefixes) != null ||
            t == "какие поправки" || t == "очисти поправки" || t == "забудь поправки" || t == "какие у меня фразы"

    fun handle(ctx: Context, t: String): Reply? {
        if (t == "какие поправки" || t == "какие у меня фразы") {
            val ph = allPhrases()
            val wd = allWords()
            if (ph.isEmpty() && wd.isEmpty()) return Reply("Поправок и своих фраз пока нет")
            val parts = ArrayList<String>()
            for ((k, v) in ph.entries.take(4)) parts.add("$k значит $v")
            for ((k, v) in wd.entries.take(4)) parts.add("слово $k значит $v")
            return Reply("Запомнила: " + parts.joinToString(". "))
        }
        if (t == "очисти поправки" || t == "забудь поправки") {
            return Reply("Забыть все поправки и свои фразы? Скажите да или нет.", Expect.YESNO) { s ->
                if (Secretary.isYes(s)) {
                    clear()
                    Reply("Забыла")
                } else {
                    Reply("Хорошо, оставляю")
                }
            }
        }

        // свои фразы: «когда я говорю спать делай сценарий вечер»
        val custom = strip(t, customPrefixes)
        if (custom != null) return createCustom(custom)

        // поправка: «нет, я сказал открой ютуб»
        val corr = strip(t, correctionPrefixes)
        if (corr != null) {
            if (corr.isBlank()) return Reply("Что вы хотели сказать?") { s -> applyCorrection(ctx, s.trim()) }
            return applyCorrection(ctx, corr)
        }
        return null
    }

    private fun createCustom(rest: String): Reply {
        val w = rest.split(" ").filter { it.isNotBlank() }
        var sep = -1
        var keepVerb = false
        for (i in 1 until w.size) {
            if (w[i] in doSeparators) { sep = i; break }
        }
        if (sep < 0) {
            for (i in 1 until w.size) {
                if (w[i] in verbSeparators) { sep = i; keepVerb = true; break }
            }
        }
        if (sep < 1) {
            return Reply("Не поняла. Скажите так: когда я говорю спать, делай сценарий вечер")
        }
        val phrase = w.take(sep).joinToString(" ")
        val command = (if (keepVerb) w.drop(sep) else w.drop(sep + 1)).joinToString(" ")
        if (command.isBlank()) return Reply("Что делать, когда вы говорите $phrase?")
        if (!Commands.isKnown(command)) {
            return Reply("Не поняла, что значит «$command». Скажите команду, которую я умею, например: запусти сценарий вечер")
        }
        addPhrase(phrase, command)
        Diag.inc("своих фраз создано")
        return Reply("Запомнила: когда вы говорите $phrase, я выполняю $command")
    }

    private fun applyCorrection(ctx: Context, intended: String): Reply {
        val heard = History.lastHeard
        if (heard.isNotBlank()) learn(heard, intended)
        val r = Commands.run(ctx, intended)
        val prefix = "Поняла, запомнила."
        val text = r.text
        return Reply(if (text.isNullOrBlank()) prefix else "$prefix $text", r.expect, r.followUp)
    }
}
