package com.luna.assistant

import android.content.Context

// Включение и выключение возможностей секретаря (экран «Секретарь» → «Возможности»)
object Features {

    val all = listOf(
        "notes" to "Заметки",
        "events" to "События и напоминания",
        "alarms" to "Таймеры и будильники",
        "scenarios" to "Сценарии",
        "messenger" to "Ответы в мессенджерах",
        "device" to "Управление телефоном, уведомления, музыка",
        "phone" to "Звонки и SMS"
    )

    fun on(key: String): Boolean =
        LunaApp.ctx?.getSharedPreferences("luna", Context.MODE_PRIVATE)?.getBoolean("feat_$key", true) ?: true

    // Настройка со своим значением по умолчанию (например, громкая связь по умолчанию выключена)
    fun onOr(key: String, default: Boolean): Boolean =
        LunaApp.ctx?.getSharedPreferences("luna", Context.MODE_PRIVATE)?.getBoolean("feat_$key", default) ?: default

    fun set(ctx: Context, key: String, value: Boolean) {
        ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).edit().putBoolean("feat_$key", value).apply()
        Diag.log("настройки", "Возможность «$key» ${if (value) "включена" else "выключена"}")
    }
}
