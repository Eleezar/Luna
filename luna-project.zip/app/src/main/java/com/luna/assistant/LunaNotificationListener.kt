package com.luna.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Чтение уведомлений других приложений: «Луна, прочитай уведомления»
class LunaNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: LunaNotificationListener? = null
    }

    override fun onListenerConnected() {
        instance = this
        Diag.set("Чтение уведомлений", "включено")
        Diag.log("уведомления", "Доступ к уведомлениям подключён")
    }

    override fun onListenerDisconnected() {
        instance = null
        Diag.set("Чтение уведомлений", "отключено")
        Diag.log("уведомления", "Доступ к уведомлениям отключён")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            NotifStore.add(this, sbn)
        } catch (e: Exception) {
            Diag.log("уведомления", "Не удалось разобрать уведомление: ${e.message}")
        }
    }
}
