package com.luna.assistant

// Ответ Луны: что сказать вслух и (необязательно) что делать с ответом пользователя на её вопрос
class Reply(val text: String?, val followUp: ((String) -> Reply)? = null)
