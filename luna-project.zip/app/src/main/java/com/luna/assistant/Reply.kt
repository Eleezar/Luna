package com.luna.assistant

// Что Луна ждёт в ответ на свой вопрос: от этого зависит, какой словарь включить для офлайн-распознавания
enum class Expect { FREE, TIME, DATETIME, YESNO }

// Ответ Луны: что сказать вслух и (необязательно) что делать с ответом пользователя на её вопрос
class Reply(
    val text: String?,
    val expect: Expect = Expect.FREE,
    val followUp: ((String) -> Reply)? = null
)
