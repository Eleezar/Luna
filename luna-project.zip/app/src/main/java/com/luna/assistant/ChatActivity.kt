package com.luna.assistant

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Разговор с Луной: что вы сказали, что она поняла и ответила. Можно печатать команды вместо голоса.
class ChatActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var speakBox: CheckBox
    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var shown = -1

    private val tick = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 1500)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(24), dp(12), dp(4))
            addView(
                TextView(ctx).apply {
                    text = "Разговор с Луной"
                    textSize = 18f
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(Button(ctx).apply {
                text = "Очистить"
                isAllCaps = false
                textSize = 12f
                setOnClickListener {
                    ChatLog.clear()
                    refresh(true)
                }
            })
        }

        list = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        scroll = ScrollView(ctx).apply { addView(list) }

        input = EditText(ctx).apply {
            hint = "Напишите команду, например: поставь таймер на пять минут"
            maxLines = 3
        }
        val send = Button(ctx).apply {
            text = "Отправить"
            isAllCaps = false
            setOnClickListener { send() }
        }
        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(4), dp(8), 0)
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(send)
        }
        speakBox = CheckBox(ctx).apply {
            text = "Озвучивать ответы"
            isChecked = true
            setPadding(dp(8), 0, dp(8), dp(8))
        }

        setContentView(LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(top)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bottom)
            addView(speakBox)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh(true)
        handler.postDelayed(tick, 1500)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (VoiceService.submit(text, speakBox.isChecked)) {
            input.setText("")
            handler.postDelayed({ refresh(true) }, 400)
        } else {
            Toast.makeText(this, "Луна не запущена. Нажмите «Запустить Луну» на главном экране.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh(force: Boolean) {
        val all = ChatLog.all()
        if (!force && all.size == shown) return
        shown = all.size
        list.removeAllViews()
        if (all.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Здесь появятся ваши команды и ответы Луны. Можно писать команды вручную внизу."
                textSize = 14f
                setPadding(dp(8), dp(16), dp(8), dp(8))
            })
        }
        for (e in all) list.addView(bubble(e))
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun bubble(e: ChatLog.Entry): LinearLayout {
        val mine = e.who == "you"
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(if (mine) Color.parseColor("#DCEBFF") else Color.parseColor("#EEEEEE"))
        }
        val tv = TextView(this).apply {
            text = (if (mine) "Вы: " else "Луна: ") + e.text +
                (if (e.note.isNotBlank()) "\n(${e.note})" else "") +
                "\n" + timeFmt.format(Date(e.time))
            textSize = 15f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = bg
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (mine) Gravity.END else Gravity.START
            setPadding(0, dp(4), 0, dp(4))
            addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }
}
