package com.luna.assistant

import android.app.Application

class LunaApp : Application() {

    companion object {
        @Volatile
        var ctx: android.content.Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        Diag.init(this)
        Store.init(this)
        Aliases.init(this)
        // Любой вылет приложения записывается в диагностику
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            Diag.crash(thread, error)
            previous?.uncaughtException(thread, error)
        }
    }
}
