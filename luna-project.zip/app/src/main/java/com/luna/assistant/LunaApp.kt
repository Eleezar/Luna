package com.luna.assistant

import android.app.Application

class LunaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Diag.init(this)
        // Любой вылет приложения записывается в диагностику
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            Diag.crash(thread, error)
            previous?.uncaughtException(thread, error)
        }
    }
}
