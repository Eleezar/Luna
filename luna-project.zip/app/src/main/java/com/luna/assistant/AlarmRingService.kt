package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

// Звонок будильника и таймера: мелодия по кругу и вибрация до 60 секунд, кнопки «Выключить» и «Ещё 5 минут»
class AlarmRingService : Service() {

    companion object {
        @Volatile
        var ringing = false

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmRingService::class.java).setAction(Alarms.ACTION_STOP))
        }

        fun snooze(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmRingService::class.java).setAction(Alarms.ACTION_SNOOZE))
        }
    }

    private var player: MediaPlayer? = null
    private var label = ""
    private var kind = "alarm"
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable {
        Diag.log("будильник", "Звонок остановлен автоматически через 60 секунд")
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Alarms.ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            Alarms.ACTION_SNOOZE -> {
                Alarms.snooze(this, label)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        label = intent?.getStringExtra("label") ?: ""
        kind = intent?.getStringExtra("kind") ?: "alarm"

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna_alarm", "Будильники и таймеры Луны", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
            }
        )
        startForeground(
            3,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        ringing = true
        startSound()
        startVibration()
        handler.removeCallbacks(autoStop)
        handler.postDelayed(autoStop, 60_000)
        Diag.log("будильник", "Звонок запущен ($kind)")
        return START_NOT_STICKY
    }

    private fun action(act: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code, Intent(this, AlarmRingService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildNotification(): Notification {
        val title = if (kind == "timer") "Таймер сработал" else "Будильник"
        return Notification.Builder(this, "luna_alarm")
            .setContentTitle(title)
            .setContentText(label)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Выключить", action(Alarms.ACTION_STOP, 1)).build())
            .addAction(Notification.Action.Builder(null, "Ещё 5 минут", action(Alarms.ACTION_SNOOZE, 2)).build())
            .build()
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            Diag.log("будильник", "Не удалось включить мелодию: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun startVibration() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        } catch (e: Exception) {
            Diag.log("будильник", "Вибрация недоступна: ${e.message}")
        }
    }

    override fun onDestroy() {
        ringing = false
        handler.removeCallbacks(autoStop)
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        try { getSystemService(Vibrator::class.java)?.cancel() } catch (e: Exception) { }
        Diag.log("будильник", "Звонок остановлен")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
