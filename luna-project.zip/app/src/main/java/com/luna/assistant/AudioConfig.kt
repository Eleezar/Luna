package com.luna.assistant

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaRecorder

// Выбор источника звука и устройства ввода (микрофон телефона, проводная или Bluetooth-гарнитура, USB-микрофон)
object AudioConfig {

    val sources = listOf(
        "auto" to "Авто: VOICE_RECOGNITION (стандартный)",
        "mic" to "MIC: обычный микрофон",
        "comm" to "VOICE_COMMUNICATION: как при разговоре по громкой связи",
        "camcorder" to "CAMCORDER: микрофон видеокамеры",
        "unprocessed" to "UNPROCESSED: без обработки звука"
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE)

    fun sourceKey(ctx: Context): String = prefs(ctx).getString("mic_source", "auto") ?: "auto"

    fun deviceKey(ctx: Context): String = prefs(ctx).getString("mic_device", "") ?: ""

    fun save(ctx: Context, source: String? = null, device: String? = null) {
        val e = prefs(ctx).edit()
        if (source != null) e.putString("mic_source", source)
        if (device != null) e.putString("mic_device", device)
        e.apply()
    }

    fun sourceId(key: String): Int = when (key) {
        "mic" -> MediaRecorder.AudioSource.MIC
        "comm" -> MediaRecorder.AudioSource.VOICE_COMMUNICATION
        "camcorder" -> MediaRecorder.AudioSource.CAMCORDER
        "unprocessed" -> MediaRecorder.AudioSource.UNPROCESSED
        else -> MediaRecorder.AudioSource.VOICE_RECOGNITION
    }

    // Выбран ли не стандартный источник или конкретное устройство
    fun isCustom(ctx: Context): Boolean = sourceKey(ctx) != "auto" || deviceKey(ctx).isNotEmpty()

    fun keyOf(d: AudioDeviceInfo): String = "${d.type}|${d.productName}"

    fun inputs(ctx: Context): List<AudioDeviceInfo> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
    }

    fun findDevice(ctx: Context, key: String): AudioDeviceInfo? {
        if (key.isEmpty()) return null
        return inputs(ctx).firstOrNull { keyOf(it) == key }
    }

    fun describe(ctx: Context): String {
        val src = sources.firstOrNull { it.first == sourceKey(ctx) }?.second ?: "авто"
        val dk = deviceKey(ctx)
        val dev = if (dk.isEmpty()) "стандартное" else (findDevice(ctx, dk)?.let { Diag.deviceName(it) } ?: "выбранное не подключено")
        return "$src; устройство: $dev"
    }
}
