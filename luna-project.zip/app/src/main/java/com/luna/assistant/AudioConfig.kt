package com.luna.assistant

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaRecorder

// Выбор источника звука и устройства ввода (микрофон телефона, проводная или Bluetooth-гарнитура, USB-микрофон)
object AudioConfig {

    val sources = listOf(
        "auto" to "Авто: VOICE_RECOGNITION (стандартный)",
        "mic" to "MIC: обычный микрофон",
        "comm" to "VOICE_COMMUNICATION: как при разговоре по громкой связи",
        "camcorder" to "CAMCORDER: микрофон видеокамеры",
        "unprocessed" to "UNPROCESSED: без обработки звука"
    )

    val musicPolicies = listOf(
        "pause" to "Слушание на паузе, пока играет музыка (звук чистый, рекомендую)",
        "phone" to "Слушать микрофоном телефона, пока играет музыка (звук чистый, если микрофон работает)",
        "keep" to "Слушать через гарнитуру всегда (звук музыки хуже)"
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE)

    // Автовыбор: Луна сама подбирает микрофон. Включён по умолчанию
    fun autoOn(ctx: Context): Boolean = prefs(ctx).getBoolean("mic_auto", true)

    fun setAuto(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("mic_auto", v).apply()

    // Ручной выбор из настроек
    fun manualSourceKey(ctx: Context): String = prefs(ctx).getString("mic_source", "auto") ?: "auto"

    fun manualDeviceKey(ctx: Context): String = prefs(ctx).getString("mic_device", "") ?: ""

    // То, чем Луна пользуется на самом деле: выбор Луны при автовыборе или ручной выбор
    fun sourceKey(ctx: Context): String = if (autoOn(ctx)) AutoMic.chosenSource(ctx) else manualSourceKey(ctx)

    fun deviceKey(ctx: Context): String = if (autoOn(ctx)) AutoMic.chosenDevice(ctx) else manualDeviceKey(ctx)

    fun save(ctx: Context, source: String? = null, device: String? = null) {
        val e = prefs(ctx).edit()
        if (source != null) e.putString("mic_source", source)
        if (device != null) e.putString("mic_device", device)
        e.apply()
    }

    fun sourceId(key: String): Int = when (key) {
        "mic" -> MediaRecorder.AudioSource.MIC
        "comm" -> MediaRecorder.AudioSource.VOICE_COMMUNICATION
        "camcorder" -> MediaRecorder.AudioSource.CAMCORDER
        "unprocessed" -> MediaRecorder.AudioSource.UNPROCESSED
        else -> MediaRecorder.AudioSource.VOICE_RECOGNITION
    }

    // Выбран ли не стандартный источник или конкретное устройство
    fun isCustom(ctx: Context): Boolean = sourceKey(ctx) != "auto" || deviceKey(ctx).isNotEmpty()

    // Что делать, когда играет музыка, а микрофоном служит Bluetooth-гарнитура
    fun musicPolicy(ctx: Context): String = prefs(ctx).getString("bt_music", "pause") ?: "pause"

    fun setMusicPolicy(ctx: Context, v: String) {
        prefs(ctx).edit().putString("bt_music", v).apply()
    }

    fun builtinMic(ctx: Context): AudioDeviceInfo? =
        inputs(ctx).firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }

    fun keyOf(d: AudioDeviceInfo): String = "${d.type}|${d.productName}"

    fun inputs(ctx: Context): List<AudioDeviceInfo> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
    }

    fun findDevice(ctx: Context, key: String): AudioDeviceInfo? {
        if (key.isEmpty()) return null
        return inputs(ctx).firstOrNull { keyOf(it) == key }
    }

    fun describe(ctx: Context): String {
        val src = sources.firstOrNull { it.first == sourceKey(ctx) }?.second ?: "авто"
        val dk = deviceKey(ctx)
        val dev = if (dk.isEmpty()) "стандартное" else (findDevice(ctx, dk)?.let { Diag.deviceName(it) } ?: "выбранное не подключено")
        return (if (autoOn(ctx)) "авто: " else "") + "$src; устройство: $dev"
    }
}
