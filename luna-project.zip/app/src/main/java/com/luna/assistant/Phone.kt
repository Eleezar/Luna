package com.luna.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager

// Звонки и SMS голосом: «позвони маме», «отправь смс Ивану буду через час», «ответь», «сбрось», «громкая связь».
// Перед набором и отправкой Луна всегда переспрашивает: «Да или нет».
object Phone {

    private val callVerbs = listOf("позвони", "набери", "вызови")
    private val speakerPhrases = listOf("на громкой связи", "по громкой связи", "на громкой", "по громкой", "на громкую", "по громкую")
    private val answerPhrases = setOf(
        "возьми трубку", "прими звонок", "принять звонок", "ответь на звонок", "ответить на звонок", "прими", "возьми"
    )
    private val hangPhrases = setOf(
        "сбрось", "сбросить", "сбрось звонок", "отклони", "отклони звонок", "отклонить звонок", "не отвечай",
        "положи трубку", "повесь трубку", "заверши звонок", "завершить звонок", "закончи звонок", "отбой"
    )
    private val speakerOnPhrases = setOf(
        "громкая связь", "громкую связь", "включи громкую связь", "включи громкую", "включи динамик", "на громкую связь"
    )
    private val speakerOffPhrases = setOf("выключи громкую связь", "выключи динамик", "убери громкую связь", "отключи громкую связь")
    private val smsMarkers = setOf("смс", "эсэмэс", "sms", "ммс", "mms", "сообщение", "сообщения")

    private class Sms(val mms: Boolean, val rest: String)

    private fun has(ctx: Context, perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ---------- разбор ----------

    private fun parseSms(t: String): Sms? {
        val w = t.split(" ").filter { it.isNotBlank() }
        if (w.isEmpty()) return null
        var i = 0
        val first = w[0]
        if (first in setOf("отправь", "напиши", "пошли", "отправить", "послать")) {
            i = 1
        } else if (first !in smsMarkers) {
            return null
        }
        var mms = false
        var marker = false
        while (i < w.size && w[i] in smsMarkers) {
            if (w[i] == "ммс" || w[i] == "mms") mms = true
            marker = true
            i++
        }
        if (!marker) return null
        return Sms(mms, w.drop(i).joinToString(" "))
    }

    private fun callVerb(t: String): String? = callVerbs.firstOrNull { t == it || t.startsWith("$it ") }

    fun isKnown(t: String): Boolean {
        if (!Features.on("phone")) return false
        return callVerb(t) != null || parseSms(t) != null || isControl(t)
    }

    // SMS диктуется длинной фразой
    fun isDictation(t: String): Boolean = Features.on("phone") && parseSms(t) != null

    private fun isControl(t: String): Boolean =
        t in answerPhrases || t in hangPhrases || t in speakerOnPhrases || t in speakerOffPhrases

    // ---------- управление текущим звонком ----------

    fun control(ctx: Context, t: String): Reply? {
        if (!Features.on("phone")) return null
        val ringing = CallMonitor.state == TelephonyManager.CALL_STATE_RINGING
        if (t in answerPhrases || (t == "ответь" && ringing) || t == "ответь на звонок") return answer(ctx)
        if (t in hangPhrases) return hangUp(ctx)
        if (t in speakerOnPhrases) return speakerReply(ctx, true)
        if (t in speakerOffPhrases) return speakerReply(ctx, false)
        return null
    }

    private fun telecom(ctx: Context): TelecomManager = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

    private fun answer(ctx: Context): Reply {
        if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return Reply("Нет разрешения на управление звонками. Разрешите на главном экране.")
        return try {
            telecom(ctx).acceptRingingCall()
            Diag.inc("звонков принято голосом")
            Reply("Отвечаю")
        } catch (e: Exception) {
            Diag.log("звонки", "Не удалось ответить: ${e.javaClass.simpleName}: ${e.message}")
            Reply("Не получилось ответить")
        }
    }

    private fun hangUp(ctx: Context): Reply {
        if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return Reply("Нет разрешения на управление звонками. Разрешите на главном экране.")
        return try {
            val ok = if (Build.VERSION.SDK_INT >= 28) telecom(ctx).endCall() else false
            Diag.inc("звонков завершено голосом")
            if (ok) Reply("Готово") else Reply("Сейчас нет звонка")
        } catch (e: Exception) {
            Diag.log("звонки", "Не удалось завершить: ${e.javaClass.simpleName}: ${e.message}")
            Reply("Не получилось завершить звонок")
        }
    }

    // Ответ на вопрос «Звонит … Ответить?»
    fun answerOrReject(ctx: Context, s: String): Reply {
        val w = s.lowercase().split(" ")
        val reject = w.any { it in setOf("нет", "сбрось", "сбросить", "отклони", "отклонить") }
        val accept = w.any { it in setOf("да", "ответь", "ответить", "принять", "возьми", "давай", "ага") }
        return when {
            reject -> hangUp(ctx)
            accept -> answer(ctx)
            else -> Reply("Хорошо")
        }
    }

    fun setSpeaker(ctx: Context, on: Boolean): Boolean {
        try {
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isSpeakerphoneOn = on
        } catch (e: Exception) {
            Diag.log("звонки", "Громкая связь через систему: ${e.message}")
        }
        val svc = LunaAccessibilityService.instance ?: return false
        val ok = svc.setToggle(listOf("громкая связь", "динамик", "speaker", "громкоговоритель"), on)
        Diag.log("звонки", "Громкая связь ${if (on) "включить" else "выключить"}: ${if (ok) "готово" else "кнопка не найдена"}")
        return ok
    }

    private fun speakerReply(ctx: Context, on: Boolean): Reply {
        val ok = setSpeaker(ctx, on)
        return if (ok) Reply(if (on) "Громкая связь включена" else "Громкая связь выключена")
        else Reply("Не нашла кнопку громкой связи. Нажмите вручную или включите службу доступности")
    }

    // ---------- выбор контакта ----------

    private fun resolveContact(ctx: Context, spoken: String, onPicked: (Contacts.Contact) -> Reply): Reply {
        if (!Contacts.hasPermission(ctx)) return Reply("Нет доступа к контактам. Разрешите на главном экране.")
        val found = Contacts.find(ctx, spoken)
        return when {
            found.isEmpty() -> Reply("Не нашла в контактах: $spoken")
            found.size == 1 -> onPicked(found[0])
            else -> chooseContact(found, 0, onPicked)
        }
    }

    private fun chooseContact(list: List<Contacts.Contact>, tries: Int, onPicked: (Contacts.Contact) -> Reply): Reply {
        val names = list.take(4).joinToString(", ") { it.name }
        return Reply("Нашла несколько: $names. Кого?") { s ->
            val stems = s.lowercase().split(" ").filter { it.isNotBlank() }.map { Messenger.stem(it) }
            val narrowed = list.filter { c -> stems.isNotEmpty() && stems.all { st -> Messenger.sharesStem(c.name, st) } }
            when {
                narrowed.size == 1 -> onPicked(narrowed[0])
                narrowed.isEmpty() || tries >= 2 -> Reply("Не поняла, кого выбрать")
                else -> chooseContact(narrowed, tries + 1, onPicked)
            }
        }
    }

    // ---------- звонок ----------

    fun handle(ctx: Context, t: String): Reply? {
        if (!Features.on("phone")) return null
        val cv = callVerb(t)
        if (cv != null) {
            Diag.inc("команд звонков")
            return startCall(ctx, t.removePrefix(cv).trim())
        }
        val sms = parseSms(t)
        if (sms != null) {
            Diag.inc("команд SMS")
            return startSms(ctx, sms)
        }
        return null
    }

    private fun startCall(ctx: Context, rest: String): Reply {
        var text = rest
        var speaker = false
        for (p in speakerPhrases) {
            if (text.contains(p)) {
                speaker = true
                text = text.replace(p, " ")
            }
        }
        text = text.trim().replace(Regex("""\s+"""), " ")
        if (text.isEmpty()) return Reply("Кому позвонить?") { s -> resolveCall(ctx, s.trim(), speaker) }
        return resolveCall(ctx, text, speaker)
    }

    private fun resolveCall(ctx: Context, spoken: String, speaker: Boolean): Reply {
        val w = spoken.split(" ").filter { it.isNotBlank() }
        // «на номер восемь девятьсот …»
        val numberWords = if (w.firstOrNull() == "номер") w.drop(1) else if (w.take(2) == listOf("на", "номер")) w.drop(2) else null
        if (numberWords != null) {
            val digits = digitsFromWords(numberWords.joinToString(" "))
            if (digits.length < 3) return Reply("Не поняла номер")
            return confirmCall(ctx, digits.chunked(3).joinToString(" "), digits, speaker)
        }
        return resolveContact(ctx, spoken) { c -> confirmCall(ctx, c.name, c.number, speaker) }
    }

    private fun confirmCall(ctx: Context, label: String, number: String, speaker: Boolean): Reply =
        Reply("Позвонить $label${if (speaker) " по громкой связи" else ""}? Скажите да или нет.", Expect.YESNO) { s ->
            if (Secretary.isYes(s)) placeCall(ctx, label, number, speaker) else Reply("Отменила")
        }

    private fun placeCall(ctx: Context, label: String, number: String, speaker: Boolean): Reply {
        val uri = Uri.parse("tel:" + Uri.encode(number))
        if (has(ctx, Manifest.permission.CALL_PHONE)) {
            try {
                val extras = Bundle()
                if (speaker || Features.onOr("call_speaker", false)) {
                    extras.putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, true)
                }
                telecom(ctx).placeCall(uri, extras)
                Diag.inc("звонков набрано")
                Diag.log("звонки", "Звонок набран голосом")
                return Reply("Звоню $label")
            } catch (e: Exception) {
                Diag.log("звонки", "Не удалось набрать: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        // без разрешения: открываем набор номера, вызов нажмёте сами
        return try {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Reply("Открываю набор номера. Нажмите вызов")
        } catch (e: Exception) {
            Reply("Не получилось позвонить")
        }
    }

    // ---------- SMS и MMS ----------

    private fun startSms(ctx: Context, sms: Sms): Reply {
        if (sms.rest.isBlank()) return Reply("Кому написать?") { s -> smsTarget(ctx, sms.mms, s.trim()) }
        return smsTarget(ctx, sms.mms, sms.rest)
    }

    private fun smsTarget(ctx: Context, mms: Boolean, rest: String): Reply {
        val w = rest.split(" ").filter { it.isNotBlank() }
        if (w.isEmpty()) return Reply("Не поняла, кому")
        var name = w[0]
        var textWords = w.drop(1)
        // имя из двух слов («Иван Петров»), если такой контакт есть
        if (w.size >= 2 && Contacts.hasPermission(ctx) && Contacts.find(ctx, w.take(2).joinToString(" ")).isNotEmpty()) {
            name = w.take(2).joinToString(" ")
            textWords = w.drop(2)
        }
        val text = textWords.joinToString(" ")
        return resolveContact(ctx, name) { c ->
            if (text.isBlank()) {
                Reply("Что написать ${c.name}?") { s -> smsConfirm(ctx, c, s.trim(), mms) }
            } else {
                smsConfirm(ctx, c, text, mms)
            }
        }
    }

    private fun smsConfirm(ctx: Context, c: Contacts.Contact, text: String, mms: Boolean): Reply =
        Reply("Отправить ${if (mms) "ММС" else "смс"} ${c.name}: $text. Скажите да или нет.", Expect.YESNO) { s ->
            if (Secretary.isYes(s)) sendSms(ctx, c, text, mms) else Reply("Отменила")
        }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun openCompose(ctx: Context, c: Contacts.Contact, text: String): Boolean = try {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.number)))
            .putExtra("sms_body", text)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    private fun sendSms(ctx: Context, c: Contacts.Contact, text: String, mms: Boolean): Reply {
        // ММС приложение отправить само не может: открываем сообщения, файл прикрепляет человек
        if (mms) {
            return if (openCompose(ctx, c, text)) Reply("Открываю сообщения. Прикрепите файл и отправьте")
            else Reply("Не получилось открыть сообщения")
        }
        if (has(ctx, Manifest.permission.SEND_SMS)) {
            try {
                val sm = smsManager(ctx)
                val parts = sm.divideMessage(text)
                sm.sendMultipartTextMessage(c.number, null, parts, null, null)
                Diag.inc("SMS отправлено")
                Diag.log("звонки", "SMS отправлено голосом")
                return Reply("Отправила смс")
            } catch (e: Exception) {
                Diag.log("звонки", "SMS не отправлено: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        // нет разрешения на SMS: открываем сообщения с готовым текстом и пробуем нажать «Отправить»
        if (openCompose(ctx, c, text)) {
            Handler(Looper.getMainLooper()).postDelayed({
                val svc = LunaAccessibilityService.instance
                val ok = svc != null && listOf("отправить", "send").any { svc.clickText(it) }
                Diag.log("звонки", "SMS через приложение сообщений: ${if (ok) "кнопка нажата" else "кнопку нажмите сами"}")
            }, 2000)
            return Reply("Нет разрешения на смс. Открываю сообщения")
        }
        return Reply("Не получилось отправить смс")
    }

    // ---------- номер из слов ----------

    private val hundreds = mapOf(
        "сто" to 100, "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500,
        "шестьсот" to 600, "семьсот" to 700, "восемьсот" to 800, "девятьсот" to 900
    )
    private val teens = mapOf(
        "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13, "четырнадцать" to 14,
        "пятнадцать" to 15, "шестнадцать" to 16, "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19
    )
    private val tens = mapOf(
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90
    )
    private val ones = mapOf(
        "ноль" to 0, "один" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9
    )

    // «восемь девятьсот двенадцать триста сорок пять шестьдесят семь восемьдесят девять» -> 89123456789
    // Числа, сказанные группами, склеиваются без разделителей. Цифры (от Google) берутся как есть.
    fun digitsFromWords(text: String): String {
        val out = StringBuilder()
        var stage = 0 // 0: ничего, 1: сотни, 2: десятки или «-надцать», 3: единицы
        var group = StringBuilder()
        fun flush() {
            if (group.isNotEmpty()) out.append(group)
            group = StringBuilder()
            stage = 0
        }
        for (raw in text.lowercase().split(" ").filter { it.isNotBlank() }) {
            if (raw.all { it.isDigit() }) {
                flush()
                out.append(raw)
                continue
            }
            val h = hundreds[raw]
            val tn = teens[raw]
            val t = tens[raw]
            val o = ones[raw]
            when {
                h != null -> {
                    flush()
                    group.append(h)
                    stage = 1
                }
                tn != null -> {
                    if (stage > 1) flush()
                    if (stage == 1) {
                        // «девятьсот двенадцать»: 900 + 12 = 912
                        val base = group.toString().toInt()
                        group = StringBuilder().append(base + tn)
                    } else {
                        group.append(tn)
                    }
                    stage = 3
                }
                t != null -> {
                    if (stage > 1) flush()
                    if (stage == 1) {
                        val base = group.toString().toInt()
                        group = StringBuilder().append(base + t)
                    } else {
                        group.append(t)
                    }
                    stage = 2
                }
                o != null -> {
                    if (o == 0) {
                        flush()
                        out.append('0')
                    } else if (stage == 2 || stage == 1) {
                        val base = group.toString().toInt()
                        group = StringBuilder().append(base + o)
                        stage = 3
                    } else {
                        flush()
                        group.append(o)
                        stage = 3
                    }
                }
            }
        }
        flush()
        return out.toString()
    }
}
