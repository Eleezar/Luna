package com.luna.assistant

// Исправляет типичные ошибки распознавания: «открой ютуп» -> «открой ютуб», «запеши» -> «запиши»
object Fuzzy {

    private val verbs = listOf(
        "открой", "запусти", "включи", "запиши", "напомни", "запланируй", "добавь", "создай", "удали",
        "прочитай", "прочти", "покажи", "сколько", "посчитай", "вычисли", "реши", "громче", "тише",
        "домой", "громкость", "назначь", "сверни", "сделай", "поставь",
        "нажми", "кликни", "прокрути", "листай", "пролистай", "напиши", "отправь", "заблокируй", "вернись", "назад", "очисти"
    )
    private val openVerbs = setOf("открой", "запусти", "включи")

    fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    // Ближайшее слово из списка; null, если нет или есть два одинаково близких
    private fun nearest(word: String, candidates: Collection<String>, maxDist: Int): String? {
        var best: String? = null
        var bestD = Int.MAX_VALUE
        var tie = false
        for (c in candidates) {
            val d = distance(word, c)
            if (d < bestD) {
                bestD = d
                best = c
                tie = false
            } else if (d == bestD) {
                tie = true
            }
        }
        return if (best != null && bestD <= maxDist && !tie) best else null
    }

    fun fixCommand(text: String): String {
        val w = text.split(" ").filter { it.isNotBlank() }.toMutableList()
        if (w.isEmpty()) return text
        if (w[0] !in verbs) {
            val v = nearest(w[0], verbs, if (w[0].length >= 6) 2 else 1)
            if (v != null) w[0] = v
        }
        if (w[0] in openVerbs && w.size >= 2) {
            val name = w.drop(1).joinToString(" ")
            val names = Commands.knownNames()
            if (name !in names) {
                val n = nearest(name, names, if (name.length >= 6) 2 else 1)
                if (n != null) return w[0] + " " + n
            }
        }
        return w.joinToString(" ")
    }
}
