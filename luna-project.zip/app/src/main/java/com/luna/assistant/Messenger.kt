package com.luna.assistant

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle

// Ответы в мессенджерах голосом.
// 1) «ответь Ивану буду через час»: ответ через кнопку «Ответить» в уведомлении (Telegram, WhatsApp, Viber, SMS и др.)
// 2) «напиши в телеграм Ивану привет»: Луна открывает приложение, находит чат и отправляет (служба доступности)
// Перед отправкой Луна всегда переспрашивает: «Отправить? Да или нет».
object Messenger {

    private val messengers = mapOf(
        "телеграм" to "telegram", "телеграмм" to "telegram", "telegram" to "telegram",
        "ватсап" to "whatsapp", "вотсап" to "whatsapp", "whatsapp" to "whatsapp",
        "вайбер" to "viber", "viber" to "viber",
        "вк" to "vk", "вконтакте" to "vk"
    )

    private data class Parsed(
        val verb: String,
        val appSpoken: String?,
        val appNeedle: String?,
        val name: String?,
        val text: String,
        val latest: Boolean
    )

    fun norm(s: String): String = s.lowercase().replace('ё', 'е')

    // «ивану» -> «ива», «маме» -> «мам»: начало слова, по которому находим имя в любом падеже
    fun stem(word: String): String {
        val w = norm(word)
        return when {
            w.length >= 5 -> w.dropLast(2)
            w.length == 4 -> w.dropLast(1)
            else -> w
        }
    }

    fun sharesStem(label: String, stem: String): Boolean {
        if (stem.isEmpty()) return false
        return norm(label).split(Regex("""[\s,.:;!?()"«»\-]+""")).any { it.startsWith(stem) }
    }

    private fun parse(t: String): Parsed? {
        val w = t.split(" ").filter { it.isNotBlank() }
        val verb = w.getOrNull(0) ?: return null
        if (verb != "ответь" && verb != "напиши" && verb != "отправь") return null
        var i = 1
        if (w.getOrNull(i) == "сообщение") i++
        var appSpoken: String? = null
        var needle: String? = null
        val inWord = w.getOrNull(i)
        if ((inWord == "в" || inWord == "во") && w.getOrNull(i + 1) != null) {
            val n = messengers[w[i + 1]]
            if (n != null) {
                appSpoken = w[i + 1]
                needle = n
                i += 2
            }
        }
        var latest = false
        var name: String? = null
        if (verb == "ответь") {
            val a = w.getOrNull(i)
            val b = w.getOrNull(i + 1)
            if (a == "на" && (b == "последнее" || b == "последний")) {
                latest = true
                i += 2
                if (w.getOrNull(i) == "сообщение") i++
            } else if (a == "им" || a == "ему" || a == "ей") {
                latest = true
                i++
            } else if (a != null) {
                name = a
                i++
            }
        } else {
            if (appSpoken == null) return null // «напиши привет» без мессенджера: это ввод текста в поле
            name = w.getOrNull(i)
            if (name != null) i++
        }
        val text = w.drop(i).joinToString(" ")
        return Parsed(verb, appSpoken, needle, name, text, latest)
    }

    fun isKnown(t: String): Boolean = parse(t) != null

    fun isDictation(t: String): Boolean = parse(t) != null

    fun handle(ctx: Context, t: String): Reply? {
        val p = parse(t) ?: return null
        Diag.inc("команд сообщений")
        if (p.name == null && !p.latest) {
            return Reply("Кому?") { s ->
                val w = s.trim().split(" ").filter { it.isNotBlank() }
                if (w.isEmpty()) Reply("Не поняла") else resolve(ctx, p.copy(name = w[0], text = w.drop(1).joinToString(" ")))
            }
        }
        return resolve(ctx, p)
    }

    private fun who(p: Parsed): String = p.name ?: "последнему отправителю"

    private fun resolve(ctx: Context, p: Parsed): Reply {
        if (p.text.isBlank()) {
            return Reply("Что написать ${who(p)}?") { s -> prepare(ctx, p.copy(text = s.trim())) }
        }
        return prepare(ctx, p)
    }

    private fun findTarget(p: Parsed): NotifStore.Item? {
        val stem = p.name?.let { stem(it) }
        return NotifStore.replyable().firstOrNull { item ->
            val appOk = p.appNeedle == null ||
                norm(item.app).contains(p.appNeedle) || norm(item.pkg).contains(p.appNeedle)
            val nameOk = p.latest || (stem != null && sharesStem(item.title, stem))
            appOk && nameOk
        }
    }

    private fun prepare(ctx: Context, p: Parsed): Reply {
        if (p.text.isBlank()) return Reply("Не поняла текст")
        val item = findTarget(p)
        if (item != null) {
            Diag.log("сообщения", "Найдено уведомление для ответа в приложении ${item.app}")
            return Reply("Отправить ${item.title} в ${item.app}: ${p.text}. Скажите да или нет.", Expect.YESNO) { s ->
                if (Secretary.isYes(s)) sendReply(ctx, item, p.text) else Reply("Отменила")
            }
        }
        if (p.appSpoken != null && p.appNeedle != null && p.name != null) {
            if (LunaAccessibilityService.instance == null) {
                return Reply("Включите службу доступности для Луны: на главном экране кнопка «Служба доступности»")
            }
            return Reply("Отправить ${p.name} в ${p.appSpoken}: ${p.text}. Скажите да или нет.", Expect.YESNO) { s ->
                if (Secretary.isYes(s)) {
                    uiFlow(ctx, p.appNeedle, p.appSpoken, p.name, p.text)
                    Reply("Пишу ${p.name} в ${p.appSpoken}")
                } else {
                    Reply("Отменила")
                }
            }
        }
        Diag.log("сообщения", "Нет свежего уведомления для ответа")
        return Reply("Нет свежего сообщения, на которое можно ответить. Скажите: напиши в телеграм, имя и текст.")
    }

    // Ответ через кнопку «Ответить» в уведомлении
    private fun sendReply(ctx: Context, item: NotifStore.Item, text: String): Reply {
        val action = item.replyAction
            ?: return Reply("Это уведомление уже закрыто. Скажите: напиши в мессенджер, имя и текст.")
        val inputs = action.remoteInputs ?: return Reply("Не получилось ответить")
        val input = inputs.firstOrNull { it.allowFreeFormInput } ?: inputs[0]
        return try {
            val intent = Intent()
            val results = Bundle()
            results.putCharSequence(input.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(ctx, 0, intent)
            Diag.inc("ответов отправлено")
            Diag.log("сообщения", "Ответ отправлен через уведомление (${item.app})")
            Reply("Отправила")
        } catch (e: PendingIntent.CanceledException) {
            Diag.log("сообщения", "Уведомление уже закрыто: ${e.message}")
            Reply("Это уведомление уже закрыто")
        } catch (e: Exception) {
            Diag.log("сообщения", "Ошибка ответа: ${e.javaClass.simpleName}: ${e.message}")
            Reply("Не получилось ответить")
        }
    }

    // Открыть приложение, найти чат, вписать текст, нажать «Отправить» (в фоновом потоке, итог озвучивается)
    private fun uiFlow(ctx: Context, needle: String, appSpoken: String, name: String, text: String) {
        Thread {
            try {
                if (!Commands.launch(ctx, needle)) {
                    VoiceService.announce("Не нашла приложение $appSpoken")
                    return@Thread
                }
                Thread.sleep(2500)
                val stem = stem(name)
                var found = LunaAccessibilityService.instance?.clickTextFuzzy(stem) == true
                if (!found) {
                    val svc = LunaAccessibilityService.instance
                    val opened = svc != null && (svc.clickText("поиск") || svc.clickText("search"))
                    if (opened) {
                        Thread.sleep(900)
                        LunaAccessibilityService.instance?.typeText(stem)
                        Thread.sleep(1800)
                        found = LunaAccessibilityService.instance?.clickTextFuzzy(stem) == true
                    }
                }
                if (!found) {
                    Diag.log("сообщения", "Чат не найден на экране")
                    VoiceService.announce("Не нашла чат $name")
                    return@Thread
                }
                Thread.sleep(1600)
                if (LunaAccessibilityService.instance?.typeText(text) != true) {
                    VoiceService.announce("Не нашла поле ввода")
                    return@Thread
                }
                Thread.sleep(700)
                val svc = LunaAccessibilityService.instance
                val sent = svc != null && listOf("отправить", "send").any { svc.clickText(it) }
                Diag.log("сообщения", "Отправка через экран: ${if (sent) "нажата" else "кнопка не найдена"}")
                VoiceService.announce(if (sent) "Отправила" else "Текст набран, но кнопку отправки не нашла")
            } catch (e: Exception) {
                Diag.log("сообщения", "Ошибка отправки через экран: ${e.javaClass.simpleName}: ${e.message}")
                VoiceService.announce("Не получилось отправить")
            }
        }.start()
    }
}
