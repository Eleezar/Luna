package com.luna.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

// Сценарии: одна фраза запускает цепочку команд.
// «создай сценарий вечер громкость тридцать потом включи музыку потом открой телеграм», потом просто «вечер».
object Scenarios {

    private val createPrefixes = listOf(
        "создай сценарий", "новый сценарий", "запомни сценарий", "добавь сценарий", "создай режим", "новый режим"
    )
    private val runPrefixes = listOf(
        "запусти сценарий", "включи сценарий", "выполни сценарий", "запусти режим", "включи режим",
        "выполни режим", "сценарий", "режим", "запусти", "включи", "выполни"
    )
    private val deletePrefixes = listOf("удали сценарий", "удали режим")
    private val listPhrases = listOf("какие сценарии", "мои сценарии", "список сценариев", "покажи сценарии", "какие режимы", "мои режимы")
    private val separators = Regex("""\s+(?:а\s+)?(?:потом|затем|после этого|далее)\s+""")

    @Volatile
    private var running = false

    private fun strip(t: String, p: String): String? {
        if (t == p) return ""
        if (t.startsWith("$p ")) return t.removePrefix("$p ").trim()
        return null
    }

    private fun strip(t: String, prefixes: List<String>): String? {
        for (p in prefixes.sortedByDescending { it.length }) {
            val r = strip(t, p)
            if (r != null) return r
        }
        return null
    }

    private fun splitSteps(text: String): List<String> =
        text.split(separators).map { it.trim() }.filter { it.isNotEmpty() }

    private fun isWait(step: String) = step == "подожди" || step.startsWith("подожди ")

    private fun waitMillis(step: String): Long {
        val sec = step.split(" ").mapNotNull { Calc.units[it] }.sum()
        return (if (sec in 1..120) sec else 2) * 1000L
    }

    private fun validStep(step: String): Boolean = isWait(step) || Commands.isKnown(step)

    private fun find(t: String): Store.Scenario? {
        val all = Store.allScenarios()
        if (all.isEmpty()) return null
        val candidates = ArrayList<String>()
        candidates.add(t)
        for (p in runPrefixes.sortedByDescending { it.length }) {
            val r = strip(t, p)
            if (r != null && r.isNotEmpty()) candidates.add(r)
        }
        for (c in candidates) {
            val exact = all.firstOrNull { it.name == c }
            if (exact != null) return exact
            if (c.length >= 5) {
                val near = all.firstOrNull { Fuzzy.distance(c, it.name) <= 1 }
                if (near != null) return near
            }
        }
        return null
    }

    fun isKnown(t: String): Boolean =
        strip(t, createPrefixes) != null || strip(t, deletePrefixes) != null ||
            listPhrases.any { t.contains(it) } || find(t) != null

    // Создание сценария диктуется длинной фразой
    fun isDictation(t: String): Boolean = strip(t, createPrefixes) != null

    fun handle(ctx: Context, t: String): Reply? {
        val create = strip(t, createPrefixes)
        if (create != null) return createStart(create)
        val del = strip(t, deletePrefixes)
        if (del != null) return delete(del)
        if (listPhrases.any { t.contains(it) }) return list()
        val sc = find(t)
        if (sc != null) return run(ctx, sc)
        return null
    }

    // ---------- создание ----------

    private fun createStart(rest: String): Reply {
        val words = rest.split(" ").filter { it.isNotBlank() }
        if (words.isEmpty()) return Reply("Как назвать сценарий?") { s -> createStart(s) }
        val name = words[0]
        val stepsText = words.drop(1).joinToString(" ")
        if (stepsText.isBlank()) return askStep(name, ArrayList(), "")
        val parts = splitSteps(stepsText)
        val bad = parts.firstOrNull { !validStep(it) }
        if (bad != null) return askStep(name, ArrayList(), "Не поняла шаг: $bad. Давайте по одному. ")
        return save(name, parts)
    }

    private fun askStep(name: String, steps: MutableList<String>, prefix: String): Reply {
        val question = if (steps.isEmpty()) "Назовите первый шаг." else "Шаг ${steps.size + 1}? Или скажите: готово."
        return Reply(prefix + question) { s ->
            val words = s.trim().split(" ").filter { it.isNotBlank() }
            val finished = words.isNotEmpty() && words.all { it in setOf("все", "всё", "готово", "хватит", "сохрани", "конец", "это") }
            if (finished) {
                if (steps.isEmpty()) Reply("Сценарий пустой, не сохраняю.") else save(name, steps)
            } else {
                val parts = splitSteps(s.trim())
                val bad = parts.firstOrNull { !validStep(it) }
                if (parts.isEmpty() || bad != null) {
                    askStep(name, steps, "Не поняла шаг. ")
                } else {
                    steps.addAll(parts)
                    askStep(name, steps, "")
                }
            }
        }
    }

    private fun save(name: String, steps: List<String>): Reply {
        Store.addScenario(name, steps)
        Diag.inc("сценариев создано")
        Diag.log("сценарий", "Сохранён «$name», шагов: ${steps.size}")
        return Reply("Сценарий $name сохранён, шагов: ${steps.size}. Чтобы запустить, скажите: $name")
    }

    private fun delete(name: String): Reply {
        if (name.isBlank()) return Reply("Какой сценарий удалить?") { s -> delete(s.trim()) }
        val ok = Store.deleteScenario(name)
        return if (ok) Reply("Удалила сценарий $name") else Reply("Такого сценария нет")
    }

    private fun list(): Reply {
        val all = Store.allScenarios()
        if (all.isEmpty()) return Reply("Сценариев пока нет")
        return Reply("Сценарии: " + all.joinToString(", ") { it.name })
    }

    // ---------- запуск ----------

    fun run(ctx: Context, sc: Store.Scenario): Reply {
        if (running) return Reply("Сценарий уже выполняется")
        running = true
        Diag.inc("сценариев запущено")
        Diag.log("сценарий", "Запуск «${sc.name}», шагов: ${sc.steps.size}")
        val handler = Handler(Looper.getMainLooper())
        var delay = 900L // пока Луна говорит «запускаю»
        for ((i, step) in sc.steps.withIndex()) {
            val at = delay
            if (!isWait(step)) {
                handler.postDelayed({ runStep(ctx, step, i + 1) }, at)
                delay += 1500
            } else {
                delay += waitMillis(step)
            }
        }
        handler.postDelayed({
            running = false
            Toast.makeText(ctx, "Сценарий «${sc.name}» выполнен", Toast.LENGTH_SHORT).show()
            Diag.log("сценарий", "Сценарий «${sc.name}» завершён")
        }, delay)
        return Reply("Запускаю сценарий ${sc.name}")
    }

    private fun runStep(ctx: Context, step: String, number: Int) {
        try {
            val r = Commands.run(ctx, step)
            Diag.log("сценарий", "шаг $number: «$step» → ${r.text ?: "без ответа"}" + if (r.followUp != null) " (вопрос пропущен)" else "")
        } catch (e: Exception) {
            Diag.log("сценарий", "шаг $number «$step»: ошибка ${e.javaClass.simpleName}: ${e.message}")
        }
    }
}
