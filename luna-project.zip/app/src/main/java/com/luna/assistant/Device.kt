package com.luna.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Handler
import android.os.Looper

// Управление телефоном и другими приложениями: уведомления, нажатия, прокрутка, ввод текста, чтение экрана
object Device {

    private enum class Kind {
        NOTIF_READ, NOTIF_CLEAR, SHADE, BACK, RECENTS, CLOSE_ALL, LOCK, SHOT,
        READ_SCREEN, SCROLL_DOWN, SCROLL_UP, SEND, CLICK, TYPE
    }

    private val clickPrefixes = listOf("нажми на", "нажми", "кликни на", "кликни", "тапни по", "тапни")

    private fun clickPrefix(t: String): String? =
        clickPrefixes.sortedByDescending { it.length }.firstOrNull { t == it || t.startsWith("$it ") }

    private fun classify(t: String): Kind? {
        if (t.contains("уведомлен")) {
            if (listOf("очисти", "удали", "сотри").any { t.contains(it) }) return Kind.NOTIF_CLEAR
            return Kind.NOTIF_READ
        }
        if (t == "что мне пришло" || t == "что пришло" || t == "что нового" || t.contains("новые сообщения")) return Kind.NOTIF_READ
        if (t.contains("шторк")) return Kind.SHADE
        if (t == "назад" || t == "вернись" || t == "вернись назад" || t == "нажми назад") return Kind.BACK
        if (t.contains("последние приложения") || t.contains("недавние приложения")) return Kind.RECENTS
        if (t.contains("закрой все приложения") || t.contains("закрой все программы")) return Kind.CLOSE_ALL
        if (t.contains("заблокируй")) return Kind.LOCK
        if (t.contains("скриншот") || t.contains("снимок экрана")) return Kind.SHOT
        if (t == "что на экране" || t.contains("прочитай экран") || t.contains("прочти экран")) return Kind.READ_SCREEN
        if (listOf("прокрути", "листай", "пролистай").any { t.startsWith(it) }) {
            return if (t.contains("вверх") || t.contains("назад")) Kind.SCROLL_UP else Kind.SCROLL_DOWN
        }
        if (t == "отправь" || t == "отправить") return Kind.SEND
        if (clickPrefix(t) != null) return Kind.CLICK
        if (t == "напиши" || t.startsWith("напиши ")) return Kind.TYPE
        return null
    }

    fun isKnown(t: String): Boolean = classify(t) != null

    // «напиши …» диктуется длинной фразой
    fun isDictation(t: String): Boolean = t == "напиши" || t.startsWith("напиши ")

    private fun needAccessibility() =
        Reply("Включите службу доступности для Луны: на главном экране кнопка «Служба доступности»")

    fun handle(ctx: Context, t: String): Reply? {
        val kind = classify(t) ?: return null
        Diag.inc("команд управления телефоном")
        Diag.log("управление", "Команда: $kind")

        // уведомления работают через отдельный доступ
        when (kind) {
            Kind.NOTIF_READ -> return readNotifications()
            Kind.NOTIF_CLEAR -> {
                val l = LunaNotificationListener.instance
                    ?: return Reply("Включите доступ к уведомлениям для Луны на главном экране")
                l.cancelAllNotifications()
                NotifStore.clear()
                return Reply("Уведомления очищены")
            }
            else -> {}
        }

        val svc = LunaAccessibilityService.instance ?: return needAccessibility()
        return when (kind) {
            Kind.SHADE -> { svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); Reply("Открываю шторку") }
            Kind.BACK -> { svc.global(AccessibilityService.GLOBAL_ACTION_BACK); Reply("Назад") }
            Kind.RECENTS -> { svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS); Reply("Последние приложения") }
            Kind.CLOSE_ALL -> {
                svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                Handler(Looper.getMainLooper()).postDelayed({
                    val ok = svc.clickText("закрыть все")
                    Diag.log("управление", "Закрыть все: ${if (ok) "нажато" else "кнопка не найдена"}")
                }, 1000)
                Reply("Закрываю все приложения")
            }
            Kind.LOCK -> { svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); Reply("Блокирую экран") }
            Kind.SHOT -> { svc.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); Reply("Делаю скриншот") }
            Kind.READ_SCREEN -> {
                val list = svc.readScreen()
                Diag.log("управление", "Прочитан экран, элементов: ${list.size}")
                if (list.isEmpty()) Reply("На экране нечего читать") else Reply(list.joinToString(". "))
            }
            Kind.SCROLL_DOWN -> if (svc.scroll(true)) Reply("Листаю вниз") else Reply("Не нашла, что прокручивать")
            Kind.SCROLL_UP -> if (svc.scroll(false)) Reply("Листаю вверх") else Reply("Не нашла, что прокручивать")
            Kind.SEND -> {
                val ok = listOf("отправить", "отправка", "send").any { svc.clickText(it) }
                if (ok) Reply("Отправляю") else Reply("Не нашла кнопку отправки")
            }
            Kind.CLICK -> {
                val prefix = clickPrefix(t) ?: ""
                val q = t.removePrefix(prefix).trim()
                if (q.isEmpty()) Reply("На что нажать?") { s -> clickReply(s) } else clickReply(q)
            }
            Kind.TYPE -> {
                val body = t.removePrefix("напиши").trim()
                if (body.isEmpty()) Reply("Что написать?") { s -> typeReply(s) } else typeReply(body)
            }
            else -> Reply("Не поняла")
        }
    }

    private fun clickReply(q: String): Reply {
        val svc = LunaAccessibilityService.instance ?: return needAccessibility()
        val ok = svc.clickText(q)
        Diag.log("управление", "Нажатие по тексту: ${if (ok) "выполнено" else "элемент не найден"}")
        return if (ok) Reply("Нажала: $q") else Reply("Не нашла на экране: $q")
    }

    private fun typeReply(text: String): Reply {
        val svc = LunaAccessibilityService.instance ?: return needAccessibility()
        val ok = svc.typeText(text)
        Diag.log("управление", "Ввод текста: ${if (ok) "выполнен" else "поле ввода не найдено"}")
        return if (ok) Reply("Написала") else Reply("Нет поля ввода. Нажмите на поле, куда писать")
    }

    private fun readNotifications(): Reply {
        if (LunaNotificationListener.instance == null) {
            return Reply("Включите доступ к уведомлениям для Луны: на главном экране кнопка «Доступ к уведомлениям»")
        }
        val unread = NotifStore.unread()
        if (unread.isEmpty()) return Reply("Новых уведомлений нет")
        val take = unread.take(5)
        val sb = StringBuilder("Новых уведомлений: ${unread.size}. ")
        for (n in take) {
            sb.append(n.app).append(": ")
            if (n.title.isNotBlank()) sb.append(n.title).append(". ")
            if (n.text.isNotBlank()) sb.append(n.text.take(140)).append(". ")
        }
        NotifStore.markRead(take)
        if (unread.size > take.size) sb.append("Остальные можно прочитать, скажите прочитай уведомления ещё раз.")
        Diag.log("управление", "Прочитано уведомлений: ${take.size} из ${unread.size}")
        return Reply(sb.toString().trim())
    }
}
