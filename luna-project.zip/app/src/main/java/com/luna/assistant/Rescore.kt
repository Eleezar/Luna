package com.luna.assistant

// Из нескольких вариантов распознавания выбирает тот, который Луна лучше понимает
object Rescore {

    private fun clean(s: String): String =
        s.replace("[unk]", " ").replace(Regex("""\s+"""), " ").trim()

    private fun score(t: String, expect: Expect): Int = when (expect) {
        Expect.FREE -> if (Commands.isKnown(t)) 100 else 0
        Expect.YESNO -> {
            val w = t.split(" ")
            if (w.any { it in setOf("да", "нет", "давай", "конечно", "отмена", "ага", "удаляй", "подтверждаю") }) 100 else 0
        }
        Expect.TIME -> {
            val p = DateParser.parse(t, true)
            if (p.hour != null) 100 else 0
        }
        Expect.DATETIME -> {
            val p = DateParser.parse(t, true)
            (if (p.hour != null) 60 else 0) + (if (p.date != null) 60 else 0)
        }
    }

    // alts: варианты от лучшего к худшему. Возвращает выбранный (и исправленный) вариант
    fun pick(alts: List<String>, expect: Expect): String {
        val cleaned = alts.map { Aliases.apply(clean(it)) }.filter { it.isNotEmpty() }
        if (cleaned.isEmpty()) return ""
        var best = cleaned[0]
        var bestScore = Int.MIN_VALUE
        for ((i, raw) in cleaned.withIndex()) {
            val fixed = if (expect == Expect.FREE) Fuzzy.fixCommand(raw) else raw
            val s = score(fixed, expect) * 10 - i // небольшой штраф за более низкое место в списке
            if (s > bestScore) {
                bestScore = s
                best = fixed
            }
        }
        return best
    }
}
