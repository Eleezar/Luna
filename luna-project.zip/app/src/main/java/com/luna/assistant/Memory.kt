package com.luna.assistant

import android.content.Context

// Память разговора: что только что создали и какую команду выполняли.
// Благодаря ей работают продолжения: «удали его», «перенеси на час позже», «а на субботу тоже?».
object Memory {

    class Ref(val type: String, val id: Long, val name: String, val time: Long)

    @Volatile
    var lastCreated: Ref? = null

    @Volatile
    var lastCommand: String = ""

    @Volatile
    var lastCommandTime: Long = 0L

    @Volatile
    private var followupHandled = false

    fun created(type: String, id: Long, name: String) {
        lastCreated = Ref(type, id, name, System.currentTimeMillis())
    }

    fun markFollowup() {
        followupHandled = true
    }

    // Запоминает команду для «ещё раз» и «а на субботу?»; сами продолжения и вопросы о Луне не запоминаются
    fun noteCommand(text: String, understood: Boolean) {
        if (followupHandled) {
            followupHandled = false
            return
        }
        if (!understood || Help.isKnown(text) || Followups.isFollowup(text)) return
        lastCommand = text
        lastCommandTime = System.currentTimeMillis()
    }
}

// Продолжения разговора
object Followups {

    private val deleteIt = setOf(
        "удали его", "удали её", "удали ее", "удали это", "отмени его", "отмени её", "отмени ее", "отмени это",
        "убери его", "убери это", "удали последнее", "удали последний", "удали последнюю"
    )
    private val repeatCommand = setOf("ещё раз", "еще раз", "повтори команду", "сделай ещё раз", "сделай еще раз", "повтори это")

    private fun isFresh(time: Long, minutes: Int) = System.currentTimeMillis() - time < minutes * 60_000L

    private fun leadFragment(t: String): String? {
        val lead = t.startsWith("а ") || t.startsWith("и ") || t.startsWith("тоже ") || t.startsWith("ещё ") || t.startsWith("еще ")
        val tail = t.endsWith(" тоже") || t.endsWith(" также")
        if (!lead && !tail) return null
        return t.removePrefix("а ").removePrefix("и ").removePrefix("тоже ").removePrefix("ещё ").removePrefix("еще ")
            .removeSuffix(" тоже").removeSuffix(" также").trim()
    }

    fun isFollowup(t: String): Boolean =
        t in deleteIt || t in repeatCommand || t.startsWith("перенеси") || t.startsWith("сдвинь") ||
            (leadFragment(t)?.let { frag ->
                val p = DateParser.parse(frag, true)
                p.date != null || p.hour != null
            } ?: false)

    fun handle(ctx: Context, t: String): Reply? {
        val ref = Memory.lastCreated?.takeIf { isFresh(it.time, 15) }

        if (t in deleteIt) return deleteIt(ctx, ref)
        if (t.startsWith("перенеси") || t.startsWith("сдвинь")) return shift(ctx, ref, t)

        if (t in repeatCommand) {
            val last = Memory.lastCommand
            if (last.isBlank() || !isFresh(Memory.lastCommandTime, 10)) return Reply("Нечего повторять")
            Memory.markFollowup()
            return Commands.run(ctx, last)
        }

        // «а на субботу тоже?»: добавляем сказанное к прошлой команде
        val frag = leadFragment(t)
        if (frag != null && frag.isNotBlank()) {
            val last = Memory.lastCommand
            if (last.isNotBlank() && isFresh(Memory.lastCommandTime, 3)) {
                val p = DateParser.parse(frag, true)
                val domain = History.domainOf(last)
                val ok = domain == "alarm" || domain == "event" || Secretary.isQuery(last)
                if ((p.date != null || p.hour != null) && ok) {
                    val combined = "$last $frag"
                    Diag.log("разговор", "Продолжение: добавляю к прошлой команде")
                    Memory.markFollowup()
                    Memory.lastCommand = combined
                    Memory.lastCommandTime = System.currentTimeMillis()
                    return Commands.run(ctx, combined)
                }
            }
        }
        return null
    }

    private fun typeLabel(type: String) = when (type) {
        "note" -> "заметку"
        "event" -> "событие"
        "alarm" -> "будильник"
        "timer" -> "таймер"
        "scenario" -> "сценарий"
        else -> "это"
    }

    private fun deleteIt(ctx: Context, ref: Memory.Ref?): Reply {
        if (ref == null) return Reply("Не знаю, что удалить. Скажите, например: удали последнюю заметку")
        when (ref.type) {
            "note" -> Store.deleteNote(ref.id)
            "event" -> {
                val ev = Store.allEvents().firstOrNull { it.id == ref.id }
                Reminders.cancel(ctx, ref.id)
                if (ev != null) CalendarSync.delete(ctx, ev.sysId)
                Store.deleteEvent(ref.id)
            }
            "alarm", "timer" -> Alarms.cancel(ctx, ref.id)
            "scenario" -> Store.deleteScenario(ref.name)
        }
        Memory.lastCreated = null
        Diag.log("разговор", "Удалено по «удали его»: ${ref.type}")
        return Reply("Удалила ${typeLabel(ref.type)}: ${ref.name}")
    }

    private fun shift(ctx: Context, ref: Memory.Ref?, t: String): Reply {
        if (ref == null || ref.type !in setOf("alarm", "timer", "event")) {
            return Reply("Не знаю, что переносить. Сначала поставьте будильник, таймер или событие")
        }
        val rest = t.removePrefix("перенеси").removePrefix("сдвинь").trim()
        val current: Long = when (ref.type) {
            "event" -> Store.allEvents().firstOrNull { it.id == ref.id }?.start
            else -> Store.findAlarm(ref.id)?.time
        } ?: return Reply("Не нашла, что переносить")

        val sign = if (rest.contains("раньше")) -1 else 1
        val dur = Alarms.parseDurationMs(rest)
        var newTime: Long? = null
        if (dur != null && (rest.contains("позже") || rest.contains("раньше"))) {
            newTime = current + sign * dur
        } else {
            val p = DateParser.parse(rest, true, ref.type == "alarm")
            if (p.date != null || p.hour != null) {
                val cal = java.util.Calendar.getInstance().apply { timeInMillis = current }
                val d = p.date
                if (d != null) {
                    cal.set(java.util.Calendar.YEAR, d.get(java.util.Calendar.YEAR))
                    cal.set(java.util.Calendar.MONTH, d.get(java.util.Calendar.MONTH))
                    cal.set(java.util.Calendar.DAY_OF_MONTH, d.get(java.util.Calendar.DAY_OF_MONTH))
                }
                val h = p.hour
                if (h != null) {
                    cal.set(java.util.Calendar.HOUR_OF_DAY, h)
                    cal.set(java.util.Calendar.MINUTE, p.minute ?: 0)
                }
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                newTime = cal.timeInMillis
            } else if (dur != null) {
                newTime = current + dur
            }
        }
        val target: Long = newTime ?: return Reply("На сколько перенести? Например: перенеси на час позже")
        if (target <= System.currentTimeMillis()) return Reply("Это время уже прошло")

        when (ref.type) {
            "event" -> {
                val ev = Store.allEvents().firstOrNull { it.id == ref.id } ?: return Reply("Не нашла событие")
                Reminders.cancel(ctx, ev.id)
                CalendarSync.delete(ctx, ev.sysId)
                Store.deleteEvent(ev.id)
                val sys = CalendarSync.insert(ctx, ev.title, target)
                val n = Store.addEvent(ev.title, target, sys)
                Reminders.schedule(ctx, n)
                Memory.created("event", n.id, ev.title)
            }
            else -> Alarms.reschedule(ctx, ref.id, target)
        }
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = target }
        Diag.log("разговор", "Перенесено: ${ref.type}")
        return Reply("Перенесла на ${Secretary.describe(cal)}")
    }
}
