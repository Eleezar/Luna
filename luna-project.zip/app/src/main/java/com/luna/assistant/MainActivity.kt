package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this

        val title = TextView(ctx).apply {
            text = "Скажите «Луна», после сигнала — команду.\n" +
                "Например: «открой ютуб», «громче», «домой», «сколько будет двадцать пять умножить на четыре».\n" +
                "Секретарь: «запиши заметку купить хлеб», «напомни позвонить врачу завтра в десять утра», " +
                "«что у меня запланировано», «прочитай заметки»."
            textSize = 16f
        }
        val overlay = Button(ctx).apply {
            text = "1. Разрешить поверх других окон"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        val start = Button(ctx).apply {
            text = "2. Запустить Луну"
            setOnClickListener { startVoice() }
        }
        val calendar = Button(ctx).apply {
            text = "3. Разрешить календарь (для секретаря)"
            setOnClickListener {
                requestPermissions(
                    arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 2
                )
            }
        }
        val stop = Button(ctx).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(ctx, VoiceService::class.java)) }
        }
        val secretary = Button(ctx).apply {
            text = "Секретарь: заметки и события"
            setOnClickListener { startActivity(Intent(ctx, SecretaryActivity::class.java)) }
        }
        val diag = Button(ctx).apply {
            text = "Диагностика"
            setOnClickListener { startActivity(Intent(ctx, DiagActivity::class.java)) }
        }

        setContentView(ScrollView(ctx).apply {
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 96, 48, 48)
                addView(title)
                addView(overlay)
                addView(start)
                addView(calendar)
                addView(stop)
                addView(secretary)
                addView(diag)
            })
        })
    }

    private fun startVoice() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(perms.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startVoice()
        }
    }
}
