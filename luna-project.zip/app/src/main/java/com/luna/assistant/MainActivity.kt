package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class MainActivity : Activity() {

    private var notifButton: Button? = null
    private var accessButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this

        val title = TextView(ctx).apply {
            text = "Скажите «Луна», после сигнала — команду.\n" +
                "Например: «открой ютуб», «громче», «домой», «сколько будет двадцать пять умножить на четыре».\n" +
                "Секретарь: «запиши заметку купить хлеб», «напомни позвонить врачу завтра в десять утра», " +
                "«что у меня запланировано», «прочитай заметки»."
            textSize = 16f
        }
        val overlay = Button(ctx).apply {
            text = "1. Разрешить поверх других окон"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        val start = Button(ctx).apply {
            text = "2. Запустить Луну"
            setOnClickListener { startVoice() }
        }
        val calendar = Button(ctx).apply {
            text = "3. Разрешить календарь (для секретаря)"
            setOnClickListener {
                requestPermissions(
                    arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 2
                )
            }
        }
        val stop = Button(ctx).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(ctx, VoiceService::class.java)) }
        }
        val secretary = Button(ctx).apply {
            text = "Секретарь: заметки и события"
            setOnClickListener { startActivity(Intent(ctx, SecretaryActivity::class.java)) }
        }
        val diag = Button(ctx).apply {
            text = "Диагностика"
            setOnClickListener { startActivity(Intent(ctx, DiagActivity::class.java)) }
        }

        val prefs = getSharedPreferences("luna", MODE_PRIVATE)
        fun engineLabel() = when (prefs.getString("engine", "google")) {
            "ondevice" -> "Распознавание команд: Google офлайн-пакет (без интернета)"
            "vosk" -> "Распознавание команд: встроенный офлайн Vosk (менее точно)"
            else -> "Распознавание команд: Google онлайн (точнее всего)"
        }
        val engine = Button(ctx).apply {
            text = engineLabel()
            isAllCaps = false
            setOnClickListener {
                val next = when (prefs.getString("engine", "google")) {
                    "google" -> "ondevice"
                    "ondevice" -> "vosk"
                    else -> "google"
                }
                prefs.edit().putString("engine", next).apply()
                text = engineLabel()
                Toast.makeText(ctx, "Режим применится при следующем запуске Луны", Toast.LENGTH_SHORT).show()
            }
        }
        val pack = Button(ctx).apply {
            text = "Скачать русский офлайн-пакет Google"
            isAllCaps = false
            setOnClickListener { downloadOfflinePack() }
        }

        val notif = Button(ctx).apply {
            isAllCaps = false
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val access = Button(ctx).apply {
            isAllCaps = false
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val appInfo = Button(ctx).apply {
            text = "Если переключатель серый: свойства приложения Луна"
            isAllCaps = false
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        notifButton = notif
        accessButton = access

        setContentView(ScrollView(ctx).apply {
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 96, 48, 48)
                addView(title)
                addView(overlay)
                addView(start)
                addView(calendar)
                addView(engine)
                addView(pack)
                addView(stop)
                addView(secretary)
                addView(notif)
                addView(access)
                addView(appInfo)
                addView(diag)
            })
        })
    }

    override fun onResume() {
        super.onResume()
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        notifButton?.text = "Доступ к уведомлениям: " + if (nl) "включён" else "выключен (нажмите)"
        accessButton?.text = "Служба доступности (управление экраном): " + if (acc) "включена" else "выключена (нажмите)"
    }

    private fun startVoice() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(perms.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startVoice()
        }
    }

    // Просит Google скачать русский пакет для распознавания без интернета (Android 13 и новее)
    private fun downloadOfflinePack() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        }
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            try {
                val r = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                r.checkRecognitionSupport(intent, mainExecutor, object : RecognitionSupportCallback {
                    override fun onSupportResult(recognitionSupport: RecognitionSupport) {
                        val installed = recognitionSupport.installedOnDeviceLanguages
                        Diag.log("google", "офлайн-пакеты Google: установлены $installed, доступно для скачивания ${recognitionSupport.supportedOnDeviceLanguages.size}")
                        val has = installed.any { it.startsWith("ru") }
                        runOnUiThread {
                            if (has) {
                                Toast.makeText(this@MainActivity, "Русский офлайн-пакет уже установлен", Toast.LENGTH_LONG).show()
                            } else {
                                try {
                                    r.triggerModelDownload(intent)
                                    Toast.makeText(this@MainActivity, "Скачивание русского пакета начато, это может занять несколько минут", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    Diag.log("google", "не удалось начать скачивание пакета: ${e.message}")
                                    Toast.makeText(this@MainActivity, "Не удалось начать скачивание: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }

                    override fun onError(error: Int) {
                        Diag.log("google", "проверка офлайн-пакетов: ошибка $error")
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Не удалось проверить пакеты (ошибка $error)", Toast.LENGTH_LONG).show()
                        }
                    }
                })
            } catch (e: Exception) {
                Diag.log("google", "офлайн-пакет: ${e.javaClass.simpleName}: ${e.message}")
                Toast.makeText(this, "Не получилось: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(
                this,
                "Скачайте вручную: приложение Google → Настройки → Голосовой ввод → Распознавание речи офлайн → Русский",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
