package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this

        val title = TextView(ctx).apply {
            text = "Скажите «Луна», после сигнала — команду.\nНапример: «открой ютуб», «громче», «громкость тридцать», «домой»."
            textSize = 18f
        }
        val overlay = Button(ctx).apply {
            text = "1. Разрешить поверх других окон"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        val start = Button(ctx).apply {
            text = "2. Запустить Луну"
            setOnClickListener { startVoice() }
        }
        val stop = Button(ctx).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(ctx, VoiceService::class.java)) }
        }

        setContentView(LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(title)
            addView(overlay)
            addView(start)
            addView(stop)
        })
    }

    private fun startVoice() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(perms.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        }
    }
}
