package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

class DiagActivity : Activity() {

    private lateinit var reportView: TextView
    private lateinit var statusView: TextView
    private lateinit var levelBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var testing = false
    private var lastReport = ""

    private val autoRefresh = object : Runnable {
        override fun run() {
            if (!testing) refresh()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this

        fun button(label: String, action: () -> Unit): Button = Button(ctx).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setOnClickListener { action() }
        }

        fun rowParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

        val row1 = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Обновить") { refresh() }, rowParams())
            addView(button("Копировать") { copyReport() }, rowParams())
            addView(button("Поделиться") { shareReport() }, rowParams())
        }
        val row2 = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Тест микрофона") { startMicTest() }, rowParams())
            addView(button("Очистить журнал") { Diag.clear(); refresh() }, rowParams())
        }

        statusView = TextView(ctx).apply {
            text = "Тест микрофона: проверяет, какой источник звука слышит вас (Луна на время теста остановится)."
            textSize = 13f
        }
        levelBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }

        reportView = TextView(ctx).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            text = "Собираю отчёт…"
        }
        val scroll = ScrollView(ctx).apply { addView(reportView) }

        setContentView(LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 24)
            addView(row1)
            addView(row2)
            addView(statusView)
            addView(levelBar)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        handler.post(autoRefresh)
    }

    override fun onPause() {
        handler.removeCallbacks(autoRefresh)
        super.onPause()
    }

    private fun refresh() {
        Thread {
            val text = Diag.report(this)
            lastReport = text
            runOnUiThread { reportView.text = text }
        }.start()
    }

    private fun currentReport(): String = lastReport.ifEmpty { Diag.report(this) }

    private fun copyReport() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Luna", currentReport()))
        Toast.makeText(this, "Отчёт скопирован, вставьте его в чат", Toast.LENGTH_LONG).show()
    }

    private fun shareReport() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, currentReport())
        }
        startActivity(Intent.createChooser(send, "Отправить отчёт"))
    }

    // ---------- Тест микрофона ----------

    private fun startMicTest() {
        if (testing) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        testing = true
        stopService(Intent(this, VoiceService::class.java))
        Diag.log("тест микрофона", "Начат тест источников звука")

        Thread {
            Thread.sleep(800) // даём службе освободить микрофон
            val sources = listOf(
                "MIC" to MediaRecorder.AudioSource.MIC,
                "VOICE_RECOGNITION" to MediaRecorder.AudioSource.VOICE_RECOGNITION,
                "VOICE_COMMUNICATION" to MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                "CAMCORDER" to MediaRecorder.AudioSource.CAMCORDER,
                "UNPROCESSED" to MediaRecorder.AudioSource.UNPROCESSED
            )
            val results = mutableListOf<String>()
            val peaks = LinkedHashMap<String, Int>()
            for ((name, src) in sources) {
                runOnUiThread { statusView.text = "Источник $name: говорите «раз, два, три…» (3 с)" }
                val r = testSource(name, src)
                peaks[name] = r.first
                results.add(r.second)
                Diag.log("тест микрофона", r.second)
            }
            val verdict = verdict(peaks)
            Diag.log("тест микрофона", verdict)
            Diag.micResults = (results + verdict).joinToString("\n")
            runOnUiThread {
                testing = false
                levelBar.progress = 0
                statusView.text = verdict + "\n(Чтобы снова включить Луну, вернитесь на главный экран и нажмите «Запустить Луну».)"
                refresh()
            }
        }.start()
    }

    // Возвращает пик в процентах и строку с результатом
    private fun testSource(name: String, source: Int): Pair<Int, String> {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return Pair(0, "$name: не поддерживается")
        var rec: AudioRecord? = null
        try {
            rec = AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            if (rec.state != AudioRecord.STATE_INITIALIZED) return Pair(0, "$name: не удалось открыть")
            rec.startRecording()
            val buf = ShortArray(1600)
            val end = SystemClock.elapsedRealtime() + 3000
            var peak = 0
            var sumSq = 0.0
            var count = 0L
            while (SystemClock.elapsedRealtime() < end) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                var chunkPeak = 0
                for (i in 0 until n) {
                    val v = abs(buf[i].toInt())
                    if (v > chunkPeak) chunkPeak = v
                    sumSq += v.toDouble() * v
                }
                count += n
                peak = max(peak, chunkPeak)
                val pct = chunkPeak * 100 / 32768
                runOnUiThread { levelBar.progress = pct }
            }
            val device = rec.routedDevice?.let { Diag.deviceName(it) } ?: "неизвестно"
            val rms = if (count > 0) sqrt(sumSq / count) else 0.0
            val db = if (rms > 0) (20 * log10(rms / 32768)).toInt() else -99
            val peakPct = peak * 100 / 32768
            return Pair(peakPct, "$name: пик $peakPct%, уровень $db дБ, устройство: $device")
        } catch (e: Exception) {
            return Pair(0, "$name: ошибка ${e.message}")
        } finally {
            try { rec?.stop() } catch (e: Exception) { }
            rec?.release()
        }
    }

    private fun verdict(peaks: Map<String, Int>): String {
        val ok = peaks.filter { it.value >= 5 }.keys
        val vr = peaks["VOICE_RECOGNITION"] ?: 0
        return when {
            ok.isEmpty() ->
                "ВЕРДИКТ: ни один источник не услышал речь (пики меньше 5%). Микрофон не работает, закрыт или нет доступа."
            vr < 5 && (peaks["MIC"] ?: 0) < 5 ->
                "ВЕРДИКТ: обычные источники молчат, а ${ok.joinToString()} слышит. Луну нужно переключить на этот источник."
            vr < 15 ->
                "ВЕРДИКТ: микрофон слышит, но тихо (пик $vr%). Говорите ближе к микрофону. Работают: ${ok.joinToString()}."
            else ->
                "ВЕРДИКТ: микрофон слышит нормально. Работают: ${ok.joinToString()}."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMicTest()
    }
}
