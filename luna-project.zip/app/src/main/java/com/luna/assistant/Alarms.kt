package com.luna.assistant

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

// Таймеры и будильники: ставятся через AlarmManager.setAlarmClock (самый надёжный способ, будит телефон),
// звонят через AlarmRingService, хранятся в Store и видны на экране «Секретарь».
object Alarms {

    const val ACTION_STOP = "com.luna.assistant.ALARM_STOP"
    const val ACTION_SNOOZE = "com.luna.assistant.ALARM_SNOOZE"

    private val timerPrefixes = listOf(
        "поставь таймер", "запусти таймер", "включи таймер", "засеки время", "засеки", "таймер"
    )
    private val alarmPrefixes = listOf(
        "поставь будильник", "заведи будильник", "установи будильник", "включи будильник",
        "добавь будильник", "разбуди меня", "будильник", "разбуди"
    )
    private val repeatPhrases = listOf("каждый день", "ежедневно", "каждое утро")
    private val stopWords = setOf(
        "стоп", "хватит", "выключи", "отключи", "замолчи", "выключи будильник", "останови будильник",
        "выключи таймер", "останови таймер", "отключи будильник"
    )

    private class Dur(val ms: Long, val title: String)

    private fun strip(t: String, prefixes: List<String>): String? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t == p) return ""
            if (t.startsWith("$p ")) return t.removePrefix("$p ").trim()
        }
        return null
    }

    private fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    fun fmtDuration(ms: Long): String {
        val total = (ms + 999) / 1000
        val h = (total / 3600).toInt()
        val m = ((total % 3600) / 60).toInt()
        val s = (total % 60).toInt()
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h ${plural(h, "час", "часа", "часов")}")
        if (m > 0) parts.add("$m ${plural(m, "минута", "минуты", "минут")}")
        if (s > 0 && h == 0) parts.add("$s ${plural(s, "секунда", "секунды", "секунд")}")
        return if (parts.isEmpty()) "меньше секунды" else parts.joinToString(" ")
    }

    // ---------- планирование ----------

    private fun pending(ctx: Context, id: Long): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, (id % 1_000_000_000L).toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(ctx: Context, a: Store.Alarm) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, SecretaryActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(a.time, show), pending(ctx, a.id))
            Diag.log("будильник", "Поставлен (${a.kind}) на ${a.time}")
        } catch (e: Exception) {
            Diag.log("будильник", "Не удалось поставить: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id))
        Store.deleteAlarm(id)
    }

    fun nextOccurrence(hour: Int, minute: Int): Calendar {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_MONTH, 1)
        return c
    }

    fun createAlarmAt(ctx: Context, time: Long, label: String, repeat: Boolean): Store.Alarm {
        val a = Store.addAlarm("alarm", label, time, repeat)
        Memory.created("alarm", a.id, if (label.isBlank()) "будильник" else label)
        schedule(ctx, a)
        Diag.inc("будильников поставлено")
        return a
    }

    fun createAlarm(ctx: Context, hour: Int, minute: Int, label: String, repeat: Boolean): Store.Alarm =
        createAlarmAt(ctx, nextOccurrence(hour, minute).timeInMillis, label, repeat)

    fun createTimer(ctx: Context, durationMs: Long, label: String): Store.Alarm {
        val a = Store.addAlarm("timer", label, System.currentTimeMillis() + durationMs, false)
        Memory.created("timer", a.id, if (label.isBlank()) "таймер" else label)
        schedule(ctx, a)
        Diag.inc("таймеров поставлено")
        return a
    }

    fun snooze(ctx: Context, label: String) {
        createTimer(ctx, 5 * 60_000L, if (label.isBlank()) "Отложено" else label)
        Diag.log("будильник", "Отложено на 5 минут")
    }

    // После перезагрузки телефона или обновления приложения будильники ставятся заново
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        for (a in Store.allAlarms()) {
            if (a.time <= now) {
                if (a.repeatDaily) {
                    var next = a.time
                    while (next <= now) next += 86_400_000L
                    Store.updateAlarmTime(a.id, next)
                } else {
                    Store.deleteAlarm(a.id)
                    continue
                }
            }
            Store.findAlarm(a.id)?.let { schedule(ctx, it) }
        }
        Diag.log("будильник", "Будильники и таймеры поставлены заново")
    }

    // Сработал будильник или таймер
    fun onFired(ctx: Context, id: Long) {
        val a = Store.findAlarm(id) ?: return
        Diag.log("будильник", "Сработал (${a.kind})")
        if (a.repeatDaily) {
            var next = a.time
            val now = System.currentTimeMillis()
            while (next <= now) next += 86_400_000L
            Store.updateAlarmTime(a.id, next)
            Store.findAlarm(a.id)?.let { schedule(ctx, it) }
        } else {
            Store.deleteAlarm(a.id)
        }
        val intent = Intent(ctx, AlarmRingService::class.java)
            .putExtra("label", a.label)
            .putExtra("kind", a.kind)
        try {
            ctx.startForegroundService(intent)
        } catch (e: Exception) {
            Diag.log("будильник", "Не удалось запустить звонок: ${e.javaClass.simpleName}: ${e.message}")
            fallbackNotify(ctx, a)
        }
    }

    // Запасной вариант: обычное уведомление со звуком, если звонок запустить не удалось
    private fun fallbackNotify(ctx: Context, a: Store.Alarm) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna_alarm_fb", "Будильники Луны (запасной)", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = Notification.Builder(ctx, "luna_alarm_fb")
            .setContentTitle(if (a.kind == "timer") "Таймер сработал" else "Будильник")
            .setContentText(a.label)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        nm.notify((a.id % 1_000_000_000L).toInt() + 2000, n)
    }

    // ---------- разбор длительности ----------

    private fun unitMs(word: String?): Long? = when {
        word == null -> null
        word.startsWith("секунд") -> 1000L
        word.startsWith("минут") -> 60_000L
        word == "час" || word == "часа" || word == "часов" -> 3_600_000L
        else -> null
    }

    // «десять минут», «полчаса», «час тридцать минут», «тридцать секунд макароны»
    private fun parseDuration(text: String): Dur? {
        val w = text.lowercase().split(" ").filter { it.isNotBlank() }
        val used = BooleanArray(w.size)
        var total = 0L
        var i = 0
        while (i < w.size) {
            val t = w[i]
            if (t == "полчаса") {
                total += 1_800_000L
                used[i] = true
                i++
                continue
            }
            if (t == "полтора" && i + 1 < w.size && w[i + 1].startsWith("час")) {
                total += 5_400_000L
                used[i] = true
                used[i + 1] = true
                i += 2
                continue
            }
            var value = 0
            var j = i
            var any = false
            while (true) {
                val nb = DateParser.readNumber(w, j, 999) ?: break
                value += nb.first
                j = nb.second
                any = true
            }
            val unit = unitMs(w.getOrNull(j))
            if (unit != null) {
                val count = if (any) value else 1
                total += count.toLong() * unit
                for (k in i..j) used[k] = true
                i = j + 1
            } else {
                i++
            }
        }
        if (total <= 0) return null
        val restWords = w.filterIndexed { idx, _ -> !used[idx] }.toMutableList()
        // «на», «для» перед названием не нужны: «таймер на пять минут для пасты» -> «Пасты»
        while (restWords.isNotEmpty() && restWords.first() in setOf("на", "для", "под", "чтобы")) restWords.removeAt(0)
        return Dur(total, DateParser.cleanTitle(restWords.joinToString(" ")))
    }

    fun parseDurationMs(text: String): Long? = parseDuration(text)?.ms

    // Меняет время будильника или таймера
    fun reschedule(ctx: Context, id: Long, newTime: Long): Boolean {
        Store.findAlarm(id) ?: return false
        Store.updateAlarmTime(id, newTime)
        Store.findAlarm(id)?.let { schedule(ctx, it) }
        return true
    }

    // ---------- голосовые команды ----------

    fun isKnown(t: String): Boolean {
        if (!Features.on("alarms")) return false
        return strip(t, timerPrefixes) != null || strip(t, alarmPrefixes) != null || isQuery(t) || isCancel(t)
    }

    private fun isQuery(t: String): Boolean =
        t.contains("какие будильники") || t.contains("мои будильники") || t.contains("какие таймеры") ||
            t.contains("мои таймеры") || t.startsWith("сколько осталось") || t.contains("что на будильнике")

    private fun isCancel(t: String): Boolean =
        (t.contains("таймер") || t.contains("будильник")) &&
            listOf("отмени", "удали", "сбрось", "останови", "выключи", "отключи").any { t.contains(it) }

    fun handle(ctx: Context, t: String): Reply? {
        if (!Features.on("alarms")) return null

        // Будильник звонит: стоп или отложить
        if (AlarmRingService.ringing) {
            if (t in stopWords) {
                AlarmRingService.stop(ctx)
                return Reply("Выключила")
            }
            if (t.startsWith("отложи") || t.contains("еще пять минут") || t.contains("ещё пять минут")) {
                AlarmRingService.snooze(ctx)
                return Reply("Отложила на пять минут")
            }
        }

        val timer = strip(t, timerPrefixes)
        if (timer != null) return addTimer(ctx, timer)
        val alarm = strip(t, alarmPrefixes)
        if (alarm != null) return addAlarm(ctx, alarm)
        if (isQuery(t)) return listAll(t)
        if (isCancel(t)) return cancelByVoice(ctx, t)
        return null
    }

    private fun addTimer(ctx: Context, raw: String): Reply {
        val d = parseDuration(raw)
        if (d == null) {
            return Reply("На сколько поставить таймер?", Expect.TIME) { s ->
                val d2 = parseDuration(s.trim())
                if (d2 == null) Reply("Не поняла время") else makeTimer(ctx, d2)
            }
        }
        return makeTimer(ctx, d)
    }

    private fun makeTimer(ctx: Context, d: Dur): Reply {
        createTimer(ctx, d.ms, d.title)
        return Reply("Таймер: ${fmtDuration(d.ms)}" + if (d.title.isNotBlank()) ". ${d.title}" else "")
    }

    private fun addAlarm(ctx: Context, raw: String): Reply {
        var text = raw
        val repeat = repeatPhrases.any { text.contains(it) }
        for (p in repeatPhrases) text = text.replace(p, " ")
        val p = DateParser.parse(text.trim(), false, true)
        return finishAlarm(ctx, p.title, p.date, p.hour, p.minute, repeat, 0)
    }

    private fun finishAlarm(
        ctx: Context, title: String, date: Calendar?, hour: Int?, minute: Int?, repeat: Boolean, tries: Int
    ): Reply {
        if (hour == null) {
            if (tries >= 3) return Reply("Не получилось. Попробуйте ещё раз.")
            return Reply("На какое время?", Expect.TIME) { s ->
                val q = DateParser.parse(s.trim(), true, true)
                finishAlarm(ctx, title.ifBlank { q.title }, date ?: q.date, q.hour, q.minute, repeat, tries + 1)
            }
        }
        val min = minute ?: 0
        val cal: Calendar = if (date == null) {
            nextOccurrence(hour, min)
        } else {
            (date.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, min)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) return Reply("Это время уже прошло")
        createAlarmAt(ctx, cal.timeInMillis, title, repeat)
        Diag.log("будильник", "Будильник: ${Secretary.describe(cal)}, повтор: $repeat")
        return Reply(
            "Будильник ${Secretary.describe(cal)}" + (if (repeat) ", каждый день" else "") +
                (if (title.isNotBlank()) ". $title" else "")
        )
    }

    private fun describeAlarm(a: Store.Alarm): String {
        val cal = Calendar.getInstance().apply { timeInMillis = a.time }
        return Secretary.describe(cal) + (if (a.repeatDaily) ", каждый день" else "") +
            (if (a.label.isNotBlank()) " — ${a.label}" else "")
    }

    private fun listAll(t: String): Reply {
        val now = System.currentTimeMillis()
        val all = Store.allAlarms()
        val alarms = all.filter { it.kind == "alarm" }
        val timers = all.filter { it.kind == "timer" }
        if (t.startsWith("сколько осталось")) {
            val first = timers.firstOrNull() ?: return Reply("Таймеров нет")
            return Reply("Осталось " + fmtDuration(first.time - now))
        }
        if (all.isEmpty()) return Reply("Будильников и таймеров нет")
        val sb = StringBuilder()
        val onlyAlarms = t.contains("будильник")
        val onlyTimers = t.contains("таймер")
        if (alarms.isNotEmpty() && !onlyTimers) {
            sb.append("Будильники: ").append(alarms.joinToString(". ") { describeAlarm(it) }).append(". ")
        }
        if (timers.isNotEmpty() && !onlyAlarms) {
            sb.append("Таймеры: ").append(timers.joinToString(". ") {
                "осталось " + fmtDuration(it.time - now) + (if (it.label.isNotBlank()) " — ${it.label}" else "")
            })
        }
        val text = sb.toString().trim()
        return Reply(if (text.isEmpty()) "Ничего нет" else text)
    }

    private fun cancelByVoice(ctx: Context, t: String): Reply {
        val kind = if (t.contains("таймер")) "timer" else "alarm"
        val word = if (kind == "timer") "таймер" else "будильник"
        val list = Store.allAlarms().filter { it.kind == kind }
        if (list.isEmpty()) return Reply(if (kind == "timer") "Таймеров нет" else "Будильников нет")
        if (t.contains("все")) {
            return Reply("Удалить все: ${list.size}? Скажите да или нет.", Expect.YESNO) { s ->
                if (Secretary.isYes(s)) {
                    for (a in list) cancel(ctx, a.id)
                    Reply("Удалила")
                } else {
                    Reply("Хорошо, оставляю")
                }
            }
        }
        val first = list.first()
        cancel(ctx, first.id)
        Diag.log("будильник", "Отменён ($word)")
        return Reply(if (kind == "timer") "Таймер отменён" else "Будильник отменён")
    }
}
