package com.luna.assistant

import android.content.Context
import android.content.Intent
import android.widget.Toast

// Когда Луна не поняла: вместо отказа предлагает догадку («Вы сказали открой ютуб?») или задаёт уточняющий вопрос
object Understand {

    private val base = listOf(
        "открой ютуб", "открой телеграм", "открой ватсап", "открой камеру", "открой настройки", "открой хром",
        "громче", "тише", "без звука", "домой", "назад", "включи музыку", "пауза", "следующий трек",
        "предыдущий трек", "прочитай уведомления", "прочитай заметки", "запиши заметку", "что у меня запланировано",
        "поставь будильник", "поставь таймер", "какие будильники", "отмени таймер", "отмени будильник",
        "позвони", "отправь смс", "ответь", "сбрось", "громкая связь", "что ты умеешь", "что на экране",
        "сделай скриншот", "что ты услышала", "сколько будет", "создай сценарий", "какие сценарии"
    )

    private fun catalog(): List<String> {
        val list = ArrayList<String>(base)
        for (s in Store.allScenarios()) list.add(s.name)
        return list
    }

    private fun ratio(a: String, b: String): Double =
        Fuzzy.distance(a, b).toDouble() / maxOf(a.length, b.length, 1)

    // Ближайшая известная команда (по началу фразы); остаток фразы сохраняется как аргумент
    fun guess(t: String): String? {
        val tw = t.split(" ").filter { it.isNotBlank() }
        if (tw.isEmpty()) return null
        var best: String? = null
        var bestScore = 1.0
        var tie = false
        for (c in catalog()) {
            val cw = c.split(" ")
            if (tw.size < cw.size) continue
            val head = tw.take(cw.size).joinToString(" ")
            val d = ratio(head, c)
            if (d < bestScore) {
                bestScore = d
                best = c
                tie = false
            } else if (d == bestScore) {
                tie = true
            }
        }
        val b = best ?: return null
        if (tie || bestScore > 0.34) return null
        val rest = tw.drop(b.split(" ").size).joinToString(" ")
        val result = if (rest.isBlank()) b else "$b $rest"
        return if (result == t) null else result
    }

    fun suggestApp(ctx: Context, name: String): Reply? {
        if (name.isBlank()) return null
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val labels = pm.queryIntentActivities(launcher, 0).map { it.loadLabel(pm).toString().lowercase() }.distinct()
        var best: String? = null
        var bestScore = 1.0
        var tie = false
        for (l in labels) {
            val d = ratio(name, l)
            if (d < bestScore) {
                bestScore = d
                best = l
                tie = false
            } else if (d == bestScore) {
                tie = true
            }
        }
        val label = best ?: return null
        if (tie || bestScore > 0.4) return null
        return Reply("Не нашла «$name». Может, «$label»? Да или нет?", Expect.YESNO) { s ->
            if (Secretary.isYes(s)) {
                Aliases.addPhrase("открой $name", "открой $label")
                if (Commands.launch(ctx, label)) Reply("Открываю $label") else Reply("Не получилось открыть")
            } else {
                Reply("Хорошо")
            }
        }
    }

    private fun confirmGuess(ctx: Context, heard: String, guess: String): Reply {
        Diag.inc("догадок предложено")
        return Reply("Вы сказали «$guess»? Да или нет?", Expect.YESNO) { s ->
            if (Secretary.isYes(s)) {
                Aliases.learn(heard, guess)
                Commands.run(ctx, guess)
            } else {
                Reply("Что вы хотели сказать?") { s2 ->
                    val intended = s2.trim()
                    if (Commands.isKnown(intended)) Aliases.learn(heard, intended)
                    Commands.run(ctx, intended)
                }
            }
        }
    }

    // Уточняющие вопросы: «Позвонить или написать маме?», «Что поставить на это время?»
    private fun clarify(ctx: Context, t: String): Reply? {
        val words = t.split(" ").filter { it.isNotBlank() }
        if (words.size <= 2 && Features.on("phone") && Contacts.hasPermission(ctx)) {
            val found = Contacts.find(ctx, t)
            if (found.size == 1) {
                val name = found[0].name
                return Reply("Позвонить или написать $name?") { s ->
                    val a = s.lowercase()
                    when {
                        a.contains("позвон") -> Commands.run(ctx, "позвони $t")
                        a.contains("смс") || a.contains("напис") -> Reply("Что написать?") { text -> Commands.run(ctx, "отправь смс $t $text") }
                        else -> Reply("Хорошо")
                    }
                }
            }
        }
        if (words.size in 1..6) {
            val p = DateParser.parse(t, true)
            if (p.hour != null && p.title.isBlank()) {
                return Reply("Что поставить на это время: будильник или напоминание?") { s ->
                    val a = s.lowercase()
                    when {
                        a.contains("будильник") -> Commands.run(ctx, "поставь будильник $t")
                        a.contains("напомин") -> Reply("О чём напомнить?") { x -> Commands.run(ctx, "напомни $x $t") }
                        else -> Reply("Хорошо")
                    }
                }
            }
        }
        return null
    }

    private fun refusal(t: String): String = Style.pick(
        "refuse",
        "Не поняла. Я услышала: $t. Повторите, пожалуйста.",
        "Не расслышала. Скажите ещё раз или спросите: что ты умеешь.",
        "Что-то не разобрала: $t. Попробуйте сказать по-другому."
    )

    fun fallback(ctx: Context, t: String): Reply {
        Diag.inc("команд не поняла")
        Diag.log("разбор", "Команда не распознана как известная: «$t»")
        Toast.makeText(ctx, "Не поняла: $t", Toast.LENGTH_SHORT).show()
        // 1) другой вариант распознавания, который Луна понимает
        for (a in History.alternatives) {
            if (a != t && Commands.isKnown(a)) return confirmGuess(ctx, t, a)
        }
        // 2) похожая известная команда
        val g = guess(t)
        if (g != null && Commands.isKnown(g)) return confirmGuess(ctx, t, g)
        // 3) уточняющий вопрос
        val c = clarify(ctx, t)
        if (c != null) return c
        // 4) честный отказ, каждый раз по-разному
        return Reply(refusal(t))
    }
}
