package com.luna.assistant

// Приводит текст от распознавателя Google к виду, который понимают разборщики Луны:
// цифры -> слова («25» -> «двадцать пять»), «10:30» -> «десять тридцать», «+», «×», «%» -> слова
object TextNorm {

    private val ones = arrayOf("", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять")
    private val teens = arrayOf(
        "десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать",
        "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать"
    )
    private val tens = arrayOf(
        "", "", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто"
    )
    private val hundreds = arrayOf(
        "", "сто", "двести", "триста", "четыреста", "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот"
    )

    private fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    private fun triple(n: Int, female: Boolean): List<String> {
        val out = ArrayList<String>()
        if (n / 100 > 0) out.add(hundreds[n / 100])
        val r = n % 100
        if (r in 10..19) {
            out.add(teens[r - 10])
        } else {
            if (r / 10 >= 2) out.add(tens[r / 10])
            val o = r % 10
            if (o > 0) {
                out.add(
                    when {
                        female && o == 1 -> "одна"
                        female && o == 2 -> "две"
                        else -> ones[o]
                    }
                )
            }
        }
        return out
    }

    fun numberToWords(n: Long): String {
        if (n == 0L) return "ноль"
        if (n < 0 || n >= 1_000_000_000L) return n.toString()
        val parts = ArrayList<String>()
        val millions = (n / 1_000_000).toInt()
        val thousands = ((n / 1000) % 1000).toInt()
        val rest = (n % 1000).toInt()
        if (millions > 0) {
            parts.addAll(triple(millions, false))
            parts.add(plural(millions, "миллион", "миллиона", "миллионов"))
        }
        if (thousands > 0) {
            parts.addAll(triple(thousands, true))
            parts.add(plural(thousands, "тысяча", "тысячи", "тысяч"))
        }
        if (rest > 0) parts.addAll(triple(rest, false))
        return parts.joinToString(" ")
    }

    fun normalize(raw: String): String {
        var t = raw.lowercase().replace('ё', 'е')

        // время: 10:30 -> «десять тридцать», 9:05 -> «девять ноль пять», 9:00 -> «девять ноль ноль»
        t = Regex("""(\d{1,2}):(\d{2})""").replace(t) { m ->
            val h = m.groupValues[1].toLong()
            val mi = m.groupValues[2].toLong()
            val minutes = when {
                mi == 0L -> "ноль ноль"
                mi < 10 -> "ноль " + numberToWords(mi)
                else -> numberToWords(mi)
            }
            " " + numberToWords(h) + " " + minutes + " "
        }

        // десятичные: 1,5 -> «один целых пять десятых»
        t = Regex("""(\d+)[.,](\d+)""").replace(t) { m ->
            val whole = m.groupValues[1].toLongOrNull()
            val fracDigits = m.groupValues[2].take(3)
            val frac = fracDigits.toLongOrNull()
            if (whole == null || frac == null) {
                m.value
            } else {
                val divisor = when (fracDigits.length) {
                    1 -> "десятых"
                    2 -> "сотых"
                    else -> "тысячных"
                }
                " " + numberToWords(whole) + " целых " + numberToWords(frac) + " " + divisor + " "
            }
        }

        // знаки действий между числами и отдельно
        t = t.replace(Regex("""(?<=\d)\s*[xх×*]\s*(?=\d)"""), " умножить на ")
        t = t.replace(Regex("""(?<=\d)\s*[/÷]\s*(?=\d)"""), " разделить на ")
        t = t.replace(Regex("""(?<=\d)\s*[-−–—]\s*(?=\d)"""), " минус ")
        t = t.replace("+", " плюс ")
        t = t.replace("%", " процентов ")

        // остальные числа
        t = Regex("""\d+""").replace(t) { m ->
            val v = m.value.toLongOrNull()
            if (v == null) m.value else " " + numberToWords(v) + " "
        }

        t = t.replace(Regex("""[.,!?;:"«»()\[\]]"""), " ")
        t = t.replace(Regex("""\s+"""), " ").trim()
        return t
    }
}
