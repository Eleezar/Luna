package com.luna.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

// Напоминания: Луна сама будит телефон в нужное время и показывает уведомление
object Reminders {

    const val CHANNEL = "luna_reminders"

    private fun requestCode(id: Long): Int = (id % 1_000_000_000L).toInt()

    private fun pending(ctx: Context, id: Long, title: String): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("id", id)
            .putExtra("title", title)
        return PendingIntent.getBroadcast(
            ctx, requestCode(id), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(ctx: Context, ev: Store.Event) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, ev.id, ev.title)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.start, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.start, pi)
            Diag.log("напоминание", "Запланировано на ${ev.start} (точно: $exact): ${ev.title}")
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.start, pi)
            Diag.log("напоминание", "Нет права на точный будильник, поставлено приблизительное: ${ev.title}")
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id, ""))
    }

    // После перезагрузки телефона или обновления Луны будильники надо поставить заново
    fun rescheduleAll(ctx: Context) {
        val list = Store.upcoming(System.currentTimeMillis())
        for (ev in list) schedule(ctx, ev)
        Diag.log("напоминание", "Поставлено заново напоминаний: ${list.size}")
    }
}
