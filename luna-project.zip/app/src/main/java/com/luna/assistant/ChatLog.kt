package com.luna.assistant

// Журнал разговора для экрана «Разговор с Луной». Хранится только в памяти.
object ChatLog {

    class Entry(val time: Long, val who: String, val text: String, val note: String)

    private val items = ArrayList<Entry>()

    @Synchronized
    fun add(who: String, text: String, note: String = "") {
        if (text.isBlank()) return
        items.add(Entry(System.currentTimeMillis(), who, text, note))
        while (items.size > 300) items.removeAt(0)
    }

    @Synchronized
    fun all(): List<Entry> = items.toList()

    @Synchronized
    fun clear() = items.clear()
}
