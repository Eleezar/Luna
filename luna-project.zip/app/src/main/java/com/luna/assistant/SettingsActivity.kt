package com.luna.assistant

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale

// Голос и стиль ответов: кратко или подробно, скорость и высота голоса, выбор голоса, поправки и свои фразы
class SettingsActivity : Activity() {

    private lateinit var content: LinearLayout
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 48)
        }
        setContentView(ScrollView(this).apply { addView(content) })
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                ttsReady = true
                runOnUiThread { render() }
            }
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun header(label: String) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(0, 32, 0, 8)
    }

    private fun info(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
    }

    private fun radioGroup(options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        for ((key, label) in options) {
            g.addView(RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                tag = key
                isChecked = key == current
            })
        }
        g.setOnCheckedChangeListener { group, checkedId ->
            val key = group.findViewById<RadioButton>(checkedId)?.tag as? String
            if (key != null) onPick(key)
        }
        return g
    }

    private fun render() {
        content.removeAllViews()

        // --- стиль ---
        content.addView(header("Стиль ответов"))
        content.addView(radioGroup(
            listOf(
                "short" to "Кратко: только суть. Подробности по команде «подробнее»",
                "normal" to "Обычно: разные формулировки (рекомендую)",
                "detailed" to "Подробно: всегда полные ответы"
            ),
            Style.verbosity(this)
        ) { Style.setVerbosity(this, it) })
        content.addView(info("Можно и голосом: «говори кратко», «говори подробно», «говори обычно», «говори быстрее», «говори медленнее»."))

        // --- скорость ---
        content.addView(header("Скорость голоса"))
        val rateLabel = info("")
        fun rateText(r: Float) = "Скорость: ${"%.2f".format(Locale.US, r)}"
        rateLabel.text = rateText(Style.rate(this))
        content.addView(rateLabel)
        content.addView(SeekBar(this).apply {
            max = 100
            progress = (((Style.rate(this@SettingsActivity) - 0.6f) / 1.2f) * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val r = 0.6f + p / 100f * 1.2f
                    Style.setRate(this@SettingsActivity, r)
                    rateLabel.text = rateText(r)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })

        // --- высота ---
        content.addView(header("Высота голоса"))
        val pitchLabel = info("")
        fun pitchText(p: Float) = "Высота: ${"%.2f".format(Locale.US, p)}"
        pitchLabel.text = pitchText(Style.pitch(this))
        content.addView(pitchLabel)
        content.addView(SeekBar(this).apply {
            max = 100
            progress = (((Style.pitch(this@SettingsActivity) - 0.7f) / 0.8f) * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = 0.7f + p / 100f * 0.8f
                    Style.setPitch(this@SettingsActivity, v)
                    pitchLabel.text = pitchText(v)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })

        // --- голос ---
        content.addView(header("Голос"))
        val voices = if (ttsReady) {
            (tts?.voices ?: emptySet()).filter { it.locale.language == "ru" }.sortedBy { it.name }
        } else {
            emptyList()
        }
        if (!ttsReady) {
            content.addView(info("Загружаю голоса…"))
        } else if (voices.isEmpty()) {
            content.addView(info("Русских голосов не найдено. Установите «Службы распознавания и синтеза речи Google» и русский голос."))
        } else {
            val options = ArrayList<Pair<String, String>>()
            options.add("" to "Авто (голос по умолчанию)")
            for (v in voices) options.add(v.name to (v.name + if (v.isNetworkConnectionRequired) " (онлайн)" else ""))
            content.addView(radioGroup(options, Style.voiceName(this)) { Style.setVoiceName(this, it) })
        }
        content.addView(Button(this).apply {
            text = "Проверить голос"
            isAllCaps = false
            setOnClickListener { testVoice() }
        })

        // --- поправки ---
        content.addView(header("Поправки и свои фразы"))
        val words = Aliases.allWords()
        val phrases = Aliases.allPhrases()
        if (words.isEmpty() && phrases.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «когда я говорю спать, делай сценарий вечер» или поправьте Луну: «нет, я сказал открой ютуб»."))
        }
        for ((k, v) in phrases) {
            content.addView(aliasRow("Фраза «$k» → $v") {
                Aliases.removePhrase(k)
                render()
            })
        }
        for ((k, v) in words) {
            content.addView(aliasRow("Слово «$k» → «$v»") {
                Aliases.removeWord(k)
                render()
            })
        }
        if (words.isNotEmpty() || phrases.isNotEmpty()) {
            content.addView(Button(this).apply {
                text = "Забыть всё"
                isAllCaps = false
                setOnClickListener {
                    Aliases.clear()
                    render()
                }
            })
        }
    }

    private fun aliasRow(label: String, onDelete: () -> Unit): LinearLayout {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
            addView(
                TextView(ctx).apply {
                    text = label
                    textSize = 15f
                },
                LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(Button(ctx).apply {
                text = "Удалить"
                isAllCaps = false
                textSize = 12f
                setOnClickListener { onDelete() }
            })
        }
    }

    private fun testVoice() {
        val t = tts ?: return
        if (!ttsReady) return
        t.setSpeechRate(Style.rate(this))
        t.setPitch(Style.pitch(this))
        val name = Style.voiceName(this)
        if (name.isNotEmpty()) {
            t.voices?.firstOrNull { it.name == name }?.let { t.voice = it }
        }
        t.speak("Привет! Я Луна. Так я теперь звучу. Будильник на семь тридцать, двадцать первого ноября.", TextToSpeech.QUEUE_FLUSH, null, "test")
    }
}
