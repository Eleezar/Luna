package com.luna.assistant

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

// Следит за состоянием звонка: Луна объявляет входящий («Звонит Мама. Ответить?») и умеет включать громкую связь
object CallMonitor {

    @Volatile
    var state: Int = TelephonyManager.CALL_STATE_IDLE

    private var callback: Any? = null
    private val handler = Handler(Looper.getMainLooper())

    fun start(ctx: Context) {
        if (callback != null) return
        if (Build.VERSION.SDK_INT < 31) {
            Diag.set("Слежение за звонками", "нужен Android 12 или новее")
            return
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            Diag.set("Слежение за звонками", "нет разрешения на состояние телефона")
            return
        }
        try {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    onState(ctx, state)
                }
            }
            tm.registerTelephonyCallback(ctx.mainExecutor, cb)
            callback = cb
            Diag.set("Слежение за звонками", "включено")
            Diag.log("звонки", "Слежение за звонками включено")
        } catch (e: Exception) {
            Diag.set("Слежение за звонками", "ошибка: ${e.message}")
            Diag.log("звонки", "Не удалось включить слежение: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun stop(ctx: Context) {
        val cb = callback as? TelephonyCallback ?: return
        try {
            ctx.getSystemService(TelephonyManager::class.java).unregisterTelephonyCallback(cb)
        } catch (e: Exception) {
        }
        callback = null
    }

    private fun onState(ctx: Context, s: Int) {
        val prev = state
        state = s
        Diag.log("звонки", "Состояние звонка: $s")
        if (!Features.on("phone")) return
        when (s) {
            TelephonyManager.CALL_STATE_RINGING -> {
                if (Features.onOr("callannounce", true)) handler.postDelayed({ announceIncoming(ctx) }, 800)
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (prev != TelephonyManager.CALL_STATE_OFFHOOK && Features.onOr("call_speaker", false)) {
                    handler.postDelayed({ Phone.setSpeaker(ctx, true) }, 1500)
                }
            }
        }
    }

    // Имя звонящего берём из уведомления о звонке (нужен доступ к уведомлениям)
    private fun callerName(): String? {
        return try {
            LunaNotificationListener.instance?.activeNotifications
                ?.firstOrNull { it.notification.category == Notification.CATEGORY_CALL }
                ?.notification?.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun announceIncoming(ctx: Context) {
        if (state != TelephonyManager.CALL_STATE_RINGING) return
        val name = callerName()
        Diag.inc("входящих звонков объявлено")
        val text = if (name.isNullOrBlank()) "Входящий звонок. Ответить?" else "Звонит $name. Ответить?"
        VoiceService.announceReply(Reply(text, Expect.YESNO) { s -> Phone.answerOrReject(ctx, s) })
    }
}
