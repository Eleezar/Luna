package com.luna.assistant

import android.content.Context

// Диалоги о самой Луне: «что ты умеешь», «как поставить будильник», «почему ты не включила музыку»,
// «что ты услышала», «повтори», «что в сценарии вечер».
object Help {

    private class Category(
        val name: String,
        val keywords: List<String>,
        val feature: String?,
        val text: String
    )

    private val categories = listOf(
        Category("приложения и громкость", listOf("приложен", "открыв", "громкост", "громче", "тише", "ютуб", "домой"), null,
            "Скажите: открой ютуб, запусти телеграм, громче, тише, громкость тридцать, домой."),
        Category("заметки", listOf("заметк"), "notes",
            "Скажите: запиши заметку купить хлеб. Прочитай заметки. Удали последнюю заметку."),
        Category("события и напоминания", listOf("событ", "календар", "напомин", "запланир"), "events",
            "Скажите: напомни позвонить врачу завтра в десять утра. Что у меня запланировано. Удали последнее событие."),
        Category("будильники и таймеры", listOf("будильник", "таймер", "разбуд"), "alarms",
            "Скажите: поставь будильник на семь тридцать. Таймер на десять минут. Какие будильники. Отмени таймер."),
        Category("калькулятор", listOf("счита", "калькулятор", "сколько будет", "посчит"), null,
            "Скажите: сколько будет двадцать пять умножить на четыре. Двадцать процентов от пятисот. Корень из шестнадцати."),
        Category("звонки", listOf("звон", "позвон", "трубк", "громкая связь", "ответить"), "phone",
            "Скажите: позвони маме. Когда звонит: ответь или сбрось. Включи громкую связь. Перед набором я спрошу подтверждение."),
        Category("смс", listOf("смс", "ммс"), "phone",
            "Скажите: отправь смс маме буду через час. Перед отправкой я прочитаю текст и спрошу подтверждение."),
        Category("ответы в мессенджерах", listOf("мессендж", "телеграм", "ватсап", "вайбер", "ответь"), "messenger",
            "Скажите: ответь Ивану буду через час. Напиши в телеграм Ивану привет. Перед отправкой я спрошу подтверждение."),
        Category("уведомления", listOf("уведомлен"), "device",
            "Скажите: прочитай уведомления. Очисти уведомления."),
        Category("управление экраном", listOf("экран", "нажми", "прокрут", "скриншот"), "device",
            "Скажите: нажми отправить. Напиши привет. Прокрути вниз. Что на экране. Сделай скриншот. Назад."),
        Category("сценарии", listOf("сценар", "режим"), "scenarios",
            "Скажите: создай сценарий вечер громкость тридцать потом включи музыку потом открой телеграм. Потом просто: вечер."),
        Category("музыка", listOf("музык", "трек", "пауз", "плеер"), "device",
            "Скажите: включи музыку. Пауза. Следующий трек. Предыдущий трек. Нужен открытый плеер.")
    )

    private val capabilityPhrases = setOf(
        "что ты умеешь", "что ты можешь", "что умеешь", "помощь", "помоги", "что можно сказать", "какие у тебя команды",
        "какие команды", "что ты умеешь делать", "что ты можешь делать", "что ты умеешь делать расскажи"
    )
    private val identityPhrases = setOf("кто ты", "ты кто", "как тебя зовут", "что ты такое", "представься")
    private val helloPhrases = setOf("привет", "здравствуй", "здравствуйте", "доброе утро", "добрый день", "добрый вечер")
    private val statusPhrases = setOf(
        "как дела", "как ты", "как твои дела", "как ты слышишь", "как твоё состояние", "как твое состояние",
        "статус", "твой статус", "ты меня слышишь", "ты здесь", "проверка связи"
    )
    private val repeatPhrases = setOf("повтори", "повтори ещё раз", "повтори еще раз", "что ты сказала", "что ты сейчас сказала")
    private val whyStarts = listOf("почему", "объясни", "что пошло не так", "отчего")

    private fun categoryFor(t: String): Category? = categories.firstOrNull { c -> c.keywords.any { t.contains(it) } }

    private fun detail(c: Category): Reply {
        val off = if (c.feature != null && !Features.on(c.feature)) " Сейчас эта возможность выключена: включите её на экране «Секретарь»." else ""
        return Reply(c.text + off)
    }

    private fun scenarioQuestionName(t: String): String? {
        if (!t.contains("сценари")) return null
        if (listOf("что в", "что делает", "расскажи про", "из чего состоит", "что внутри", "покажи").none { t.contains(it) }) return null
        val name = t.substringAfterLast("сценари").substringAfter(" ", "").trim()
        return if (name.isBlank()) null else name
    }

    private fun isWhy(t: String) =
        whyStarts.any { t.startsWith(it) } || t.contains("не сработало") || t.contains("ты не включила") ||
            t.contains("ты не сделала") || t.contains("почему не")

    private fun isHeard(t: String) =
        t.startsWith("что ты услышала") || t == "что ты слышала" || t.contains("что ты поняла") || t.startsWith("что ты услыша")

    private fun isHowTo(t: String) = (t.startsWith("как ") || t.startsWith("как мне ")) && categoryFor(t) != null

    fun isKnown(t: String): Boolean =
        t in capabilityPhrases || t in identityPhrases || t in helloPhrases || t in statusPhrases || t in repeatPhrases ||
            isWhy(t) || isHeard(t) || isHowTo(t) || scenarioQuestionName(t) != null || t.contains("спасибо")

    fun handle(ctx: Context, t: String): Reply? {
        // повторить последний ответ
        if (t in repeatPhrases) {
            val s = History.lastSpoken
            return if (s.isBlank()) Reply("Я ещё ничего не говорила") else Reply(s)
        }
        // что услышала
        if (isHeard(t)) {
            val h = History.lastHeard
            if (h.isBlank()) return Reply("Я пока ничего не слышала")
            val raw = History.lastHeardRaw
            return Reply("Я услышала: $h." + if (raw.isNotBlank() && raw != h) " Распознавание написало: $raw." else "")
        }
        // что в сценарии
        val sn = scenarioQuestionName(t)
        if (sn != null) {
            val sc = Scenarios.find(sn) ?: return Reply("Сценария $sn нет")
            val steps = sc.steps.withIndex().joinToString(". ") { "${it.index + 1}: ${it.value}" }
            return Reply("Сценарий ${sc.name}. $steps")
        }
        // почему не получилось
        if (isWhy(t)) return why(ctx, t)
        // что умеешь
        if (t in capabilityPhrases) {
            val names = categories.joinToString(", ") { it.name }
            return Reply("Я умею: $names. Про что рассказать подробнее?") { s ->
                val c = categoryFor(s.lowercase())
                if (c == null) Reply("Не поняла, про что. Скажите, например: про звонки или про сценарии.") else detail(c)
            }
        }
        // как сделать
        if (isHowTo(t)) {
            val c = categoryFor(t) ?: return null
            return detail(c)
        }
        // кто ты
        if (t in identityPhrases) {
            return Reply("Я Луна, голосовой ассистент на вашем телефоне. Слушаю слово Луна, выполняю команды, веду заметки и помогаю со звонками.")
        }
        if (t in helloPhrases) return Reply("Привет! Слушаю.")
        if (t.contains("спасибо")) return Reply("Пожалуйста.")
        // состояние
        if (t in statusPhrases) return Reply(statusText())
        return null
    }

    private fun statusText(): String {
        val ok = Diag.counter("слово «Луна» услышано")
        val rej = Diag.counter("слово «Луна» отклонено")
        val heard = Diag.counter("команд распознано")
        val bad = Diag.counter("команд не поняла")
        val engine = Diag.stateOf("Распознавание команд") ?: "не определено"
        return "Я здесь и слушаю. Слово Луна принято $ok, отклонено $rej. Команд распознано $heard, не поняла $bad. Распознавание: $engine."
    }

    // Почему не получилось: находим подходящее действие и объясняем
    private fun why(ctx: Context, t: String): Reply {
        val topic = History.domainOf(t)
        val action = if (topic == "other") (History.lastFailure() ?: History.last()) else History.findForTopic(topic)
        if (action == null) {
            val off = History.featureOffReason(topic)
            if (off != null) return Reply(off)
            return Reply("Я не выполняла такой команды. Возможно, я не расслышала. Спросите: что ты услышала?")
        }
        return Reply(History.explain(ctx, action, topic))
    }
}
