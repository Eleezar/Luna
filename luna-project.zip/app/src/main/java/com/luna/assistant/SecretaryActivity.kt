package com.luna.assistant

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// Экран секретаря: всё, что Луна записала, можно смотреть, добавлять, править и удалять вручную.
// Заметки, события, таймеры и будильники, сценарии, а также включение и выключение возможностей.
class SecretaryActivity : Activity() {

    private lateinit var content: LinearLayout
    private val dateFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 48)
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- вспомогательное ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun header(label: String) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(0, 32, 0, 8)
    }

    private fun info(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun row(label: String, onClick: (() -> Unit)? = null, onDelete: () -> Unit): LinearLayout {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
            addView(
                TextView(ctx).apply {
                    text = label
                    textSize = 15f
                    if (onClick != null) setOnClickListener { onClick() }
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(Button(ctx).apply {
                text = "Удалить"
                isAllCaps = false
                textSize = 12f
                setOnClickListener { onDelete() }
            })
        }
    }

    private fun editText(hint: String, initial: String = "", multiline: Boolean = false, numeric: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(initial)
            if (multiline) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 3
                gravity = Gravity.TOP
            } else if (numeric) {
                inputType = InputType.TYPE_CLASS_NUMBER
            }
        }

    private fun box(vararg views: android.view.View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), 0)
        for (v in views) addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun askText(title: String, initial: String, multiline: Boolean, onOk: (String) -> Unit) {
        val et = editText("", initial, multiline)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box(et))
            .setPositiveButton("Сохранить") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) onOk(s)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pickDateTime(initial: Long, onPicked: (Long) -> Unit) {
        val c = Calendar.getInstance().apply {
            timeInMillis = if (initial > 0) initial else System.currentTimeMillis() + 3_600_000L
        }
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val r = Calendar.getInstance().apply {
                    set(y, m, d, h, min, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                onPicked(r.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---------- вывод экрана ----------

    private fun render() {
        content.removeAllViews()
        val now = System.currentTimeMillis()

        // --- возможности ---
        content.addView(header("Возможности секретаря"))
        content.addView(info("Выключенное Луна не будет выполнять и не будет предлагать."))
        for ((key, label) in Features.all) {
            content.addView(Switch(this).apply {
                text = label
                isChecked = Features.on(key)
                setOnCheckedChangeListener { _, checked -> Features.set(this@SecretaryActivity, key, checked) }
            })
        }

        content.addView(Switch(this).apply {
            text = "Объявлять входящие звонки голосом"
            isChecked = Features.onOr("callannounce", true)
            setOnCheckedChangeListener { _, checked -> Features.set(this@SecretaryActivity, "callannounce", checked) }
        })
        content.addView(Switch(this).apply {
            text = "Включать громкую связь при звонках"
            isChecked = Features.onOr("call_speaker", false)
            setOnCheckedChangeListener { _, checked -> Features.set(this@SecretaryActivity, "call_speaker", checked) }
        })

        // --- заметки ---
        val notes = Store.allNotes().sortedByDescending { it.id }
        content.addView(header("Заметки (${notes.size})"))
        content.addView(button("＋ Добавить заметку") {
            askText("Новая заметка", "", true) { text ->
                Store.addNote(text)
                render()
            }
        })
        if (notes.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «Луна», сигнал, «запиши заметку купить хлеб»."))
        }
        for (n in notes) {
            content.addView(row("${dateFmt.format(Date(n.time))}\n${n.text}", {
                askText("Изменить заметку", n.text, true) { text ->
                    Store.updateNote(n.id, text)
                    render()
                }
            }) {
                Store.deleteNote(n.id)
                render()
            })
        }
        if (notes.isNotEmpty()) {
            content.addView(button("Поделиться заметками") {
                val body = notes.joinToString("\n\n") { "${dateFmt.format(Date(it.time))}\n${it.text}" }
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                startActivity(Intent.createChooser(send, "Заметки"))
            })
        }

        // --- события ---
        val events = Store.allEvents()
        content.addView(header("События (${events.size})"))
        content.addView(button("＋ Добавить событие") {
            askText("Название события", "", false) { title ->
                pickDateTime(0L) { ms ->
                    if (ms <= System.currentTimeMillis()) toast("Это время уже прошло") else saveEvent(null, title, ms)
                    render()
                }
            }
        })
        if (events.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «напомни позвонить врачу завтра в десять утра»."))
        }
        for (ev in events) {
            val mark = if (ev.start < now) "прошло: " else ""
            val sys = if (ev.sysId >= 0) "  (в календаре телефона)" else ""
            content.addView(row("$mark${dateFmt.format(Date(ev.start))}  ${ev.title}$sys", {
                askText("Название события", ev.title, false) { title ->
                    pickDateTime(ev.start) { ms ->
                        if (ms <= System.currentTimeMillis()) toast("Это время уже прошло") else saveEvent(ev, title, ms)
                        render()
                    }
                }
            }) {
                Reminders.cancel(this, ev.id)
                CalendarSync.delete(this, ev.sysId)
                Store.deleteEvent(ev.id)
                render()
            })
        }

        // --- будильники и таймеры ---
        val alarms = Store.allAlarms()
        content.addView(header("Будильники и таймеры (${alarms.size})"))
        content.addView(button("＋ Добавить будильник") { alarmDialog(null) })
        content.addView(button("＋ Добавить таймер") { timerDialog() })
        if (alarms.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «поставь будильник на семь тридцать» или «таймер на десять минут»."))
        }
        for (a in alarms) {
            val label = if (a.label.isBlank()) "" else " — ${a.label}"
            if (a.kind == "alarm") {
                val whenText = if (a.repeatDaily) "${timeFmt.format(Date(a.time))}, каждый день" else dateFmt.format(Date(a.time))
                content.addView(row("Будильник $whenText$label", { alarmDialog(a) }) {
                    Alarms.cancel(this, a.id)
                    render()
                })
            } else {
                content.addView(row("Таймер: осталось ${Alarms.fmtDuration(a.time - now)}$label") {
                    Alarms.cancel(this, a.id)
                    render()
                })
            }
        }

        // --- сценарии ---
        val scenarios = Store.allScenarios()
        content.addView(header("Сценарии (${scenarios.size})"))
        content.addView(button("＋ Добавить сценарий") { scenarioDialog(null) })
        if (scenarios.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «создай сценарий вечер громкость тридцать потом включи музыку потом открой телеграм»."))
        }
        for (sc in scenarios) {
            content.addView(row("${sc.name}: ${sc.steps.joinToString(" → ")}", { scenarioDialog(sc) }) {
                Store.deleteScenario(sc.name)
                render()
            })
        }

        // --- состояние ---
        content.addView(header("Состояние"))
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        content.addView(info("Точные напоминания: ${if (exact) "разрешены" else "НЕ разрешены (могут опаздывать)"}"))
        content.addView(info("Календарь телефона: ${if (CalendarSync.hasPermission(this)) "доступ есть" else "нет доступа, события хранятся только в Луне (кнопка «Разрешить календарь» на главном экране)"}"))
    }

    // ---------- диалоги правки ----------

    private fun saveEvent(old: Store.Event?, title: String, start: Long) {
        if (old != null) {
            Reminders.cancel(this, old.id)
            CalendarSync.delete(this, old.sysId)
            Store.deleteEvent(old.id)
        }
        val sysId = CalendarSync.insert(this, title, start)
        val ev = Store.addEvent(title, start, sysId)
        Reminders.schedule(this, ev)
        Diag.log("секретарь", "Событие записано вручную")
    }

    private fun scenarioDialog(old: Store.Scenario?) {
        val nameEt = editText("Название (например: вечер)", old?.name ?: "")
        val stepsEt = editText(
            "Шаги, по одному в строке. Например:\nгромкость тридцать\nвключи музыку\nоткрой телеграм",
            old?.steps?.joinToString("\n") ?: "", multiline = true
        )
        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Новый сценарий" else "Изменить сценарий")
            .setView(box(nameEt, stepsEt))
            .setPositiveButton("Сохранить") { _, _ ->
                val name = nameEt.text.toString().trim().lowercase()
                val steps = stepsEt.text.toString().lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }
                if (name.isEmpty() || steps.isEmpty()) {
                    toast("Нужны название и хотя бы один шаг")
                } else {
                    if (old != null && old.name != name) Store.deleteScenario(old.name)
                    Store.addScenario(name, steps)
                    val unknown = steps.filter { !Scenarios.validStep(it) }
                    if (unknown.isNotEmpty()) toast("Луна может не понять шаги: ${unknown.joinToString("; ")}")
                    render()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun alarmDialog(old: Store.Alarm?) {
        val tp = TimePicker(this).apply {
            setIs24HourView(true)
            val c = Calendar.getInstance().apply {
                timeInMillis = old?.time ?: (System.currentTimeMillis() + 3_600_000L)
            }
            hour = c.get(Calendar.HOUR_OF_DAY)
            minute = c.get(Calendar.MINUTE)
        }
        val labelEt = editText("Название (необязательно)", old?.label ?: "")
        val rep = CheckBox(this).apply {
            text = "Каждый день"
            isChecked = old?.repeatDaily ?: false
        }
        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Новый будильник" else "Изменить будильник")
            .setView(box(tp, labelEt, rep))
            .setPositiveButton("Сохранить") { _, _ ->
                if (old != null) Alarms.cancel(this, old.id)
                Alarms.createAlarm(this, tp.hour, tp.minute, labelEt.text.toString().trim(), rep.isChecked)
                render()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun timerDialog() {
        val minEt = editText("Минут", "5", numeric = true)
        val secEt = editText("Секунд", "0", numeric = true)
        val labelEt = editText("Название (необязательно)", "")
        AlertDialog.Builder(this)
            .setTitle("Новый таймер")
            .setView(box(minEt, secEt, labelEt))
            .setPositiveButton("Запустить") { _, _ ->
                val min = minEt.text.toString().toLongOrNull() ?: 0L
                val sec = secEt.text.toString().toLongOrNull() ?: 0L
                val ms = (min * 60 + sec) * 1000L
                if (ms <= 0) {
                    toast("Укажите время")
                } else {
                    Alarms.createTimer(this, ms, labelEt.text.toString().trim())
                    render()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
