package com.luna.assistant

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Экран секретаря: заметки и события, которые Луна записала (хранятся в самой Луне)
class SecretaryActivity : Activity() {

    private lateinit var content: LinearLayout
    private val dateFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 48)
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun header(label: String) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(0, 32, 0, 8)
    }

    private fun info(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
    }

    private fun row(label: String, onDelete: () -> Unit): LinearLayout {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
            addView(
                TextView(ctx).apply { text = label; textSize = 15f },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(Button(ctx).apply {
                text = "Удалить"
                isAllCaps = false
                textSize = 12f
                setOnClickListener { onDelete() }
            })
        }
    }

    private fun render() {
        content.removeAllViews()
        val now = System.currentTimeMillis()

        val notes = Store.allNotes().sortedByDescending { it.id }
        content.addView(header("Заметки (${notes.size})"))
        if (notes.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «Луна», сигнал, «запиши заметку купить хлеб»."))
        }
        for (n in notes) {
            content.addView(row("${dateFmt.format(Date(n.time))}\n${n.text}") {
                Store.deleteNote(n.id)
                render()
            })
        }

        val events = Store.allEvents()
        content.addView(header("События (${events.size})"))
        if (events.isEmpty()) {
            content.addView(info("Пока пусто. Скажите: «Луна», сигнал, «напомни позвонить врачу завтра в десять утра»."))
        }
        for (ev in events) {
            val mark = if (ev.start < now) "прошло: " else ""
            val sys = if (ev.sysId >= 0) "  (в календаре телефона)" else ""
            content.addView(row("$mark${dateFmt.format(Date(ev.start))}  ${ev.title}$sys") {
                Reminders.cancel(this, ev.id)
                CalendarSync.delete(this, ev.sysId)
                Store.deleteEvent(ev.id)
                render()
            })
        }

        if (notes.isNotEmpty()) {
            content.addView(Button(this).apply {
                text = "Поделиться заметками"
                isAllCaps = false
                setOnClickListener {
                    val body = notes.joinToString("\n\n") { "${dateFmt.format(Date(it.time))}\n${it.text}" }
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, body)
                    }
                    startActivity(Intent.createChooser(send, "Заметки"))
                }
            })
        }

        content.addView(header("Состояние"))
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        content.addView(info("Точные напоминания: ${if (exact) "разрешены" else "НЕ разрешены (могут опаздывать)"}"))
        content.addView(info("Календарь телефона: ${if (CalendarSync.hasPermission(this)) "доступ есть" else "нет доступа, события хранятся только в Луне (кнопка «Разрешить календарь» на главном экране)"}"))
    }
}
