package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Собственное хранилище секретаря: заметки, события и сценарии. Работает на любом телефоне, не зависит от других приложений.
object Store {

    class Note(val id: Long, val time: Long, val text: String)
    class Event(val id: Long, val title: String, val start: Long, val sysId: Long = -1L)
    class Scenario(val name: String, val steps: List<String>)

    private val notes = ArrayList<Note>()
    private val events = ArrayList<Event>()
    private val scenarios = ArrayList<Scenario>()
    private var file: File? = null

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "secretary.json")
        load()
    }

    @Synchronized
    private fun load() {
        notes.clear()
        events.clear()
        scenarios.clear()
        val f = file ?: return
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            val na = root.optJSONArray("notes") ?: JSONArray()
            for (i in 0 until na.length()) {
                val o = na.getJSONObject(i)
                notes.add(Note(o.getLong("id"), o.getLong("time"), o.getString("text")))
            }
            val ea = root.optJSONArray("events") ?: JSONArray()
            for (i in 0 until ea.length()) {
                val o = ea.getJSONObject(i)
                events.add(Event(o.getLong("id"), o.getString("title"), o.getLong("start"), o.optLong("sys", -1L)))
            }
            val sa = root.optJSONArray("scenarios") ?: JSONArray()
            for (i in 0 until sa.length()) {
                val o = sa.getJSONObject(i)
                val steps = ArrayList<String>()
                val arr = o.optJSONArray("steps") ?: JSONArray()
                for (k in 0 until arr.length()) steps.add(arr.getString(k))
                scenarios.add(Scenario(o.getString("name"), steps))
            }
            Diag.log("секретарь", "Загружено: заметок ${notes.size}, событий ${events.size}, сценариев ${scenarios.size}")
        } catch (e: Exception) {
            Diag.log("секретарь", "Не удалось прочитать данные: ${e.message}")
        }
    }

    @Synchronized
    private fun save() {
        val f = file ?: return
        try {
            val root = JSONObject()
            val na = JSONArray()
            for (n in notes) na.put(JSONObject().put("id", n.id).put("time", n.time).put("text", n.text))
            val ea = JSONArray()
            for (e in events) ea.put(JSONObject().put("id", e.id).put("title", e.title).put("start", e.start).put("sys", e.sysId))
            val sa = JSONArray()
            for (s in scenarios) {
                val arr = JSONArray()
                for (step in s.steps) arr.put(step)
                sa.put(JSONObject().put("name", s.name).put("steps", arr))
            }
            root.put("notes", na)
            root.put("events", ea)
            root.put("scenarios", sa)
            f.writeText(root.toString())
        } catch (e: Exception) {
            Diag.log("секретарь", "Не удалось сохранить данные: ${e.message}")
        }
    }

    private fun newId(): Long {
        var id = System.currentTimeMillis()
        val max = maxOf(notes.maxOfOrNull { it.id } ?: 0L, events.maxOfOrNull { it.id } ?: 0L)
        if (id <= max) id = max + 1
        return id
    }

    // ---- заметки ----
    @Synchronized
    fun addNote(text: String): Note {
        val n = Note(newId(), System.currentTimeMillis(), text)
        notes.add(n)
        save()
        return n
    }

    @Synchronized
    fun allNotes(): List<Note> = notes.toList()

    @Synchronized
    fun deleteNote(id: Long): Boolean {
        val removed = notes.removeAll { it.id == id }
        if (removed) save()
        return removed
    }

    @Synchronized
    fun deleteLastNote(): Note? {
        val last = notes.maxByOrNull { it.id } ?: return null
        notes.remove(last)
        save()
        return last
    }

    @Synchronized
    fun clearNotes(): Int {
        val n = notes.size
        notes.clear()
        save()
        return n
    }

    // ---- события ----
    @Synchronized
    fun addEvent(title: String, start: Long, sysId: Long = -1L): Event {
        val e = Event(newId(), title, start, sysId)
        events.add(e)
        save()
        return e
    }

    @Synchronized
    fun allEvents(): List<Event> = events.sortedBy { it.start }

    @Synchronized
    fun upcoming(now: Long): List<Event> = events.filter { it.start >= now }.sortedBy { it.start }

    @Synchronized
    fun deleteEvent(id: Long): Boolean {
        val removed = events.removeAll { it.id == id }
        if (removed) save()
        return removed
    }

    @Synchronized
    fun lastAddedEvent(): Event? = events.maxByOrNull { it.id }

    // ---- сценарии ----
    @Synchronized
    fun addScenario(name: String, steps: List<String>) {
        scenarios.removeAll { it.name == name }
        scenarios.add(Scenario(name, steps.toList()))
        save()
    }

    @Synchronized
    fun allScenarios(): List<Scenario> = scenarios.toList()

    @Synchronized
    fun deleteScenario(name: String): Boolean {
        val removed = scenarios.removeAll { it.name == name }
        if (removed) save()
        return removed
    }
}
