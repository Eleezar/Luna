package com.luna.assistant

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

// Маршрутизация звука для Bluetooth-гарнитуры: без неё её микрофон не включается
object AudioRoute {

    private var scoStarted = false
    private var commSet = false

    fun isBluetooth(d: AudioDeviceInfo?): Boolean =
        d != null && (d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || d.type == 26) // 26 = BLE-гарнитура

    fun apply(ctx: Context, device: AudioDeviceInfo?) {
        val dev = device ?: return
        if (!isBluetooth(dev)) return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val list = am.availableCommunicationDevices
                val target = list.firstOrNull { it.type == dev.type && it.address == dev.address }
                    ?: list.firstOrNull { it.type == dev.type }
                if (target != null) {
                    commSet = am.setCommunicationDevice(target)
                    Diag.log("микрофон", "Bluetooth-гарнитура выбрана для связи: $commSet")
                } else {
                    Diag.log("микрофон", "Bluetooth-гарнитура недоступна для связи (нет в списке устройств)")
                }
            } else {
                @Suppress("DEPRECATION")
                am.startBluetoothSco()
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = true
                scoStarted = true
                Diag.log("микрофон", "Включён Bluetooth SCO")
            }
        } catch (e: Exception) {
            Diag.log("микрофон", "Не удалось включить Bluetooth-микрофон: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun release(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (commSet && Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
                commSet = false
            }
            if (scoStarted) {
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = false
                @Suppress("DEPRECATION")
                am.stopBluetoothSco()
                scoStarted = false
            }
        } catch (e: Exception) {
            Diag.log("микрофон", "Не удалось отключить Bluetooth-маршрут: ${e.message}")
        }
    }
}
