package com.luna.assistant

import android.content.Context

// Как Луна говорит: разные формулировки, кратко или подробно, правильное чтение времени и дат, скорость и голос
object Style {

    @Volatile
    var lastFull = ""

    // Следующий ответ произнести как есть (для команды «подробнее»)
    @Volatile
    var verbatimNext = false

    private val rnd = java.util.Random()
    private val lastPick = HashMap<String, Int>()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE)

    fun verbosity(ctx: Context): String = prefs(ctx).getString("verbosity", "normal") ?: "normal"
    fun setVerbosity(ctx: Context, v: String) = prefs(ctx).edit().putString("verbosity", v).apply()

    fun rate(ctx: Context): Float = prefs(ctx).getFloat("tts_rate", 1.0f)
    fun setRate(ctx: Context, v: Float) = prefs(ctx).edit().putFloat("tts_rate", v.coerceIn(0.6f, 1.8f)).apply()

    fun pitch(ctx: Context): Float = prefs(ctx).getFloat("tts_pitch", 1.0f)
    fun setPitch(ctx: Context, v: Float) = prefs(ctx).edit().putFloat("tts_pitch", v.coerceIn(0.7f, 1.5f)).apply()

    fun voiceName(ctx: Context): String = prefs(ctx).getString("tts_voice", "") ?: ""
    fun setVoiceName(ctx: Context, v: String) = prefs(ctx).edit().putString("tts_voice", v).apply()

    // Выбирает один из вариантов, не повторяя прошлый выбор для того же ключа
    fun pick(key: String, vararg options: String): String {
        if (options.size == 1) return options[0]
        var i = rnd.nextInt(options.size)
        if (i == lastPick[key]) i = (i + 1) % options.size
        lastPick[key] = i
        return options[i]
    }

    private const val MONTHS = "января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря"

    private val ordinalGen = mapOf(
        1 to "первого", 2 to "второго", 3 to "третьего", 4 to "четвёртого", 5 to "пятого", 6 to "шестого",
        7 to "седьмого", 8 to "восьмого", 9 to "девятого", 10 to "десятого", 11 to "одиннадцатого",
        12 to "двенадцатого", 13 to "тринадцатого", 14 to "четырнадцатого", 15 to "пятнадцатого",
        16 to "шестнадцатого", 17 to "семнадцатого", 18 to "восемнадцатого", 19 to "девятнадцатого",
        20 to "двадцатого", 30 to "тридцатого"
    )

    private fun dayWords(d: Int): String = when {
        ordinalGen.containsKey(d) -> ordinalGen.getValue(d)
        d in 21..29 -> "двадцать " + ordinalGen.getValue(d - 20)
        d == 31 -> "тридцать первого"
        else -> d.toString()
    }

    private fun hourWord(h: Int): String {
        val m100 = h % 100
        val m10 = h % 10
        return when {
            m100 in 11..14 -> "часов"
            m10 == 1 -> "час"
            m10 in 2..4 -> "часа"
            else -> "часов"
        }
    }

    // Чтение времени и дат словами: «7:00» -> «семь часов», «21 ноября» -> «двадцать первого ноября»
    fun speakable(text: String): String {
        var t = Regex("""(\d{1,2}):(\d{2})""").replace(text) { m ->
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toLong()
            val hw = TextNorm.numberToWords(h.toLong())
            when {
                mi == 0L -> "$hw ${hourWord(h)}"
                mi < 10 -> "$hw ноль ${TextNorm.numberToWords(mi)}"
                else -> "$hw ${TextNorm.numberToWords(mi)}"
            }
        }
        t = Regex("""(\d{1,2}) ($MONTHS)""").replace(t) { m -> dayWords(m.groupValues[1].toInt()) + " " + m.groupValues[2] }
        return t
    }

    // Меняет формулировку и длину ответа. Полный текст запоминается для команды «подробнее»
    fun polish(ctx: Context, text: String): String {
        if (verbatimNext) {
            verbatimNext = false
            return speakable(text)
        }
        lastFull = speakable(text)
        val mode = verbosity(ctx)
        val chosen = variant(text, mode) ?: shorten(text, mode)
        return speakable(chosen)
    }

    private fun variant(text: String, mode: String): String? {
        Regex("""^Записала заметку: (.+)$""").matchEntire(text)?.let { m ->
            val body = m.groupValues[1]
            return when (mode) {
                "short" -> "Записала."
                "detailed" -> text
                else -> pick("note", text, "Готово, записала: $body", "Записано: $body")
            }
        }
        Regex("""^Записала: (.+?), ((?:сегодня|завтра|послезавтра|[а-яё]+, \d{1,2} [а-яё]+) в \d{1,2}:\d{2})$""")
            .matchEntire(text)?.let { m ->
                val title = m.groupValues[1]
                val whenText = m.groupValues[2]
                return when (mode) {
                    "short" -> "Записала на $whenText."
                    "detailed" -> text
                    else -> pick("event", text, "Поставила на $whenText: $title", "Готово. $title, $whenText")
                }
            }
        Regex("""^Открываю (.+)$""").matchEntire(text)?.let { m ->
            val name = m.groupValues[1]
            return when (mode) {
                "short" -> "Открываю."
                "detailed" -> text
                else -> pick("open", text, "Сейчас открою $name", "Уже открываю $name")
            }
        }
        Regex("""^Таймер: (.+)$""").matchEntire(text)?.let { m ->
            return when (mode) {
                "short" -> "Таймер запущен."
                "detailed" -> text
                else -> pick("timer", text, "Поставила таймер: ${m.groupValues[1]}")
            }
        }
        Regex("""^Будильник (.+)$""").matchEntire(text)?.let { m ->
            return when (mode) {
                "short" -> "Будильник поставлен."
                "detailed" -> text
                else -> pick("alarm", text, "Поставила будильник ${m.groupValues[1]}")
            }
        }
        if (text == "Отправила") {
            return when (mode) {
                "detailed" -> text
                else -> pick("sent", "Отправила", "Готово, отправила", "Отправлено")
            }
        }
        return null
    }

    // В коротком режиме длинный ответ сокращается до первого предложения
    private fun shorten(text: String, mode: String): String {
        if (mode != "short" || text.contains("?") || text.length <= 100) return text
        val first = text.split(". ").first().trimEnd('.')
        return if (first.length < text.length - 10) "$first. Скажите: подробнее." else text
    }
}
