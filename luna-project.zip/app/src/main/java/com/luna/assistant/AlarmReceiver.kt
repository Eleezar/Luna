package com.luna.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Alarms.onFired(ctx, intent.getLongExtra("id", 0L))
    }
}
