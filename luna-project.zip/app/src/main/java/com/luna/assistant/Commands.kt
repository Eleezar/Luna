package com.luna.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.media.AudioManager
import android.net.Uri
import android.widget.Toast

object Commands {

    // Как говорим -> как приложение называется на телефоне (часть названия)
    internal val appAliases = mapOf(
        "ютуб" to "youtube", "телеграм" to "telegram", "ватсап" to "whatsapp",
        "хром" to "chrome", "вайбер" to "viber", "инстаграм" to "instagram",
        "карты" to "maps", "камера" to "camera", "настройки" to "settings",
        "дром" to "drom", "яндекс" to "yandex", "вконтакте" to "vk"
    )

    private val sites = mapOf(
        "ютуб" to "https://youtube.com", "гугл" to "https://google.com",
        "яндекс" to "https://ya.ru", "вк" to "https://vk.com", "дром" to "https://drom.ru",
        "youtube" to "https://youtube.com", "google" to "https://google.com"
    )

    private val numbers = mapOf(
        "ноль" to 0, "один" to 1, "два" to 2, "три" to 3, "четыре" to 4, "пять" to 5,
        "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10,
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90, "сто" to 100
    )

    // Названия приложений и сайтов, которые Луна знает по-русски
    fun knownNames(): Set<String> = appAliases.keys + sites.keys

    // Приложение, название которого содержит искомое слово
    fun findApp(ctx: Context, name: String): ResolveInfo? {
        val needle = appAliases[name] ?: name
        if (needle.isBlank()) return null
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(needle)
        }
    }

    // Запускает приложение по названию. false, если такого нет
    fun launch(ctx: Context, name: String): Boolean {
        val app = findApp(ctx, name) ?: return false
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return false
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    // Похоже ли распознанное на команду, которую Луна умеет (без выполнения). Нужно для выбора лучшего варианта
    fun isKnown(raw: String): Boolean {
        val t = raw.lowercase().trim()
        if (t.isEmpty()) return false
        if (Secretary.isDictation(t) || Secretary.isQuery(t) || Device.isKnown(t) ||
            Scenarios.isKnown(t) || Messenger.isKnown(t) || Alarms.isKnown(t) || Phone.isKnown(t)
        ) return true
        if (listOf("сколько", "посчитай", "вычисли", "реши", "громкость").any { t.startsWith(it) }) return true
        if (t == "домой" || t.contains("громче") || t.contains("тише") || t.contains("без звука") ||
            t.contains("выключи звук") || t.contains("сверни")
        ) return true
        val verb = listOf("открой", "запусти", "включи").firstOrNull { t.startsWith("$it ") }
        if (verb != null) {
            val name = t.removePrefix("$verb ").trim()
            if (name in knownNames()) return true
            val ctx = LunaApp.ctx
            return ctx != null && findApp(ctx, name) != null
        }
        return false
    }

    // Выполняет команду и возвращает ответ, который Луна произнесёт вслух
    fun run(ctx: Context, raw: String): Reply {
        val t = raw.lowercase().trim()
        if (t.isEmpty()) return Reply(null)
        Diag.log("разбор", "Разбираю команду: «$t»")

        // секретарь: заметки и события
        val secretary = Secretary.handle(ctx, t)
        if (secretary != null) return secretary

        // звонок идёт или звонит телефон: ответить, сбросить, громкая связь
        val phoneControl = Phone.control(ctx, t)
        if (phoneControl != null) return phoneControl

        // таймеры и будильники
        val alarms = Alarms.handle(ctx, t)
        if (alarms != null) return alarms

        // сценарии: одна фраза запускает цепочку команд
        val scenario = Scenarios.handle(ctx, t)
        if (scenario != null) return scenario

        // ответы в мессенджерах
        val messenger = Messenger.handle(ctx, t)
        if (messenger != null) return messenger

        // звонки и SMS по имени из контактов
        val phone = Phone.handle(ctx, t)
        if (phone != null) return phone

        // управление телефоном: уведомления, нажатия, прокрутка, чтение экрана, музыка
        val device = Device.handle(ctx, t)
        if (device != null) return device

        val calcPrefix = listOf("сколько будет", "сколько", "посчитай", "вычисли", "реши")
            .firstOrNull { t.startsWith(it) }
        if (calcPrefix != null) return Reply(calc(t.removePrefix(calcPrefix).trim()))

        val text: String = when {
            t.startsWith("громкость") -> setVolume(ctx, t.removePrefix("громкость").trim())
            t.contains("громче") -> { adjust(ctx, AudioManager.ADJUST_RAISE); "Громче" }
            t.contains("тише") -> { adjust(ctx, AudioManager.ADJUST_LOWER); "Тише" }
            t.contains("без звука") || t.contains("выключи звук") -> { adjust(ctx, AudioManager.ADJUST_MUTE); "Без звука" }
            t == "домой" || t.contains("сверни") -> { goHome(ctx); "Хорошо" }
            else -> {
                val prefix = listOf("открой", "запусти", "включи").firstOrNull { t.startsWith(it) }
                if (prefix != null) {
                    open(ctx, t.removePrefix(prefix).trim())
                } else {
                    Diag.inc("команд не поняла")
                    Diag.log("разбор", "Команда не распознана как известная: «$t»")
                    toast(ctx, "Не поняла: $t")
                    "Не поняла"
                }
            }
        }
        return Reply(text)
    }

    private fun calc(expr: String): String {
        val r = Calc.evaluate(expr)
        if (r == null) {
            Diag.inc("примеров не разобрала")
            Diag.log("калькулятор", "Не удалось разобрать пример: «$expr»")
            return "Не поняла пример"
        }
        if (r.isNaN() || r.isInfinite()) return "На ноль делить нельзя"
        Diag.log("калькулятор", "«$expr» = $r")
        return "Получится " + Calc.format(r)
    }

    private fun open(ctx: Context, name: String): String {
        if (name.isEmpty()) return "Что открыть?"
        if (launch(ctx, name)) return "Открываю $name"
        val url = sites[name]
        if (url != null) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Открываю $name"
        }
        Diag.inc("приложение не найдено")
        Diag.log("разбор", "Не нашла приложение или сайт: «$name» (искала «${appAliases[name] ?: name}»)")
        toast(ctx, "Не нашла: $name")
        return "Не нашла $name"
    }

    private fun audio(ctx: Context) = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun adjust(ctx: Context, direction: Int) {
        audio(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun setVolume(ctx: Context, words: String): String {
        val found = words.split(" ").mapNotNull { numbers[it] }
        if (found.isEmpty()) return "Скажите, какую громкость"
        val percent = found.sum().coerceIn(0, 100)
        val am = audio(ctx)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * percent / 100, AudioManager.FLAG_SHOW_UI)
        return "Громкость $percent"
    }

    private fun goHome(ctx: Context) {
        ctx.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}
