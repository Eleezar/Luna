package com.luna.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.widget.Toast

object Commands {

    // Как говорим -> как приложение называется на телефоне (часть названия)
    private val appAliases = mapOf(
        "ютуб" to "youtube", "телеграм" to "telegram", "ватсап" to "whatsapp",
        "хром" to "chrome", "вайбер" to "viber", "инстаграм" to "instagram",
        "карты" to "maps", "камера" to "camera", "настройки" to "settings",
        "дром" to "drom", "яндекс" to "yandex"
    )

    private val sites = mapOf(
        "ютуб" to "https://youtube.com", "гугл" to "https://google.com",
        "яндекс" to "https://ya.ru", "вк" to "https://vk.com", "дром" to "https://drom.ru"
    )

    private val numbers = mapOf(
        "ноль" to 0, "один" to 1, "два" to 2, "три" to 3, "четыре" to 4, "пять" to 5,
        "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10,
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90, "сто" to 100
    )

    fun run(ctx: Context, raw: String) {
        val t = raw.lowercase().trim()
        when {
            t.startsWith("громкость") -> setVolume(ctx, t.removePrefix("громкость").trim())
            t.contains("громче") -> adjust(ctx, AudioManager.ADJUST_RAISE)
            t.contains("тише") -> adjust(ctx, AudioManager.ADJUST_LOWER)
            t.contains("без звука") || t.contains("выключи звук") -> adjust(ctx, AudioManager.ADJUST_MUTE)
            t == "домой" || t.contains("сверни") -> goHome(ctx)
            else -> {
                val prefix = listOf("открой", "запусти", "включи").firstOrNull { t.startsWith(it) }
                if (prefix != null) open(ctx, t.removePrefix(prefix).trim())
                else toast(ctx, "Не поняла: $t")
            }
        }
    }

    private fun open(ctx: Context, name: String) {
        if (name.isEmpty()) return
        val needle = appAliases[name] ?: name
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(needle)
        }
        if (app != null) {
            val intent = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
            if (intent != null) { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return }
        }
        val url = sites[name]
        if (url != null) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            toast(ctx, "Не нашла: $name")
        }
    }

    private fun audio(ctx: Context) = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun adjust(ctx: Context, direction: Int) {
        audio(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun setVolume(ctx: Context, words: String) {
        val percent = words.split(" ").mapNotNull { numbers[it] }.sum().coerceIn(0, 100)
        val am = audio(ctx)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * percent / 100, AudioManager.FLAG_SHOW_UI)
    }

    private fun goHome(ctx: Context) {
        ctx.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}
