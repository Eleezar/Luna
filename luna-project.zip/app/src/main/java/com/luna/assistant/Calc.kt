package com.luna.assistant

import java.util.Locale

// Голосовой калькулятор: «двадцать пять умножить на четыре», «сто разделить на восемь»,
// «двадцать процентов от пятисот», «пять в квадрате», «корень из шестнадцати»,
// «одна целая пять десятых плюс два».
object Calc {

    internal val units = mapOf(
        "ноль" to 0, "нуль" to 0, "один" to 1, "одна" to 1, "одно" to 1, "одну" to 1,
        "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6,
        "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10, "одиннадцать" to 11,
        "двенадцать" to 12, "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15,
        "шестнадцать" to 16, "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19,
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90,
        // формы после «от», «из» («от пятисот», «из шестнадцати»)
        "двух" to 2, "трёх" to 3, "трех" to 3, "четырёх" to 4, "четырех" to 4, "пяти" to 5, "шести" to 6, "семи" to 7, "восьми" to 8, "девяти" to 9, "десяти" to 10, "одиннадцати" to 11, "двенадцати" to 12, "тринадцати" to 13, "четырнадцати" to 14, "пятнадцати" to 15, "шестнадцати" to 16, "семнадцати" to 17, "восемнадцати" to 18, "девятнадцати" to 19, "двадцати" to 20, "тридцати" to 30, "сорока" to 40, "пятидесяти" to 50, "шестидесяти" to 60, "семидесяти" to 70, "восьмидесяти" to 80, "девяноста" to 90, "ста" to 100, "двухсот" to 200, "трёхсот" to 300, "трехсот" to 300, "четырёхсот" to 400, "четырехсот" to 400, "пятисот" to 500, "шестисот" to 600, "семисот" to 700, "восьмисот" to 800, "девятисот" to 900,
        "сто" to 100, "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500,
        "шестьсот" to 600, "семьсот" to 700, "восемьсот" to 800, "девятьсот" to 900
    )

    private fun fractionDivisor(w: String): Int? = when (w) {
        "десятых", "десятая", "десятые" -> 10
        "сотых", "сотая", "сотые" -> 100
        "тысячных", "тысячная", "тысячные" -> 1000
        else -> null
    }

    // Превращает фразу в список: числа (Double) и операции (String)
    private fun tokenize(text: String): List<Any> {
        val out = mutableListOf<Any>()
        var total = 0L
        var current = 0L
        var inNum = false
        var base: Double? = null

        fun flush() {
            if (inNum) {
                out.add((total + current).toDouble())
                total = 0; current = 0; inNum = false
            }
        }

        for (w in text.lowercase().split(" ").filter { it.isNotBlank() }) {
            val v = units[w]
            val div = fractionDivisor(w)
            when {
                v != null -> { current += v; inNum = true }
                div != null -> {
                    out.add((base ?: 0.0) + (total + current).toDouble() / div)
                    base = null; total = 0; current = 0; inNum = false
                }
                w.startsWith("тысяч") -> {
                    total += (if (current == 0L) 1L else current) * 1000L
                    current = 0; inNum = true
                }
                w.startsWith("миллион") -> {
                    total += (if (current == 0L) 1L else current) * 1_000_000L
                    current = 0; inNum = true
                }
                w.startsWith("цел") -> {
                    base = (total + current).toDouble()
                    total = 0; current = 0; inNum = false
                }
                else -> {
                    flush()
                    when {
                        w == "плюс" || w == "прибавить" -> out.add("+")
                        w == "минус" || w == "отнять" || w == "вычесть" -> out.add("-")
                        w.startsWith("умнож") || w.startsWith("помнож") -> out.add("*")
                        w.startsWith("раздел") || w.startsWith("подел") -> out.add("/")
                        w.startsWith("процент") -> out.add("%")
                        w == "квадрате" || w == "квадрат" -> out.add("^2")
                        w == "кубе" || w == "куб" -> out.add("^3")
                        w == "корень" -> out.add("sqrt")
                        // остальные слова («на», «из», «от», «и», «будет») пропускаем
                    }
                }
            }
        }
        flush()
        return out
    }

    // Считает список; null — если пример не удалось разобрать
    private fun compute(items: List<Any>): Double? {
        if (items.isEmpty()) return null
        var i = 0
        var negate = false
        if (items[0] == "-") { negate = true; i++ }

        fun readNumber(): Double? {
            var sqrt = false
            if (i < items.size && items[i] == "sqrt") { sqrt = true; i++ }
            val x = items.getOrNull(i) as? Double ?: return null
            i++
            var r = x
            while (i < items.size && (items[i] == "^2" || items[i] == "^3")) {
                r = if (items[i] == "^2") r * r else r * r * r
                i++
            }
            if (sqrt) r = Math.sqrt(r)
            return r
        }

        val vals = mutableListOf<Double>()
        val ops = mutableListOf<String>()
        var first = readNumber() ?: return null
        if (negate) first = -first
        vals.add(first)
        while (i < items.size) {
            val op = items[i] as? String ?: return null
            i++
            val n = readNumber() ?: return null
            ops.add(op)
            vals.add(n)
        }

        // Сначала умножение, деление и проценты, потом плюс и минус
        var k = 0
        while (k < ops.size) {
            val op = ops[k]
            if (op == "*" || op == "/" || op == "%") {
                val a = vals[k]
                val b = vals[k + 1]
                vals[k] = when (op) {
                    "*" -> a * b
                    "/" -> a / b
                    else -> a * b / 100.0
                }
                vals.removeAt(k + 1)
                ops.removeAt(k)
            } else {
                k++
            }
        }
        var result = vals[0]
        for (j in ops.indices) {
            result = if (ops[j] == "+") result + vals[j + 1] else result - vals[j + 1]
        }
        return result
    }

    fun evaluate(text: String): Double? = compute(tokenize(text))

    fun format(x: Double): String {
        if (x < 0) return "минус " + format(-x)
        if (x == Math.rint(x) && x < 1e15) return x.toLong().toString()
        return String.format(Locale.US, "%.4f", x).trimEnd('0').trimEnd('.').replace('.', ',')
    }
}
