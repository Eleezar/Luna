package com.luna.assistant

import org.json.JSONArray

// Узкие словари для офлайн-распознавания, когда Луна знает, какого ответа ждать
// («Во сколько?» — только числа и слова времени). Так модель почти не ошибается.
object Grammars {

    private val timeWords = listOf(
        "утра", "дня", "вечера", "ночи", "половине", "половину", "четверть", "без", "полдень", "полночь",
        "час", "часа", "часов", "минут", "минуты", "минуту", "ноль", "нуль", "в", "через", "полчаса"
    )
    private val dateWords = listOf(
        "сегодня", "завтра", "послезавтра", "на", "числа", "неделю", "недели", "недель",
        "день", "дня", "дней", "следующий", "следующую", "следующее"
    )
    private val yesNoWords = listOf(
        "да", "нет", "давай", "конечно", "отмена", "не", "надо", "ага", "удаляй", "подтверждаю"
    )

    // null — свободная речь (полный словарь)
    fun json(expect: Expect): String? {
        val words: Collection<String> = when (expect) {
            Expect.FREE -> return null
            Expect.YESNO -> yesNoWords
            Expect.TIME -> Calc.units.keys + timeWords
            Expect.DATETIME ->
                Calc.units.keys + timeWords + dateWords + DateParser.ordinals.keys +
                    DateParser.months.keys + DateParser.weekdays.keys
        }
        val list = LinkedHashSet<String>(words)
        list.add("[unk]")
        return JSONArray(list.toList()).toString()
    }
}
