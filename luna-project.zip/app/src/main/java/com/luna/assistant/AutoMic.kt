package com.luna.assistant

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

// Автоматический выбор микрофона: Луна сама проверяет, какое устройство и какой источник звука работают,
// и выбирает лучший. Мёртвый микрофон (из него идёт цифровая тишина) отсеивается без участия человека.
object AutoMic {

    @Volatile
    var lastProbeAt = 0L

    @Volatile
    var lastProbeEnd = 0L

    private val sourceOrder = listOf(
        Triple("auto", MediaRecorder.AudioSource.VOICE_RECOGNITION, "стандартный источник"),
        Triple("mic", MediaRecorder.AudioSource.MIC, "MIC"),
        Triple("comm", MediaRecorder.AudioSource.VOICE_COMMUNICATION, "VOICE_COMMUNICATION")
    )

    class Candidate(val device: AudioDeviceInfo?, val sourceKey: String, val source: Int)
    class Stat(val peakPct: Int, val peakRaw: Int, val rms: Double, val routed: String)
    class Result(val deviceKey: String, val sourceKey: String, val label: String, val ok: Boolean)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE)

    fun chosenDevice(ctx: Context): String = prefs(ctx).getString("auto_device", "") ?: ""
    fun chosenSource(ctx: Context): String = prefs(ctx).getString("auto_source", "auto") ?: "auto"
    fun btFirst(ctx: Context): Boolean = prefs(ctx).getBoolean("auto_bt_first", false)
    fun setBtFirst(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("auto_bt_first", v).apply()

    private fun save(ctx: Context, deviceKey: String, sourceKey: String) {
        prefs(ctx).edit().putString("auto_device", deviceKey).putString("auto_source", sourceKey).apply()
    }

    // Проводная и USB-гарнитура, потом микрофон телефона, потом Bluetooth (у него хуже звук и расход батареи)
    private fun priority(d: AudioDeviceInfo, btFirst: Boolean): Int = when (d.type) {
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> 0
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> 1
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> 2
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26 -> if (btFirst) -1 else 3
        else -> 99
    }

    private fun sourceLabel(key: String): String = sourceOrder.firstOrNull { it.first == key }?.third ?: key

    private fun label(c: Candidate): String =
        (c.device?.let { Diag.deviceName(it) } ?: "стандартное устройство") + ", " + sourceLabel(c.sourceKey)

    private fun candidates(ctx: Context): List<Candidate> {
        val bt = btFirst(ctx)
        val devices = AudioConfig.inputs(ctx).filter { priority(it, bt) < 99 }.sortedBy { priority(it, bt) }
        val out = ArrayList<Candidate>()
        if (devices.isEmpty()) {
            for ((key, id, _) in sourceOrder) out.add(Candidate(null, key, id))
        } else {
            for (d in devices) for ((key, id, _) in sourceOrder) out.add(Candidate(d, key, id))
        }
        return out
    }

    // Записывает звук с кандидата и считает уровень. Живой микрофон даёт шум (пик от 4), мёртвый даёт ноль
    private fun measure(ctx: Context, c: Candidate, ms: Long): Stat {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return Stat(0, 0, 0.0, "не поддерживается")
        var rec: AudioRecord? = null
        val bt = AudioRoute.isBluetooth(c.device)
        try {
            if (bt) {
                AudioRoute.apply(ctx, c.device)
                Thread.sleep(1200) // гарнитуре нужно время на переход в режим звонка
            }
            rec = AudioRecord(c.source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            if (rec.state != AudioRecord.STATE_INITIALIZED) return Stat(0, 0, 0.0, "не открылся")
            val dev = c.device
            if (dev != null) rec.setPreferredDevice(dev)
            rec.startRecording()
            val buf = ShortArray(1600)
            val end = SystemClock.elapsedRealtime() + ms
            var peak = 0
            var sumSq = 0.0
            var count = 0L
            while (SystemClock.elapsedRealtime() < end) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                for (i in 0 until n) {
                    val v = abs(buf[i].toInt())
                    if (v > peak) peak = v
                    sumSq += v.toDouble() * v
                }
                count += n
            }
            val routed = rec.routedDevice?.let { Diag.deviceName(it) } ?: "неизвестно"
            val rms = if (count > 0) sqrt(sumSq / count) else 0.0
            return Stat(peak * 100 / 32768, peak, rms, routed)
        } catch (e: Exception) {
            return Stat(0, 0, 0.0, "ошибка: ${e.message}")
        } finally {
            try { rec?.stop() } catch (e: Exception) { }
            rec?.release()
            if (bt) AudioRoute.release(ctx)
        }
    }

    private fun isAlive(s: Stat) = s.peakRaw >= 4

    // Полная проверка (блокирующая, вызывать не из главного потока).
    // speech = true: человек говорит «раз, два, три», выбирается самый громкий рабочий источник.
    fun probe(ctx: Context, speech: Boolean, progress: ((String) -> Unit)? = null): Result {
        lastProbeAt = SystemClock.elapsedRealtime()
        try {
            val tested = ArrayList<Pair<Candidate, Stat>>()
            for (c in candidates(ctx)) {
                progress?.invoke("Проверяю: ${label(c)}")
                val s = measure(ctx, c, if (speech) 1500 else 900)
                tested.add(c to s)
                Diag.log(
                    "автомикрофон",
                    "${label(c)}: пик ${s.peakPct}% (сырой ${s.peakRaw}), устройство: ${s.routed}"
                )
                // без речи достаточно первого живого кандидата по приоритету
                if (!speech && isAlive(s)) break
            }
            val alive = tested.filter { isAlive(it.second) }
            if (alive.isEmpty()) {
                Diag.log("автомикрофон", "Ни один источник не слышит")
                return Result("", "auto", "", false)
            }
            val first = alive.first()
            val loudest = alive.maxByOrNull { it.second.peakRaw } ?: first
            // самый громкий выбирается, только если он заметно громче первого по приоритету
            val chosen = if (speech && loudest.second.peakRaw > first.second.peakRaw * 1.5 && loudest.second.peakPct >= 8) {
                loudest
            } else {
                first
            }
            val c = chosen.first
            val deviceKey = c.device?.let { AudioConfig.keyOf(it) } ?: ""
            save(ctx, deviceKey, c.sourceKey)
            Diag.log("автомикрофон", "Выбрано: ${label(c)}")
            return Result(deviceKey, c.sourceKey, label(c), true)
        } finally {
            lastProbeEnd = SystemClock.elapsedRealtime()
        }
    }

    // Быстрая проверка при запуске: если прошлый выбор жив, полный перебор не нужен
    fun quickCheck(ctx: Context): Result {
        val dk = chosenDevice(ctx)
        val sk = chosenSource(ctx)
        val dev = AudioConfig.findDevice(ctx, dk)
        if (dk.isEmpty() || dev != null) {
            val c = Candidate(dev, sk, AudioConfig.sourceId(sk))
            val s = measure(ctx, c, 900)
            if (isAlive(s)) {
                lastProbeEnd = SystemClock.elapsedRealtime()
                Diag.log("автомикрофон", "Прошлый выбор работает: ${label(c)}")
                return Result(dk, sk, label(c), true)
            }
        }
        return probe(ctx, false)
    }

    fun describeResult(r: Result): String =
        if (r.ok) "Выбрала: ${r.label}" else "Не нашла микрофон, который слышит. Проверьте разрешение на микрофон или подключите гарнитуру."

    // ---------- голосовые команды ----------

    private val calibratePhrases = setOf(
        "подбери микрофон", "выбери микрофон", "выбери микрофон сама", "проверь микрофон", "проверь микрофоны",
        "найди микрофон", "настрой микрофон", "подбери микрофон сама", "настрой микрофон сама"
    )
    private val whichPhrases = setOf("откуда ты слышишь", "какой микрофон", "через что ты слышишь", "какой у тебя микрофон")

    fun isKnown(t: String): Boolean = t in calibratePhrases || t in whichPhrases

    fun handle(ctx: Context, t: String): Reply? {
        if (t in whichPhrases) return Reply("Слушаю через ${AudioConfig.describe(ctx)}")
        if (t in calibratePhrases) {
            VoiceService.requestCalibration()
            return Reply("Хорошо. Говорите «раз, два, три» без остановки, пока я проверяю микрофоны. Это займёт около десяти секунд.")
        }
        return null
    }
}
