package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

// Откуда Луна слышит: источник звука и устройство ввода (микрофон телефона, гарнитура, USB, Bluetooth)
class AudioSourceActivity : Activity() {

    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var level: ProgressBar
    private var testing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 48)
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun header(label: String) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(0, 32, 0, 8)
    }

    private fun info(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
    }

    private fun render() {
        content.removeAllViews()
        content.addView(info(
            "Здесь можно выбрать, откуда Луна слушает: другой источник звука телефона, проводную гарнитуру, " +
                "USB-микрофон или Bluetooth-гарнитуру. Если основной микрофон не работает, попробуйте другой источник " +
                "и проверьте кнопкой внизу. Изменения действуют сразу, для Bluetooth перезапустите Луну."
        ))

        // --- источник звука ---
        content.addView(header("Источник звука"))
        val srcGroup = RadioGroup(this)
        val currentSource = AudioConfig.sourceKey(this)
        for ((key, label) in AudioConfig.sources) {
            srcGroup.addView(RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                tag = key
                isChecked = key == currentSource
            })
        }
        srcGroup.setOnCheckedChangeListener { g, checkedId ->
            val key = g.findViewById<RadioButton>(checkedId)?.tag as? String
            if (key != null) {
                AudioConfig.save(this, source = key)
                Diag.log("микрофон", "Выбран источник звука: $key")
            }
        }
        content.addView(srcGroup)

        // --- устройство ввода ---
        content.addView(header("Устройство ввода"))
        val devGroup = RadioGroup(this)
        val currentDevice = AudioConfig.deviceKey(this)
        devGroup.addView(RadioButton(this).apply {
            text = "Авто (стандартное)"
            id = View.generateViewId()
            tag = ""
            isChecked = currentDevice.isEmpty()
        })
        val devices = AudioConfig.inputs(this)
        for (d in devices) {
            val key = AudioConfig.keyOf(d)
            devGroup.addView(RadioButton(this).apply {
                text = Diag.deviceName(d)
                id = View.generateViewId()
                tag = key
                isChecked = key == currentDevice
            })
        }
        devGroup.setOnCheckedChangeListener { g, checkedId ->
            val key = g.findViewById<RadioButton>(checkedId)?.tag as? String
            if (key != null) {
                AudioConfig.save(this, device = key)
                Diag.log("микрофон", "Выбрано устройство ввода")
            }
        }
        content.addView(devGroup)
        content.addView(Button(this).apply {
            text = "Обновить список устройств"
            isAllCaps = false
            setOnClickListener { render() }
        })
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            content.addView(Button(this).apply {
                text = "Разрешить доступ к Bluetooth (для гарнитур)"
                isAllCaps = false
                setOnClickListener {
                    requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
                }
            })
        }

        content.addView(info(
            "Распознавание Google получает звук из выбранного источника (Android 13 и новее). " +
                "Если Google его не примет, Луна сама перейдёт на офлайн-распознавание Vosk. " +
                "Bluetooth-гарнитура, пока служит микрофоном, работает в режиме звонка: звук в ней хуже, а батарея садится быстрее."
        ))

        // --- Bluetooth и музыка ---
        content.addView(header("Bluetooth и музыка"))
        content.addView(info(
            "Когда играет музыка, а микрофоном служит Bluetooth-гарнитура, музыка звучит «как из-под воды»: " +
                "гарнитура переходит в режим звонка. Выберите, как поступать Луне:"
        ))
        val musicGroup = RadioGroup(this)
        val currentPolicy = AudioConfig.musicPolicy(this)
        for ((key, label) in AudioConfig.musicPolicies) {
            musicGroup.addView(RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                tag = key
                isChecked = key == currentPolicy
            })
        }
        musicGroup.setOnCheckedChangeListener { g, checkedId ->
            val key = g.findViewById<RadioButton>(checkedId)?.tag as? String
            if (key != null) {
                AudioConfig.setMusicPolicy(this, key)
                Diag.log("микрофон", "Режим Bluetooth и музыки: $key")
            }
        }
        content.addView(musicGroup)

        // --- проверка ---
        content.addView(header("Проверка"))
        content.addView(Button(this).apply {
            text = "Проверить выбранное (3 секунды)"
            isAllCaps = false
            setOnClickListener { runTest() }
        })
        level = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        content.addView(level)
        status = TextView(this).apply {
            text = "Луна на время проверки остановится. Потом запустите её на главном экране."
            textSize = 14f
        }
        content.addView(status)
        content.addView(info("Текущий выбор: ${AudioConfig.describe(this)}"))
    }

    private fun runTest() {
        if (testing) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)
            return
        }
        testing = true
        stopService(Intent(this, VoiceService::class.java))
        val source = AudioConfig.sourceId(AudioConfig.sourceKey(this))
        val device = AudioConfig.findDevice(this, AudioConfig.deviceKey(this))
        AudioRoute.apply(this, device)
        status.text = "Говорите «раз, два, три…» (3 секунды)"
        Thread {
            Thread.sleep(800) // даём службе освободить микрофон
            val result = measure(source, device)
            AudioRoute.release(this)
            Diag.log("тест микрофона", result)
            runOnUiThread {
                testing = false
                level.progress = 0
                status.text = result
            }
        }.start()
    }

    private fun measure(source: Int, device: AudioDeviceInfo?): String {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return "Этот источник не поддерживается"
        var rec: AudioRecord? = null
        try {
            rec = AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            if (rec.state != AudioRecord.STATE_INITIALIZED) return "Не удалось открыть микрофон с таким источником"
            if (device != null) rec.setPreferredDevice(device)
            rec.startRecording()
            val buf = ShortArray(1600)
            val end = SystemClock.elapsedRealtime() + 3000
            var peak = 0
            var sumSq = 0.0
            var count = 0L
            while (SystemClock.elapsedRealtime() < end) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                var chunkPeak = 0
                for (i in 0 until n) {
                    val v = abs(buf[i].toInt())
                    if (v > chunkPeak) chunkPeak = v
                    sumSq += v.toDouble() * v
                }
                count += n
                peak = max(peak, chunkPeak)
                val pct = chunkPeak * 100 / 32768
                runOnUiThread { level.progress = pct }
            }
            val routed = rec.routedDevice?.let { Diag.deviceName(it) } ?: "неизвестно"
            val rms = if (count > 0) sqrt(sumSq / count) else 0.0
            val db = if (rms > 0) (20 * log10(rms / 32768)).toInt() else -99
            val peakPct = peak * 100 / 32768
            val verdict = when {
                peakPct < 2 -> "ВЕРДИКТ: тишина. Этот источник или устройство ничего не слышит."
                peakPct < 10 -> "ВЕРДИКТ: слышит очень тихо. Говорите ближе к микрофону."
                else -> "ВЕРДИКТ: слышит хорошо."
            }
            return "Пик $peakPct%, уровень $db дБ, фактическое устройство: $routed. $verdict"
        } catch (e: Exception) {
            return "Ошибка: ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            try { rec?.stop() } catch (e: Exception) { }
            rec?.release()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            runTest()
        } else if (requestCode == 12) {
            Toast.makeText(this, "Нажмите «Обновить список устройств»", Toast.LENGTH_SHORT).show()
            render()
        }
    }
}
