package com.luna.assistant

import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.os.ParcelFileDescriptor
import java.io.OutputStream

// Передаёт распознавателю Google звук из выбранного источника и устройства (Android 13 и новее).
// Читает микрофон сам и отдаёт звук в канал, который Google читает вместо своего микрофона.
class GoogleAudioFeeder(private val source: Int, private val device: AudioDeviceInfo?) {

    private var rec: AudioRecord? = null
    private var out: OutputStream? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    var peakPercent = 0
        private set

    // Открывает запись и канал. Возвращает конец канала для распознавателя или null, если не вышло
    fun open(): ParcelFileDescriptor? {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val r: AudioRecord = try {
            AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        } catch (e: Exception) {
            Diag.log("микрофон", "Для Google: AudioRecord не создан: ${e.message}")
            return null
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return null
        }
        if (device != null) r.setPreferredDevice(device)
        val pipe = try {
            ParcelFileDescriptor.createPipe()
        } catch (e: Exception) {
            r.release()
            return null
        }
        rec = r
        out = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        return pipe[0]
    }

    fun start() {
        val r = rec ?: return
        val o = out ?: return
        try {
            r.startRecording()
        } catch (e: Exception) {
            Diag.log("микрофон", "Для Google: запись не началась: ${e.message}")
            stop()
            return
        }
        running = true
        val t = Thread { loop(r, o) }
        t.name = "luna-google-feed"
        thread = t
        t.start()
    }

    private fun loop(r: AudioRecord, o: OutputStream) {
        val buf = ShortArray(1600)
        val bytes = ByteArray(buf.size * 2)
        try {
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                var peak = 0
                for (i in 0 until n) {
                    val s = buf[i].toInt()
                    bytes[2 * i] = (s and 0xFF).toByte()
                    bytes[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
                    val a = if (s < 0) -s else s
                    if (a > peak) peak = a
                }
                val pct = peak * 100 / 32768
                if (pct > peakPercent) peakPercent = pct
                o.write(bytes, 0, n * 2)
            }
        } catch (e: Exception) {
            // канал закрыт распознавателем: это нормальный конец
        } finally {
            try { r.stop() } catch (e: Exception) { }
        }
    }

    fun stop() {
        running = false
        try { thread?.join(1500) } catch (e: InterruptedException) { }
        thread = null
        try { out?.close() } catch (e: Exception) { }
        out = null
        try { rec?.release() } catch (e: Exception) { }
        rec = null
    }
}
