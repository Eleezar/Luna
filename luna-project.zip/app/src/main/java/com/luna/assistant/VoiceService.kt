package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

class VoiceService : Service(), RecognitionListener {

    private val tag = "Luna"
    private val wakeWord = "луна"
    private val handler = Handler(Looper.getMainLooper())

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var awake = false
    private var started = false

    private val backToWake = Runnable { startWake() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna", "Луна", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, "luna")
            .setContentTitle("Луна слушает")
            .setContentText("Скажите «Луна»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Модель лежит в assets/model-ru, при первом запуске распаковывается
        StorageService.unpack(this, "model-ru", "model",
            { m -> model = m; startWake() },
            { e -> Log.e(tag, "Не удалось загрузить модель: ${e.message}") })

        return START_STICKY
    }

    // Режим 1: слушаем только слово «Луна» (узкий словарь — быстро и мало ложных срабатываний)
    private fun startWake() {
        handler.removeCallbacks(backToWake)
        speech?.shutdown()
        awake = false
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f, "[\"$wakeWord\", \"[unk]\"]")
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
        } catch (e: Exception) {
            Log.e(tag, "startWake: ${e.message}")
        }
    }

    // Режим 2: после слова слушаем команду полным словарём
    private fun startCommand() {
        speech?.shutdown()
        awake = true
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP)
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f)
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            handler.postDelayed(backToWake, 7000) // не услышали команду — возвращаемся к ожиданию
        } catch (e: Exception) {
            Log.e(tag, "startCommand: ${e.message}")
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (awake || hypothesis == null) return
        if (JSONObject(hypothesis).optString("partial").contains(wakeWord)) startCommand()
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        val text = JSONObject(hypothesis).optString("text").trim()
        if (text.isEmpty()) return
        if (!awake) {
            if (text.contains(wakeWord)) startCommand()
            return
        }
        Log.d(tag, "Команда: $text")
        Commands.run(this, text.removePrefix(wakeWord).trim())
        startWake()
    }

    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { Log.e(tag, "Ошибка: ${exception?.message}") }
    override fun onTimeout() {}

    override fun onDestroy() {
        handler.removeCallbacks(backToWake)
        speech?.shutdown()
        model?.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
