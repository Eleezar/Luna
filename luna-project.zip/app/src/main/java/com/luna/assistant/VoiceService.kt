package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    private val wakeWord = "луна"
    private val handler = Handler(Looper.getMainLooper())

    // Vosk: слово «Луна» всегда, команды — если Google недоступен или выключен
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var recognizer: Recognizer? = null
    private var awake = false
    private var started = false

    // Google: распознавание команд (точнее, нужен интернет)
    private var sr: SpeechRecognizer? = null
    private var googleFailures = 0

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var tWake = 0L
    private var tCommand = 0L
    private var firstPartialLogged = false

    // Диалог: Луна задала вопрос и ждёт ответ без слова «Луна»
    private var pending: ((String) -> Reply)? = null
    private var pendingExpect = Expect.FREE

    // Длинная диктовка в офлайн-режиме: собираем фразы, пока человек не замолчит на 2 секунды
    private val buffer = StringBuilder()
    private var collectStart = 0L
    private val finishCollect = Runnable { finishCollecting() }

    private val googleStart = Runnable { beginGoogleListening() }

    private val commandTimeout = Runnable {
        Diag.inc("таймаутов команды")
        Diag.log("команда", "таймаут: ответ не услышан")
        startWake()
    }
    private val ttsFallback = Runnable {
        Diag.inc("зависаний озвучки")
        Diag.log("голос", "озвучка не завершилась за 15 с, возвращаюсь к ожиданию")
        startWake()
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "luna")
            .setContentTitle("Луна")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    // google — онлайн (точнее), ondevice — Google с пакетом на телефоне (без интернета), vosk — встроенный офлайн
    private fun engine(): String = getSharedPreferences("luna", MODE_PRIVATE).getString("engine", "google") ?: "google"

    private fun googleEnabled(): Boolean = engine() != "vosk"

    private fun useGoogle(): Boolean =
        googleEnabled() && googleFailures < 3 && SpeechRecognizer.isRecognitionAvailable(this)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true
        googleFailures = 0
        Diag.set("Служба", "работает")
        Diag.set("Режим", "подготовка")
        Diag.set(
            "Распознавание команд",
            when (engine()) {
                "google" -> "Google онлайн (с переходом на Vosk при сбоях)"
                "ondevice" -> "Google офлайн-пакет (с переходом на Vosk при сбоях)"
                else -> "Vosk офлайн"
            }
        )
        Diag.set(
            "Google-распознаватель",
            if (SpeechRecognizer.isRecognitionAvailable(this)) "доступен" else "НЕДОСТУПЕН (нужно приложение Google)"
        )
        Diag.log(
            "служба",
            "Запуск службы. Входные устройства: ${Diag.inputDevices(this)}. " +
                "Служба распознавания телефона: ${Settings.Secure.getString(contentResolver, "voice_recognition_service")}"
        )

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna", "Луна", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notification("Подготовка…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Голос Луны (встроенный синтезатор речи Android)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                Diag.log("голос", "TTS запущен, движок: ${tts?.defaultEngine}, русский язык: код $r, готов: $ttsReady")
                Diag.set("Голос (TTS)", if (ttsReady) "готов (русский)" else "русский голос недоступен (код $r)")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        Diag.log("голос", "озвучка началась")
                    }

                    override fun onDone(utteranceId: String?) {
                        Diag.log("голос", "озвучка закончена")
                        handler.post { afterSpeech() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        Diag.inc("ошибок озвучки")
                        Diag.log("голос", "ОШИБКА озвучки")
                        handler.post { afterSpeech() }
                    }
                })
            } else {
                Diag.log("голос", "TTS не запустился, код $status")
                Diag.set("Голос (TTS)", "ошибка запуска (код $status)")
            }
        }

        // Модель для слова «Луна» скачивается один раз, потом работает без интернета
        Thread {
            val t0 = SystemClock.elapsedRealtime()
            try {
                Diag.set("Модель", "загрузка")
                val m = ModelLoader.ensure(this) { msg ->
                    Diag.set("Модель", msg)
                    handler.post { updateNotification(msg) }
                }
                Diag.log("модель", "Модель загружена за ${SystemClock.elapsedRealtime() - t0} мс")
                Diag.set("Модель", "загружена")
                handler.post {
                    model = m
                    updateNotification("Скажите «Луна»")
                    startWake()
                }
            } catch (e: Exception) {
                Diag.log("модель", "ОШИБКА загрузки: ${e.javaClass.simpleName}: ${e.message}")
                Diag.set("Модель", "ОШИБКА: ${e.message}")
                handler.post {
                    updateNotification("Не удалось скачать модель. Проверьте интернет и запустите снова")
                    Toast.makeText(this, "Не удалось скачать модель: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()

        return START_STICKY
    }

    private fun destroyGoogle() {
        handler.removeCallbacks(googleStart)
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
    }

    // Правильная остановка: сначала stop() (ждём поток записи), потом shutdown(), потом закрываем распознаватель
    private fun releaseSpeech() {
        destroyGoogle()
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (e: Exception) {
            Diag.log("ошибка", "releaseSpeech: ${e.message}")
        }
        speech = null
        try { recognizer?.close() } catch (e: Exception) { }
        recognizer = null
    }

    // После речи Луны: если она задала вопрос, слушаем ответ, иначе ждём слово «Луна»
    private fun afterSpeech() {
        handler.removeCallbacks(ttsFallback)
        if (pending != null) startCommand() else startWake()
    }

    // Луна говорит; пока говорит, микрофон выключен, чтобы она не слушала сама себя
    private fun say(reply: Reply) {
        val text = reply.text
        if (!text.isNullOrBlank()) {
            updateNotification(text)
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
        }
        if (text.isNullOrBlank() || !ttsReady) {
            if (!text.isNullOrBlank()) Diag.log("голос", "ответ «$text» не озвучен: русский голос не готов")
            afterSpeech()
            return
        }
        handler.removeCallbacks(commandTimeout)
        releaseSpeech()
        Diag.inc("ответов озвучено")
        Diag.log("голос", "говорю: «$text»")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        handler.postDelayed(ttsFallback, 15000) // запасной возврат, если озвучка зависла
    }

    // Режим 1: слушаем только слово «Луна» (Vosk, офлайн)
    private fun startWake() {
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        handler.removeCallbacks(finishCollect)
        pending = null
        buffer.setLength(0)
        releaseSpeech()
        awake = false
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f, "[\"$wakeWord\", \"[unk]\"]")
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            Diag.set("Режим", "ожидание слова «Луна»")
            Diag.log("режим", "ожидание слова «Луна»")
        } catch (e: Exception) {
            Diag.log("ошибка", "startWake: ${e.message}")
            Diag.set("Режим", "ОШИБКА запуска ожидания: ${e.message}")
        }
    }

    // Режим 2: после слова (или после вопроса Луны) слушаем команду
    private fun startCommand() {
        handler.removeCallbacks(finishCollect)
        buffer.setLength(0)
        releaseSpeech()
        awake = true
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP)
        if (useGoogle()) startGoogle() else startVoskCommand()
    }

    // ---------- Распознавание команд: Google ----------

    private fun startGoogle() {
        tCommand = SystemClock.elapsedRealtime()
        firstPartialLogged = false
        Diag.set("Режим", if (pending != null) "ответ на вопрос Луны (Google)" else "приём команды (Google)")
        handler.removeCallbacks(commandTimeout)
        handler.postDelayed(commandTimeout, 20000) // страховка на случай зависания
        handler.postDelayed(googleStart, 450) // даём стихнуть сигналу и освободиться микрофону
    }

    private fun beginGoogleListening() {
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            sr = r
            r.setRecognitionListener(googleListener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                if (engine() == "ondevice") putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            }
            r.startListening(intent)
            Diag.log("google", "слушаю (запуск через ${SystemClock.elapsedRealtime() - tCommand} мс)")
        } catch (e: Exception) {
            Diag.log("google", "не удалось запустить: ${e.javaClass.simpleName}: ${e.message}")
            googleFailed("исключение: ${e.message}")
        }
    }

    // Google не справился: эту команду принимаем офлайн, а после трёх сбоев подряд переходим на офлайн насовсем
    private fun googleFailed(reason: String) {
        googleFailures++
        Diag.inc("Google: ошибок")
        Diag.inc("переходов на офлайн-распознавание")
        Diag.log("google", "сбой ($reason), сбоев подряд: $googleFailures, перехожу на офлайн для этой команды")
        if (googleFailures >= 3) {
            Diag.set("Распознавание команд", "офлайн (Vosk): Google сбоил 3 раза подряд")
        }
        handler.removeCallbacks(commandTimeout)
        handler.post {
            destroyGoogle()
            startVoskCommand()
        }
    }

    private fun errorName(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "таймаут сети"
        SpeechRecognizer.ERROR_NETWORK -> "нет сети"
        SpeechRecognizer.ERROR_AUDIO -> "ошибка записи звука"
        SpeechRecognizer.ERROR_SERVER -> "ошибка сервера"
        SpeechRecognizer.ERROR_CLIENT -> "ошибка клиента"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "речь не началась"
        SpeechRecognizer.ERROR_NO_MATCH -> "ничего не распознано"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "распознаватель занят"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "нет разрешения"
        else -> "код $code"
    }

    private val googleListener = object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            Diag.log("google", "готов слушать через ${SystemClock.elapsedRealtime() - tCommand} мс (говорите сейчас)")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val p = list?.firstOrNull()
            if (!p.isNullOrBlank()) {
                updateNotification("Слышу: $p")
                if (!firstPartialLogged) {
                    firstPartialLogged = true
                    Diag.log("google", "первые слова через ${SystemClock.elapsedRealtime() - tCommand} мс: «$p»")
                }
            }
        }

        override fun onResults(results: Bundle?) {
            handler.removeCallbacks(commandTimeout)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list.isNullOrEmpty()) {
                googleFailed("пустой результат")
                return
            }
            val raw = list[0]
            val text = TextNorm.normalize(raw)
            val score = results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull()
            Diag.log(
                "google",
                "услышано: «$raw» → «$text», уверенность $score, варианты: ${list.drop(1).joinToString(" | ")}"
            )
            googleFailures = 0
            Diag.inc("Google: распознано")
            Diag.inc("команд распознано")
            updateNotification("Услышала: $text")
            Toast.makeText(this@VoiceService, "Услышала: $text", Toast.LENGTH_SHORT).show()
            handler.post {
                destroyGoogle()
                execute(text.removePrefix(wakeWord).trim())
            }
        }

        override fun onError(error: Int) {
            handler.removeCallbacks(commandTimeout)
            val name = errorName(error)
            Diag.log("google", "ошибка $error ($name)")
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    Diag.inc("таймаутов команды")
                    handler.post {
                        destroyGoogle()
                        startWake()
                    }
                }
                else -> googleFailed(name)
            }
        }
    }

    // ---------- Распознавание команд: Vosk (офлайн) ----------

    private fun startVoskCommand() {
        releaseSpeech()
        val m = model ?: return
        try {
            val expect = if (pending != null) pendingExpect else Expect.FREE
            val grammar = Grammars.json(expect)
            val rec = if (grammar != null) Recognizer(m, 16000f, grammar) else Recognizer(m, 16000f)
            rec.setMaxAlternatives(5) // несколько вариантов, из которых выберем понятный
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            tCommand = SystemClock.elapsedRealtime()
            firstPartialLogged = false
            Diag.set(
                "Режим",
                (if (pending != null) "ответ на вопрос Луны" else "приём команды") +
                    " (офлайн${if (grammar != null) ", узкий словарь: $expect" else ""})"
            )
            Diag.log(
                "команда",
                "офлайн-микрофон открыт через ${tCommand - tWake} мс после слова «Луна»" +
                    (if (grammar != null) ", словарь: $expect" else ", полный словарь") +
                    " (речь в этот промежуток теряется)"
            )
            handler.removeCallbacks(commandTimeout)
            handler.postDelayed(commandTimeout, if (pending != null) 10000 else 7000)
        } catch (e: Exception) {
            Diag.log("ошибка", "startVoskCommand: ${e.message}")
            Diag.set("Режим", "ОШИБКА приёма команды: ${e.message}")
        }
    }

    // Результат Vosk: либо {"text": ...}, либо {"alternatives": [{"text": ...}, ...]}
    private fun voskTexts(hypothesis: String): List<String> {
        val o = JSONObject(hypothesis)
        val alts = o.optJSONArray("alternatives")
        if (alts != null) {
            val out = ArrayList<String>()
            for (i in 0 until alts.length()) out.add(alts.getJSONObject(i).optString("text"))
            return out
        }
        return listOf(o.optString("text"))
    }

    override fun onPartialResult(hypothesis: String?) {
        if (hypothesis == null) return
        val partial = JSONObject(hypothesis).optString("partial")
        if (awake) {
            if (partial.isNotBlank()) {
                updateNotification("Слышу: $partial")
                if (!firstPartialLogged) {
                    firstPartialLogged = true
                    Diag.log("команда", "первые слова через ${SystemClock.elapsedRealtime() - tCommand} мс: «$partial»")
                }
            }
            return
        }
        if (partial.contains(wakeWord)) {
            tWake = SystemClock.elapsedRealtime()
            Diag.inc("слово «Луна» услышано")
            Diag.log("слово", "услышано слово: «$partial»")
            startCommand()
        }
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        val alts = voskTexts(hypothesis)
        val text = if (awake) {
            Rescore.pick(alts, if (pending != null) pendingExpect else Expect.FREE)
        } else {
            (alts.firstOrNull() ?: "").replace("[unk]", " ").trim()
        }
        if (awake && alts.size > 1) {
            Diag.log("команда", "варианты офлайн: ${alts.joinToString(" | ")} → выбрано «$text»")
        }
        if (!awake) {
            if (text.isNotEmpty()) {
                if (text.contains(wakeWord)) {
                    tWake = SystemClock.elapsedRealtime()
                    Diag.inc("слово «Луна» услышано")
                    Diag.log("слово", "слово услышано в итоговом результате: «$text»")
                    startCommand()
                } else {
                    Diag.inc("посторонних фраз в ожидании")
                }
            }
            return
        }
        val now = SystemClock.elapsedRealtime()
        val ms = now - tCommand
        if (text.isEmpty()) {
            Diag.inc("пустых результатов команды")
            Diag.log("команда", "пустой результат через $ms мс")
            return
        }
        Diag.inc("команд распознано")
        Diag.log("команда", "услышано (офлайн): «$text» (через $ms мс после открытия микрофона)")
        updateNotification("Услышала: $text")
        Toast.makeText(this, "Услышала: $text", Toast.LENGTH_SHORT).show()
        handler.removeCallbacks(commandTimeout)

        val cleaned = text.removePrefix(wakeWord).trim()
        // Длинные команды и ответы на вопросы собираем, пока человек не замолчит
        val shortAnswer = pending != null && (pendingExpect == Expect.TIME || pendingExpect == Expect.YESNO)
        val collecting = !shortAnswer && (pending != null || buffer.isNotEmpty() || Secretary.isDictation(cleaned))
        if (!collecting) {
            execute(cleaned)
            return
        }
        if (buffer.isEmpty()) collectStart = now else buffer.append(' ')
        buffer.append(cleaned)
        handler.removeCallbacks(finishCollect)
        if (now - collectStart > 25000) finishCollecting() else handler.postDelayed(finishCollect, 2000)
    }

    private fun finishCollecting() {
        handler.removeCallbacks(finishCollect)
        val text = buffer.toString().trim()
        buffer.setLength(0)
        if (text.isEmpty()) {
            afterSpeech()
            return
        }
        Diag.log("команда", "диктовка собрана: «$text»")
        execute(text)
    }

    private fun execute(text: String) {
        val dialog = pending
        pending = null
        val reply: Reply = try {
            if (dialog != null) dialog(text) else Commands.run(this, text)
        } catch (e: Exception) {
            Diag.inc("ошибок выполнения команд")
            Diag.log("ошибка", "Команда «$text»: ${e.javaClass.simpleName}: ${e.message}")
            Reply("Не получилось выполнить команду")
        }
        pending = reply.followUp
        pendingExpect = reply.expect
        Diag.log("команда", "результат: «${reply.text ?: "без ответа"}»" + if (reply.followUp != null) " (жду ответ)" else "")
        say(reply)
    }

    override fun onFinalResult(hypothesis: String?) {}

    override fun onError(exception: Exception?) {
        Diag.inc("ошибок распознавания")
        Diag.log("ошибка", "Vosk: ${exception?.message}")
    }

    override fun onTimeout() {}

    override fun onDestroy() {
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        handler.removeCallbacks(finishCollect)
        releaseSpeech()
        tts?.stop()
        tts?.shutdown()
        model?.close()
        Diag.set("Служба", "остановлена")
        Diag.set("Режим", "—")
        Diag.log("служба", "Служба остановлена")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
