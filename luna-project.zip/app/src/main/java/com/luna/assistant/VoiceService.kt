package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    private val tag = "Luna"
    private val wakeWord = "луна"
    private val handler = Handler(Looper.getMainLooper())

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var recognizer: Recognizer? = null
    private var awake = false
    private var started = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val backToWake = Runnable { startWake() }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "luna")
            .setContentTitle("Луна")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna", "Луна", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notification("Подготовка…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Голос Луны (встроенный синтезатор речи Android)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { handler.post { startWake() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { handler.post { startWake() } }
                })
                if (!ttsReady) Log.e(tag, "Русский голос не установлен")
            }
        }

        // Модель скачивается один раз при первом запуске, потом работает без интернета
        Thread {
            try {
                val m = ModelLoader.ensure(this) { msg -> handler.post { updateNotification(msg) } }
                handler.post {
                    model = m
                    updateNotification("Скажите «Луна»")
                    startWake()
                }
            } catch (e: Exception) {
                Log.e(tag, "Не удалось загрузить модель: ${e.message}")
                handler.post {
                    updateNotification("Не удалось скачать модель. Проверьте интернет и запустите снова")
                    Toast.makeText(this, "Не удалось скачать модель: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()

        return START_STICKY
    }

    // Правильная остановка: сначала stop() (ждём поток записи), потом shutdown(), потом закрываем распознаватель
    private fun releaseSpeech() {
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (e: Exception) {
            Log.e(tag, "releaseSpeech: ${e.message}")
        }
        speech = null
        try { recognizer?.close() } catch (e: Exception) { }
        recognizer = null
    }

    // Луна говорит; пока говорит, микрофон выключен, чтобы она не слушала сама себя
    private fun say(text: String?) {
        if (text.isNullOrBlank() || !ttsReady) {
            startWake()
            return
        }
        handler.removeCallbacks(backToWake)
        releaseSpeech()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        handler.postDelayed(backToWake, 15000) // запасной возврат, если озвучка зависла
    }

    // Режим 1: слушаем только слово «Луна»
    private fun startWake() {
        handler.removeCallbacks(backToWake)
        releaseSpeech()
        awake = false
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f, "[\"$wakeWord\", \"[unk]\"]")
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
        } catch (e: Exception) {
            Log.e(tag, "startWake: ${e.message}")
        }
    }

    // Режим 2: после слова слушаем команду полным словарём
    private fun startCommand() {
        releaseSpeech()
        awake = true
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP)
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f)
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            handler.postDelayed(backToWake, 7000) // не услышали команду — возвращаемся к ожиданию
        } catch (e: Exception) {
            Log.e(tag, "startCommand: ${e.message}")
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (awake || hypothesis == null) return
        if (JSONObject(hypothesis).optString("partial").contains(wakeWord)) startCommand()
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        val text = JSONObject(hypothesis).optString("text").trim()
        if (text.isEmpty()) return
        if (!awake) {
            if (text.contains(wakeWord)) startCommand()
            return
        }
        Log.d(tag, "Команда: $text")
        handler.removeCallbacks(backToWake)
        val reply = Commands.run(this, text.removePrefix(wakeWord).trim())
        say(reply)
    }

    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { Log.e(tag, "Ошибка: ${exception?.message}") }
    override fun onTimeout() {}

    override fun onDestroy() {
        handler.removeCallbacks(backToWake)
        releaseSpeech()
        tts?.stop()
        tts?.shutdown()
        model?.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
