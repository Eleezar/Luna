package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import java.io.IOException
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    companion object {
        @Volatile
        private var instance: VoiceService? = null

        // Озвучить сообщение из другого потока (например, итог отправки сообщения)
        fun announce(text: String) {
            val s = instance ?: return
            s.handler.post { s.say(Reply(text)) }
        }

        // Команда, введённая текстом на экране разговора. false, если Луна не запущена
        fun submit(text: String, speak: Boolean): Boolean {
            val s = instance ?: return false
            s.handler.post {
                s.silentNext = !speak
                s.typedNext = true
                s.execute(text)
            }
            return true
        }

        // Луна сама задаёт вопрос и ждёт ответ (например, «Звонит Мама. Ответить?»)
        fun announceReply(reply: Reply) {
            val s = instance ?: return
            s.handler.post {
                s.pending = reply.followUp
                s.pendingExpect = reply.expect
                s.say(reply)
            }
        }

        // Команда «включи музыку» при Bluetooth-гарнитуре: Луна сама освободит гарнитуру от режима звонка
        // и потом нажмёт «играть». true: Луна возьмёт это на себя, false: клавишу нужно нажать самому.
        fun requestMusicPlay(): Boolean {
            val s = instance ?: return false
            return s.queueMusicPlay()
        }
    }

    private val wakeWord = "луна"
    private val handler = Handler(Looper.getMainLooper())

    // Vosk: слово «Луна» всегда, команды — если Google недоступен или выключен
    private var model: Model? = null
    private var vosk: VoskListener? = null
    private var routeLogged = false
    private var silentNext = false
    private var typedNext = false

    // Google с выбранным источником звука
    private var feeder: GoogleAudioFeeder? = null
    private var googleStreamMisses = 0
    private var googleStreamBroken = false

    // Bluetooth и музыка
    private var speaking = false
    private var musicSuspended = false
    private var musicStopStreak = 0
    private var musicGraceUntil = 0L
    private var musicRequestPending = false
    private var pendingPlayKey = false
    private val btMonitor = object : Runnable {
        override fun run() {
            try {
                checkMusic()
            } catch (e: Exception) {
                Diag.log("музыка", "Ошибка проверки музыки: ${e.message}")
            }
            handler.postDelayed(this, 1500)
        }
    }
    private var recognizer: Recognizer? = null
    private var awake = false
    private var started = false

    // Google: распознавание команд (точнее, нужен интернет)
    private var sr: SpeechRecognizer? = null
    private var googleFailures = 0

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var tWake = 0L
    private var wakeStartAt = 0L // когда начато ожидание слова «Луна»
    private var falseStreak = 0 // подряд «пустых» срабатываний
    private var wakeBoost = 0.0 // автоматическая добавка к порогу при частых ложных срабатываниях
    private var tCommand = 0L
    private var firstPartialLogged = false

    // Диалог: Луна задала вопрос и ждёт ответ без слова «Луна»
    private var pending: ((String) -> Reply)? = null
    private var pendingExpect = Expect.FREE

    // Длинная диктовка в офлайн-режиме: собираем фразы, пока человек не замолчит на 2 секунды
    private val buffer = StringBuilder()
    private var collectStart = 0L
    private val finishCollect = Runnable { finishCollecting() }

    private val googleStart = Runnable { beginGoogleListening() }

    private val commandTimeout = Runnable {
        Diag.inc("таймаутов команды")
        Diag.log("команда", "таймаут: ответ не услышан")
        if (pending == null && !firstPartialLogged) noteFalseTrigger()
        startWake()
    }
    private val ttsFallback = Runnable {
        Diag.inc("зависаний озвучки")
        Diag.log("голос", "озвучка не завершилась за 15 с, возвращаюсь к ожиданию")
        startWake()
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "luna")
            .setContentTitle("Луна")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    // google — онлайн (точнее), ondevice — Google с пакетом на телефоне (без интернета), vosk — встроенный офлайн
    private fun engine(): String = getSharedPreferences("luna", MODE_PRIVATE).getString("engine", "google") ?: "google"

    private fun googleEnabled(): Boolean = engine() != "vosk"

    private fun useGoogle(): Boolean {
        if (!googleEnabled() || googleFailures >= 3 || !SpeechRecognizer.isRecognitionAvailable(this)) return false
        if (musicSuspended) return false
        // выбранный источник звука Google получает от нас (Android 13 и новее)
        if (AudioConfig.isCustom(this) && (Build.VERSION.SDK_INT < 33 || googleStreamBroken)) return false
        return true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true
        instance = this
        googleFailures = 0
        Diag.set("Служба", "работает")
        Diag.set("Режим", "подготовка")
        Diag.set("Музыка и Bluetooth", "обычный режим")
        Diag.set("Источник звука", AudioConfig.describe(this))
        AudioRoute.apply(this, AudioConfig.findDevice(this, AudioConfig.deviceKey(this)))
        Diag.set("Порог слова «Луна»", describeWake())
        Diag.set(
            "Распознавание команд",
            when (engine()) {
                "google" -> "Google онлайн (с переходом на Vosk при сбоях)"
                "ondevice" -> "Google офлайн-пакет (с переходом на Vosk при сбоях)"
                else -> "Vosk офлайн"
            }
        )
        Diag.set(
            "Google-распознаватель",
            if (SpeechRecognizer.isRecognitionAvailable(this)) "доступен" else "НЕДОСТУПЕН (нужно приложение Google)"
        )
        Diag.log(
            "служба",
            "Запуск службы. Входные устройства: ${Diag.inputDevices(this)}. " +
                "Служба распознавания телефона: ${Settings.Secure.getString(contentResolver, "voice_recognition_service")}"
        )

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna", "Луна", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notification("Подготовка…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Голос Луны (встроенный синтезатор речи Android)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                Diag.log("голос", "TTS запущен, движок: ${tts?.defaultEngine}, русский язык: код $r, готов: $ttsReady")
                Diag.set("Голос (TTS)", if (ttsReady) "готов (русский)" else "русский голос недоступен (код $r)")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        Diag.log("голос", "озвучка началась")
                    }

                    override fun onDone(utteranceId: String?) {
                        Diag.log("голос", "озвучка закончена")
                        handler.post { afterSpeech() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        Diag.inc("ошибок озвучки")
                        Diag.log("голос", "ОШИБКА озвучки")
                        handler.post { afterSpeech() }
                    }
                })
            } else {
                Diag.log("голос", "TTS не запустился, код $status")
                Diag.set("Голос (TTS)", "ошибка запуска (код $status)")
            }
        }

        // Модель для слова «Луна» скачивается один раз, потом работает без интернета
        Thread {
            val t0 = SystemClock.elapsedRealtime()
            try {
                Diag.set("Модель", "загрузка")
                val m = ModelLoader.ensure(this) { msg ->
                    Diag.set("Модель", msg)
                    handler.post { updateNotification(msg) }
                }
                Diag.log("модель", "Модель загружена за ${SystemClock.elapsedRealtime() - t0} мс")
                Diag.set("Модель", "загружена")
                handler.post {
                    model = m
                    updateNotification("Скажите «Луна»")
                    startWake()
                }
            } catch (e: Exception) {
                Diag.log("модель", "ОШИБКА загрузки: ${e.javaClass.simpleName}: ${e.message}")
                Diag.set("Модель", "ОШИБКА: ${e.message}")
                handler.post {
                    updateNotification("Не удалось скачать модель. Проверьте интернет и запустите снова")
                    Toast.makeText(this, "Не удалось скачать модель: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()

        handler.removeCallbacks(btMonitor)
        handler.postDelayed(btMonitor, 3000)
        CallMonitor.start(this)
        return START_STICKY
    }

    // Запускает «слух» Vosk с выбранным источником и устройством. Не вышло: пробуем стандартный
    private fun startVosk(rec: Recognizer) {
        val srcKey = AudioConfig.sourceKey(this)
        val devKey = AudioConfig.deviceKey(this)
        val phoneMode = musicSuspended && AudioConfig.musicPolicy(this) == "phone"
        val device = if (phoneMode) AudioConfig.builtinMic(this) else AudioConfig.findDevice(this, devKey)
        if (!phoneMode && devKey.isNotEmpty() && device == null) {
            Diag.log("микрофон", "Выбранное устройство не подключено, использую стандартное")
        }
        val logRoute = !routeLogged
        var l = VoskListener(rec, AudioConfig.sourceId(srcKey), device, this, logRoute)
        if (!l.start()) {
            Diag.log("микрофон", "Не удалось открыть источник «$srcKey»${if (device != null) " и выбранное устройство" else ""}, пробую стандартный")
            l = VoskListener(rec, MediaRecorder.AudioSource.VOICE_RECOGNITION, null, this, logRoute)
            if (!l.start()) throw IOException("Не удалось открыть микрофон")
        }
        routeLogged = true
        vosk = l
    }

    // ---------- Bluetooth-гарнитура и музыка ----------

    private fun btDevice(): AudioDeviceInfo? {
        val d = AudioConfig.findDevice(this, AudioConfig.deviceKey(this))
        return if (AudioRoute.isBluetooth(d)) d else null
    }

    // Пока гарнитура служит микрофоном, она в режиме звонка и музыка в ней звучит «как из-под воды».
    // Когда начинает играть музыка, Луна освобождает гарнитуру (по выбранному режиму) и возвращает её после.
    private fun checkMusic() {
        if (speaking || awake) return
        val policy = AudioConfig.musicPolicy(this)
        if (policy == "keep" || btDevice() == null) {
            if (musicSuspended) exitMusicMode()
            return
        }
        val playing = (getSystemService(AUDIO_SERVICE) as AudioManager).isMusicActive
        if (playing) {
            musicStopStreak = 0
            if (!musicSuspended) enterMusicMode(policy)
        } else if (musicSuspended) {
            musicStopStreak++
            if (musicStopStreak >= 2 && SystemClock.elapsedRealtime() > musicGraceUntil) exitMusicMode()
        }
    }

    private fun enterMusicMode(policy: String) {
        musicSuspended = true
        musicStopStreak = 0
        Diag.inc("переходов в режим музыки")
        Diag.log("музыка", "Играет музыка при Bluetooth-гарнитуре, режим «$policy»: освобождаю гарнитуру для чистого звука")
        val text = if (policy == "phone") "Играет музыка: слушаю микрофоном телефона" else "Играет музыка: слушание на паузе"
        Diag.set("Музыка и Bluetooth", text)
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(finishCollect)
        pending = null
        buffer.setLength(0)
        releaseSpeech()
        awake = false
        handler.removeCallbacks(btMonitor)
        CallMonitor.stop(this)
        AudioRoute.release(this)
        updateNotification(text)
        if (policy == "phone") startWake()
    }

    private fun exitMusicMode() {
        musicSuspended = false
        musicStopStreak = 0
        Diag.log("музыка", "Музыка закончилась: возвращаю прослушивание через гарнитуру")
        Diag.set("Музыка и Bluetooth", "обычный режим")
        AudioRoute.apply(this, btDevice())
        updateNotification("Скажите «Луна»")
        startWake()
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // «Включи музыку»: сначала освободить гарнитуру, потом нажать «играть»
    private fun queueMusicPlay(): Boolean {
        if (AudioConfig.musicPolicy(this) == "keep" || btDevice() == null) return false
        pendingPlayKey = true
        musicRequestPending = true
        if (!speaking) handler.post { processMusicRequest() }
        return true
    }

    private fun processMusicRequest() {
        musicRequestPending = false
        val policy = AudioConfig.musicPolicy(this)
        if (!musicSuspended && policy != "keep" && btDevice() != null) {
            musicGraceUntil = SystemClock.elapsedRealtime() + 9000
            enterMusicMode(policy)
        }
        if (pendingPlayKey) {
            pendingPlayKey = false
            handler.postDelayed({ sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY) }, 700)
        }
    }

    private fun destroyGoogle() {
        handler.removeCallbacks(googleStart)
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
        try { feeder?.stop() } catch (e: Exception) { }
        feeder = null
    }

    // Правильная остановка: сначала stop() (ждём поток записи), потом shutdown(), потом закрываем распознаватель
    private fun releaseSpeech() {
        destroyGoogle()
        try {
            vosk?.stop()
        } catch (e: Exception) {
            Diag.log("ошибка", "releaseSpeech: ${e.message}")
        }
        vosk = null
        try { recognizer?.close() } catch (e: Exception) { }
        recognizer = null
    }

    // После речи Луны: если она задала вопрос, слушаем ответ, иначе ждём слово «Луна»
    private fun afterSpeech() {
        handler.removeCallbacks(ttsFallback)
        speaking = false
        if (musicRequestPending) {
            processMusicRequest()
            if (musicSuspended && AudioConfig.musicPolicy(this) == "pause") return
        }
        if (pending != null) startCommand() else startWake()
    }

    // Луна говорит; пока говорит, микрофон выключен, чтобы она не слушала сама себя
    private fun say(reply: Reply) {
        val original = reply.text
        // разные формулировки, кратко или подробно, время и даты словами
        val text = if (original.isNullOrBlank()) original else Style.polish(this, original)
        val silent = silentNext
        silentNext = false
        if (!text.isNullOrBlank()) {
            History.lastSpoken = text
            ChatLog.add("luna", text)
            updateNotification(text)
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
        }
        if (text.isNullOrBlank() || !ttsReady || silent) {
            if (!silent && !text.isNullOrBlank()) Diag.log("голос", "ответ «$text» не озвучен: русский голос не готов")
            afterSpeech()
            return
        }
        handler.removeCallbacks(commandTimeout)
        releaseSpeech()
        Diag.inc("ответов озвучено")
        Diag.log("голос", "говорю: «$text»")
        speaking = true
        tts?.setSpeechRate(Style.rate(this))
        tts?.setPitch(Style.pitch(this))
        val voiceName = Style.voiceName(this)
        if (voiceName.isNotEmpty()) {
            tts?.voices?.firstOrNull { it.name == voiceName }?.let { tts?.voice = it }
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        handler.postDelayed(ttsFallback, 15000) // запасной возврат, если озвучка зависла
    }

    // ---------- Слово «Луна»: защита от ложных срабатываний ----------

    // Похожие по звучанию и частые слова: без них модель «натягивает» любой звук на «луна»
    private val wakeDecoys = listOf(
        "да", "нет", "ну", "вот", "это", "так", "что", "как", "еще", "уже", "там", "тут", "сейчас", "потом",
        "ладно", "хорошо", "привет", "лана", "лина", "лука", "лупа", "лунка", "лунный", "лунная", "луне",
        "луну", "луны", "руна", "ляна", "лужа", "лунь"
    )

    private fun wakeGrammar(): String {
        val list = ArrayList<String>()
        list.add(wakeWord)
        list.addAll(wakeDecoys)
        list.add("[unk]")
        return JSONArray(list).toString()
    }

    private fun wakeSens(): String = getSharedPreferences("luna", MODE_PRIVATE).getString("wake", "mid") ?: "mid"

    private fun wakeThreshold(): Double {
        val base = when (wakeSens()) {
            "strict" -> 0.92
            "high" -> 0.65
            else -> 0.82
        }
        return minOf(0.97, base + wakeBoost)
    }

    private fun describeWake(): String =
        "режим «${wakeSens()}», порог ${String.format(Locale.US, "%.2f", wakeThreshold())}" +
            (if (wakeBoost > 0) " (авто +${String.format(Locale.US, "%.2f", wakeBoost)})" else "")

    // Слово услышано, а команды не последовало: вероятно, ложное срабатывание
    private fun noteFalseTrigger() {
        Diag.inc("вероятные ложные срабатывания")
        falseStreak++
        if (falseStreak >= 3 && wakeBoost < 0.12) {
            wakeBoost += 0.04
            falseStreak = 0
            Diag.log("слово", "много ложных срабатываний подряд: порог слова «Луна» повышен")
            Diag.set("Порог слова «Луна»", describeWake())
        }
    }

    private fun noteRealCommand() {
        falseStreak = 0
        if (wakeBoost > 0) {
            wakeBoost = maxOf(0.0, wakeBoost - 0.02)
            Diag.set("Порог слова «Луна»", describeWake())
        }
    }

    // Итог распознавания в режиме ожидания: проверяем уверенность, длительность и что фраза начинается со слова «Луна»
    private fun handleWakeResult(hypothesis: String) {
        val o = JSONObject(hypothesis)
        val raw = o.optString("text").trim()
        if (raw.isEmpty()) return
        val arr = o.optJSONArray("result")
        var first = raw.split(" ").firstOrNull() == wakeWord
        var conf = 1.0
        var dur = 0.5
        if (arr != null && arr.length() > 0) {
            val w0 = arr.getJSONObject(0)
            first = w0.optString("word") == wakeWord
            conf = w0.optDouble("conf", 1.0)
            dur = w0.optDouble("end", 0.5) - w0.optDouble("start", 0.0)
        }
        if (!first) {
            Diag.inc("посторонних фраз в ожидании")
            return
        }
        val now = SystemClock.elapsedRealtime()
        val thr = wakeThreshold()
        val reason = when {
            now - wakeStartAt < 700 -> "слишком рано после запуска"
            conf < thr -> "низкая уверенность"
            dur < 0.2 -> "слишком коротко"
            dur > 1.6 -> "слишком долго"
            else -> null
        }
        Diag.log(
            "слово",
            "кандидат «$raw»: уверенность ${String.format(Locale.US, "%.2f", conf)}, " +
                "длительность ${String.format(Locale.US, "%.2f", dur)} с, " +
                "порог ${String.format(Locale.US, "%.2f", thr)} → ${reason ?: "принято"}"
        )
        if (reason != null) {
            Diag.inc("слово «Луна» отклонено")
            return
        }
        tWake = now
        Diag.inc("слово «Луна» услышано")
        startCommand()
    }

    // Режим 1: слушаем только слово «Луна» (Vosk, офлайн)
    private fun startWake() {
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        handler.removeCallbacks(finishCollect)
        pending = null
        buffer.setLength(0)
        releaseSpeech()
        awake = false
        if (musicSuspended && AudioConfig.musicPolicy(this) == "pause") {
            Diag.set("Режим", "пауза: играет музыка (слушание выключено)")
            return
        }
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f, wakeGrammar())
            rec.setWords(true) // уверенность и время каждого слова
            recognizer = rec
            startVosk(rec)
            wakeStartAt = SystemClock.elapsedRealtime()
            Diag.set("Режим", "ожидание слова «Луна»")
            Diag.log("режим", "ожидание слова «Луна»")
        } catch (e: Exception) {
            Diag.log("ошибка", "startWake: ${e.message}")
            Diag.set("Режим", "ОШИБКА запуска ожидания: ${e.message}")
        }
    }

    // Режим 2: после слова (или после вопроса Луны) слушаем команду
    private fun startCommand() {
        handler.removeCallbacks(finishCollect)
        buffer.setLength(0)
        releaseSpeech()
        awake = true
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP)
        val shortAnswer = pending != null && (pendingExpect == Expect.YESNO || pendingExpect == Expect.TIME)
        if (!shortAnswer && useGoogle()) startGoogle() else startVoskCommand()
    }

    // ---------- Распознавание команд: Google ----------

    private fun startGoogle() {
        tCommand = SystemClock.elapsedRealtime()
        firstPartialLogged = false
        Diag.set("Режим", if (pending != null) "ответ на вопрос Луны (Google)" else "приём команды (Google)")
        handler.removeCallbacks(commandTimeout)
        handler.postDelayed(commandTimeout, 20000) // страховка на случай зависания
        handler.postDelayed(googleStart, 450) // даём стихнуть сигналу и освободиться микрофону
    }

    private fun beginGoogleListening() {
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            sr = r
            r.setRecognitionListener(googleListener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                if (engine() == "ondevice") putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            }
            var readFd: android.os.ParcelFileDescriptor? = null
            if (AudioConfig.isCustom(this) && Build.VERSION.SDK_INT >= 33) {
                val f = GoogleAudioFeeder(
                    AudioConfig.sourceId(AudioConfig.sourceKey(this)),
                    AudioConfig.findDevice(this, AudioConfig.deviceKey(this))
                )
                readFd = f.open()
                if (readFd == null) {
                    Diag.log("google", "не удалось открыть выбранный источник звука для Google")
                    googleFailed("источник звука не открыт")
                    return
                }
                feeder = f
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, readFd)
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16000)
            }
            r.startListening(intent)
            feeder?.start()
            try { readFd?.close() } catch (e: Exception) { }
            Diag.log("google", "слушаю (запуск через ${SystemClock.elapsedRealtime() - tCommand} мс)" +
                if (feeder != null) ", звук из выбранного источника" else "")
        } catch (e: Exception) {
            Diag.log("google", "не удалось запустить: ${e.javaClass.simpleName}: ${e.message}")
            googleFailed("исключение: ${e.message}")
        }
    }

    // Google не справился: эту команду принимаем офлайн, а после трёх сбоев подряд переходим на офлайн насовсем
    private fun googleFailed(reason: String) {
        googleFailures++
        Diag.inc("Google: ошибок")
        Diag.inc("переходов на офлайн-распознавание")
        Diag.log("google", "сбой ($reason), сбоев подряд: $googleFailures, перехожу на офлайн для этой команды")
        if (googleFailures >= 3) {
            Diag.set("Распознавание команд", "офлайн (Vosk): Google сбоил 3 раза подряд")
        }
        handler.removeCallbacks(commandTimeout)
        handler.post {
            destroyGoogle()
            startVoskCommand()
        }
    }

    private fun errorName(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "таймаут сети"
        SpeechRecognizer.ERROR_NETWORK -> "нет сети"
        SpeechRecognizer.ERROR_AUDIO -> "ошибка записи звука"
        SpeechRecognizer.ERROR_SERVER -> "ошибка сервера"
        SpeechRecognizer.ERROR_CLIENT -> "ошибка клиента"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "речь не началась"
        SpeechRecognizer.ERROR_NO_MATCH -> "ничего не распознано"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "распознаватель занят"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "нет разрешения"
        else -> "код $code"
    }

    private val googleListener = object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            Diag.log("google", "готов слушать через ${SystemClock.elapsedRealtime() - tCommand} мс (говорите сейчас)")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val p = list?.firstOrNull()
            if (!p.isNullOrBlank()) {
                updateNotification("Слышу: $p")
                if (!firstPartialLogged) {
                    firstPartialLogged = true
                    Diag.log("google", "первые слова через ${SystemClock.elapsedRealtime() - tCommand} мс: «$p»")
                }
            }
        }

        override fun onResults(results: Bundle?) {
            handler.removeCallbacks(commandTimeout)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list.isNullOrEmpty()) {
                googleFailed("пустой результат")
                return
            }
            val raw = list[0]
            val norm = list.map { TextNorm.normalize(it) }
            // из вариантов Google берём тот, который Луна понимает
            val picked = Rescore.pick(norm, if (pending != null) pendingExpect else Expect.FREE)
            val text = if (picked.isBlank()) norm[0] else picked
            History.pendingRaw = raw
            History.alternatives = norm
            val score = results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull()
            Diag.log(
                "google",
                "услышано: «$raw» → «$text», уверенность $score, варианты: ${list.drop(1).joinToString(" | ")}"
            )
            googleFailures = 0
            if (feeder != null) {
                googleStreamMisses = 0
                Diag.log("google", "Google принял звук из выбранного источника")
            }
            Diag.inc("Google: распознано")
            Diag.inc("команд распознано")
            updateNotification("Услышала: $text")
            Toast.makeText(this@VoiceService, "Услышала: $text", Toast.LENGTH_SHORT).show()
            handler.post {
                destroyGoogle()
                execute(text.removePrefix(wakeWord).trim())
            }
        }

        override fun onError(error: Int) {
            handler.removeCallbacks(commandTimeout)
            val name = errorName(error)
            Diag.log("google", "ошибка $error ($name)")
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    Diag.inc("таймаутов команды")
                    val f = feeder
                    if (f != null && f.peakPercent >= 10) {
                        googleStreamMisses++
                        Diag.log("google", "Google не услышал звук из выбранного источника (пик ${f.peakPercent}%), промахов: $googleStreamMisses")
                        if (googleStreamMisses >= 2) {
                            googleStreamBroken = true
                            Diag.set("Распознавание команд", "Vosk офлайн: Google не принимает выбранный источник звука")
                            Diag.log("google", "Google, похоже, не принимает внешний звук: дальше команды идут офлайн")
                        }
                    } else if (pending == null && !firstPartialLogged) {
                        noteFalseTrigger()
                    }
                    handler.post {
                        destroyGoogle()
                        startWake()
                    }
                }
                else -> googleFailed(name)
            }
        }
    }

    // ---------- Распознавание команд: Vosk (офлайн) ----------

    private fun startVoskCommand() {
        releaseSpeech()
        val m = model ?: return
        try {
            val expect = if (pending != null) pendingExpect else Expect.FREE
            val grammar = Grammars.json(expect)
            val rec = if (grammar != null) Recognizer(m, 16000f, grammar) else Recognizer(m, 16000f)
            rec.setMaxAlternatives(5) // несколько вариантов, из которых выберем понятный
            recognizer = rec
            startVosk(rec)
            tCommand = SystemClock.elapsedRealtime()
            firstPartialLogged = false
            Diag.set(
                "Режим",
                (if (pending != null) "ответ на вопрос Луны" else "приём команды") +
                    " (офлайн${if (grammar != null) ", узкий словарь: $expect" else ""})"
            )
            Diag.log(
                "команда",
                "офлайн-микрофон открыт через ${tCommand - tWake} мс после слова «Луна»" +
                    (if (grammar != null) ", словарь: $expect" else ", полный словарь") +
                    " (речь в этот промежуток теряется)"
            )
            handler.removeCallbacks(commandTimeout)
            handler.postDelayed(commandTimeout, if (pending != null) 10000 else 7000)
        } catch (e: Exception) {
            Diag.log("ошибка", "startVoskCommand: ${e.message}")
            Diag.set("Режим", "ОШИБКА приёма команды: ${e.message}")
        }
    }

    // Результат Vosk: либо {"text": ...}, либо {"alternatives": [{"text": ...}, ...]}
    private fun voskTexts(hypothesis: String): List<String> {
        val o = JSONObject(hypothesis)
        val alts = o.optJSONArray("alternatives")
        if (alts != null) {
            val out = ArrayList<String>()
            for (i in 0 until alts.length()) out.add(alts.getJSONObject(i).optString("text"))
            return out
        }
        return listOf(o.optString("text"))
    }

    override fun onPartialResult(hypothesis: String?) {
        if (hypothesis == null) return
        val partial = JSONObject(hypothesis).optString("partial")
        if (awake) {
            if (partial.isNotBlank()) {
                updateNotification("Слышу: $partial")
                if (!firstPartialLogged) {
                    firstPartialLogged = true
                    Diag.log("команда", "первые слова через ${SystemClock.elapsedRealtime() - tCommand} мс: «$partial»")
                }
            }
            return
        }
        if (wakeSens() == "high" && partial.contains(wakeWord)) {
            tWake = SystemClock.elapsedRealtime()
            Diag.inc("слово «Луна» услышано")
            Diag.log("слово", "услышано слово: «$partial»")
            startCommand()
        }
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        if (!awake) {
            handleWakeResult(hypothesis)
            return
        }
        val alts = voskTexts(hypothesis)
        val text = if (awake) {
            Rescore.pick(alts, if (pending != null) pendingExpect else Expect.FREE)
        } else {
            (alts.firstOrNull() ?: "").replace("[unk]", " ").trim()
        }
        if (awake) History.alternatives = alts.map { it.replace("[unk]", " ").trim() }.filter { it.isNotEmpty() }
        if (awake && alts.size > 1) {
            Diag.log("команда", "варианты офлайн: ${alts.joinToString(" | ")} → выбрано «$text»")
        }
        if (!awake) {
            if (text.isNotEmpty()) {
                if (text.contains(wakeWord)) {
                    tWake = SystemClock.elapsedRealtime()
                    Diag.inc("слово «Луна» услышано")
                    Diag.log("слово", "слово услышано в итоговом результате: «$text»")
                    startCommand()
                } else {
                    Diag.inc("посторонних фраз в ожидании")
                }
            }
            return
        }
        val now = SystemClock.elapsedRealtime()
        val ms = now - tCommand
        if (text.isEmpty()) {
            Diag.inc("пустых результатов команды")
            Diag.log("команда", "пустой результат через $ms мс")
            return
        }
        Diag.inc("команд распознано")
        Diag.log("команда", "услышано (офлайн): «$text» (через $ms мс после открытия микрофона)")
        updateNotification("Услышала: $text")
        Toast.makeText(this, "Услышала: $text", Toast.LENGTH_SHORT).show()
        handler.removeCallbacks(commandTimeout)

        val cleaned = text.removePrefix(wakeWord).trim()
        // Длинные команды и ответы на вопросы собираем, пока человек не замолчит
        val shortAnswer = pending != null && (pendingExpect == Expect.TIME || pendingExpect == Expect.YESNO)
        val collecting = !shortAnswer && (pending != null || buffer.isNotEmpty() || Secretary.isDictation(cleaned) || Device.isDictation(cleaned) ||
                Scenarios.isDictation(cleaned) || Messenger.isDictation(cleaned) ||
                Phone.isDictation(cleaned))
        if (!collecting) {
            execute(cleaned)
            return
        }
        if (buffer.isEmpty()) collectStart = now else buffer.append(' ')
        buffer.append(cleaned)
        handler.removeCallbacks(finishCollect)
        if (now - collectStart > 25000) finishCollecting() else handler.postDelayed(finishCollect, 2000)
    }

    private fun finishCollecting() {
        handler.removeCallbacks(finishCollect)
        val text = buffer.toString().trim()
        buffer.setLength(0)
        if (text.isEmpty()) {
            afterSpeech()
            return
        }
        Diag.log("команда", "диктовка собрана: «$text»")
        execute(text)
    }

    private fun execute(text: String) {
        noteRealCommand()
        val dialog = pending
        pending = null
        val rawNote = History.pendingRaw
        val chatNote = when {
            typedNext -> "введено вручную"
            rawNote.isNotBlank() && rawNote.lowercase() != text -> "распознано: $rawNote"
            else -> ""
        }
        typedNext = false
        ChatLog.add("you", text, chatNote)
        val reply: Reply = try {
            if (dialog != null) dialog(text) else Commands.run(this, text)
        } catch (e: Exception) {
            Diag.inc("ошибок выполнения команд")
            Diag.log("ошибка", "Команда «$text»: ${e.javaClass.simpleName}: ${e.message}")
            Reply("Не получилось выполнить команду")
        }
        pending = reply.followUp
        pendingExpect = reply.expect
        History.noteHeard(text)
        if (dialog != null) History.update(reply.text ?: "") else History.add(text, reply.text ?: "")
        if (dialog == null) Memory.noteCommand(text, !History.isFailure(reply.text) && reply.followUp == null)
        Diag.log("команда", "результат: «${reply.text ?: "без ответа"}»" + if (reply.followUp != null) " (жду ответ)" else "")
        say(reply)
    }

    override fun onFinalResult(hypothesis: String?) {}

    override fun onError(exception: Exception?) {
        Diag.inc("ошибок распознавания")
        Diag.log("ошибка", "Vosk: ${exception?.message}")
    }

    override fun onTimeout() {}

    override fun onDestroy() {
        instance = null
        AudioRoute.release(this)
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        handler.removeCallbacks(finishCollect)
        releaseSpeech()
        tts?.stop()
        tts?.shutdown()
        model?.close()
        Diag.set("Служба", "остановлена")
        Diag.set("Режим", "—")
        Diag.log("служба", "Служба остановлена")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
