package com.luna.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    private val wakeWord = "луна"
    private val handler = Handler(Looper.getMainLooper())

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var recognizer: Recognizer? = null
    private var awake = false
    private var started = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var tWake = 0L
    private var tCommand = 0L
    private var firstPartialLogged = false

    private val commandTimeout = Runnable {
        Diag.inc("таймаутов команды (7 с тишины)")
        Diag.log("команда", "таймаут: команда не услышана за 7 с")
        startWake()
    }
    private val ttsFallback = Runnable {
        Diag.inc("зависаний озвучки")
        Diag.log("голос", "озвучка не завершилась за 15 с, возвращаюсь к ожиданию")
        startWake()
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "luna")
            .setContentTitle("Луна")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true
        Diag.set("Служба", "работает")
        Diag.set("Режим", "подготовка")
        Diag.log("служба", "Запуск службы. Входные устройства: ${Diag.inputDevices(this)}")

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("luna", "Луна", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notification("Подготовка…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Голос Луны (встроенный синтезатор речи Android)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                Diag.log("голос", "TTS запущен, движок: ${tts?.defaultEngine}, русский язык: код $r, готов: $ttsReady")
                Diag.set("Голос (TTS)", if (ttsReady) "готов (русский)" else "русский голос недоступен (код $r)")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        Diag.log("голос", "озвучка началась")
                    }

                    override fun onDone(utteranceId: String?) {
                        Diag.log("голос", "озвучка закончена")
                        handler.post { startWake() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        Diag.inc("ошибок озвучки")
                        Diag.log("голос", "ОШИБКА озвучки")
                        handler.post { startWake() }
                    }
                })
            } else {
                Diag.log("голос", "TTS не запустился, код $status")
                Diag.set("Голос (TTS)", "ошибка запуска (код $status)")
            }
        }

        // Модель скачивается один раз при первом запуске, потом работает без интернета
        Thread {
            val t0 = SystemClock.elapsedRealtime()
            try {
                Diag.set("Модель", "загрузка")
                val m = ModelLoader.ensure(this) { msg ->
                    Diag.set("Модель", msg)
                    handler.post { updateNotification(msg) }
                }
                Diag.log("модель", "Модель загружена за ${SystemClock.elapsedRealtime() - t0} мс")
                Diag.set("Модель", "загружена")
                handler.post {
                    model = m
                    updateNotification("Скажите «Луна»")
                    startWake()
                }
            } catch (e: Exception) {
                Diag.log("модель", "ОШИБКА загрузки: ${e.javaClass.simpleName}: ${e.message}")
                Diag.set("Модель", "ОШИБКА: ${e.message}")
                handler.post {
                    updateNotification("Не удалось скачать модель. Проверьте интернет и запустите снова")
                    Toast.makeText(this, "Не удалось скачать модель: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()

        return START_STICKY
    }

    // Правильная остановка: сначала stop() (ждём поток записи), потом shutdown(), потом закрываем распознаватель
    private fun releaseSpeech() {
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (e: Exception) {
            Diag.log("ошибка", "releaseSpeech: ${e.message}")
        }
        speech = null
        try { recognizer?.close() } catch (e: Exception) { }
        recognizer = null
    }

    // Луна говорит; пока говорит, микрофон выключен, чтобы она не слушала сама себя
    private fun say(text: String?) {
        if (text.isNullOrBlank() || !ttsReady) {
            if (!text.isNullOrBlank()) Diag.log("голос", "ответ «$text» не озвучен: русский голос не готов")
            startWake()
            return
        }
        handler.removeCallbacks(commandTimeout)
        releaseSpeech()
        Diag.inc("ответов озвучено")
        Diag.log("голос", "говорю: «$text»")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        handler.postDelayed(ttsFallback, 15000) // запасной возврат, если озвучка зависла
    }

    // Режим 1: слушаем только слово «Луна»
    private fun startWake() {
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        releaseSpeech()
        awake = false
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f, "[\"$wakeWord\", \"[unk]\"]")
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            Diag.set("Режим", "ожидание слова «Луна»")
            Diag.log("режим", "ожидание слова «Луна»")
        } catch (e: Exception) {
            Diag.log("ошибка", "startWake: ${e.message}")
            Diag.set("Режим", "ОШИБКА запуска ожидания: ${e.message}")
        }
    }

    // Режим 2: после слова слушаем команду полным словарём
    private fun startCommand() {
        releaseSpeech()
        awake = true
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP)
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000f)
            recognizer = rec
            speech = SpeechService(rec, 16000f).also { it.startListening(this) }
            tCommand = SystemClock.elapsedRealtime()
            firstPartialLogged = false
            Diag.set("Режим", "приём команды")
            Diag.log("команда", "микрофон для команды открыт через ${tCommand - tWake} мс после слова «Луна» (речь в этот промежуток теряется)")
            handler.postDelayed(commandTimeout, 7000) // не услышали команду — возвращаемся к ожиданию
        } catch (e: Exception) {
            Diag.log("ошибка", "startCommand: ${e.message}")
            Diag.set("Режим", "ОШИБКА приёма команды: ${e.message}")
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (hypothesis == null) return
        val partial = JSONObject(hypothesis).optString("partial")
        if (awake) {
            if (partial.isNotBlank()) {
                updateNotification("Слышу: $partial")
                if (!firstPartialLogged) {
                    firstPartialLogged = true
                    Diag.log("команда", "первые слова через ${SystemClock.elapsedRealtime() - tCommand} мс: «$partial»")
                }
            }
            return
        }
        if (partial.contains(wakeWord)) {
            tWake = SystemClock.elapsedRealtime()
            Diag.inc("слово «Луна» услышано")
            Diag.log("слово", "услышано слово: «$partial»")
            startCommand()
        }
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        val text = JSONObject(hypothesis).optString("text").trim()
        if (!awake) {
            if (text.isNotEmpty()) {
                if (text.contains(wakeWord)) {
                    tWake = SystemClock.elapsedRealtime()
                    Diag.inc("слово «Луна» услышано")
                    Diag.log("слово", "слово услышано в итоговом результате: «$text»")
                    startCommand()
                } else {
                    Diag.inc("посторонних фраз в ожидании")
                }
            }
            return
        }
        val ms = SystemClock.elapsedRealtime() - tCommand
        if (text.isEmpty()) {
            Diag.inc("пустых результатов команды")
            Diag.log("команда", "пустой результат через $ms мс")
            return
        }
        Diag.inc("команд распознано")
        Diag.log("команда", "услышано: «$text» (через $ms мс после открытия микрофона)")
        updateNotification("Услышала: $text")
        Toast.makeText(this, "Услышала: $text", Toast.LENGTH_SHORT).show()
        handler.removeCallbacks(commandTimeout)
        val reply = Commands.run(this, text.removePrefix(wakeWord).trim())
        Diag.log("команда", "результат: «${reply ?: "без ответа"}»")
        say(reply)
    }

    override fun onFinalResult(hypothesis: String?) {}

    override fun onError(exception: Exception?) {
        Diag.inc("ошибок распознавания")
        Diag.log("ошибка", "Vosk: ${exception?.message}")
    }

    override fun onTimeout() {}

    override fun onDestroy() {
        handler.removeCallbacks(commandTimeout)
        handler.removeCallbacks(ttsFallback)
        releaseSpeech()
        tts?.stop()
        tts?.shutdown()
        model?.close()
        Diag.set("Служба", "остановлена")
        Diag.set("Режим", "—")
        Diag.log("служба", "Служба остановлена")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
